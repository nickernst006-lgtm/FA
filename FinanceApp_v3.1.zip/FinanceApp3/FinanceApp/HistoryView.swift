import SwiftUI

struct HistoryView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var goToForm: () -> Void

    @State private var filterBankId: UUID? = nil
    @State private var filterCategoryName: String = ""
    @State private var filterFrom: Date? = nil
    @State private var filterTo: Date? = nil
    @State private var searchText: String = ""
    @State private var showFilters = false
    @State private var showClearConfirm = false
    @State private var exportFile: ExportFile? = nil
    @State private var deleteTarget: OperationRecord? = nil

    var hasActiveFilters: Bool {
        filterBankId != nil || !filterCategoryName.isEmpty || filterFrom != nil || filterTo != nil
    }

    var filteredSorted: [OperationRecord] {
        var items = appState.data.operations

        if let filterBankId, let bank = appState.data.banks.first(where: { $0.id == filterBankId }) {
            items = items.filter { $0.bank == bank.name }
        }
        if !filterCategoryName.isEmpty {
            items = items.filter { $0.category == filterCategoryName }
        }
        if let from = filterFrom {
            let s = DateFmt.dayString(from)
            items = items.filter { $0.date >= s }
        }
        if let to = filterTo {
            let s = DateFmt.dayString(to)
            items = items.filter { $0.date <= s }
        }
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            items = items.filter { r in
                let fields = [r.person, r.comment, r.category, r.subcategory, r.bank, r.account, r.operation]
                return fields.contains { $0.localizedCaseInsensitiveContains(q) } || Money.format(r.amount).contains(q)
            }
        }

        return items.sorted { a, b in
            if a.date != b.date { return a.date > b.date }
            if a.time != b.time { return a.time > b.time }
            return a.createdAt > b.createdAt
        }
    }

    struct DayGroup: Identifiable {
        let day: String
        var items: [OperationRecord]
        var id: String { day }
    }

    func groupByDay(_ sorted: [OperationRecord]) -> [DayGroup] {
        var result: [DayGroup] = []
        for rec in sorted {
            if let last = result.last, last.day == rec.date {
                result[result.count - 1].items.append(rec)
            } else {
                result.append(DayGroup(day: rec.date, items: [rec]))
            }
        }
        return result
    }

    var body: some View {
        let items = filteredSorted
        let groups = groupByDay(items)
        List {
            if items.isEmpty {
                emptyState
            } else {
                ForEach(groups) { group in
                    Section {
                        ForEach(group.items) { rec in
                            Button { edit(rec) } label: {
                                RecordRow(rec: rec)
                            }
                            .buttonStyle(.plain)
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) { deleteTarget = rec } label: {
                                    Label("Удалить", systemImage: "trash")
                                }
                            }
                            .swipeActions(edge: .leading) {
                                Button { duplicate(rec) } label: { Label("Копия", systemImage: "plus.square.on.square") }
                                    .tint(.indigo)
                            }
                            .contextMenu {
                                Button { edit(rec) } label: { Label("Изменить", systemImage: "pencil") }
                                Button { duplicate(rec) } label: { Label("Сделать копию", systemImage: "plus.square.on.square") }
                                Divider()
                                Button(role: .destructive) { deleteTarget = rec } label: { Label("Удалить", systemImage: "trash") }
                            }
                        }
                    } header: {
                        Text(DateFmt.humanDay(group.day))
                    }
                }
            }
        }
        .navigationTitle("История")
        .themedList()
        .searchable(text: $searchText, prompt: "Поиск")
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    showFilters = true
                } label: {
                    Image(systemName: hasActiveFilters
                          ? "line.3.horizontal.decrease.circle.fill"
                          : "line.3.horizontal.decrease.circle")
                }
                .accessibilityLabel("Фильтры")

                Menu {
                    Button {
                        export(appState.data.operations)
                    } label: {
                        Label("Экспорт всех в Excel", systemImage: "square.and.arrow.up")
                    }
                    .disabled(appState.data.operations.isEmpty)
                    if hasActiveFilters || !searchText.isEmpty {
                        Button {
                            export(items)
                        } label: {
                            Label("Экспорт найденных (\(items.count))", systemImage: "square.and.arrow.up.on.square")
                        }
                        .disabled(items.isEmpty)
                    }
                    Divider()
                    Button(role: .destructive) { showClearConfirm = true } label: {
                        Label("Очистить базу", systemImage: "trash")
                    }
                    .disabled(appState.data.operations.isEmpty)
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .accessibilityLabel("Действия")
            }
        }
        .sheet(isPresented: $showFilters) {
            filtersSheet
        }
        .alert("Удалить запись?", isPresented: Binding(
            get: { deleteTarget != nil },
            set: { if !$0 { deleteTarget = nil } }
        )) {
            Button("Отмена", role: .cancel) { deleteTarget = nil }
            Button("Удалить", role: .destructive) {
                if let t = deleteTarget {
                    appState.data.operations.removeAll { $0.id == t.id }
                    if editState == .edit(t.id) || editState == .duplicate(t.id) { editState = nil }
                    appState.persist()
                }
                deleteTarget = nil
            }
        } message: {
            Text("Операция будет удалена без возможности восстановления.")
        }
        .alert("Очистить базу?", isPresented: $showClearConfirm) {
            Button("Отмена", role: .cancel) {}
            Button("Очистить", role: .destructive) {
                appState.data.operations.removeAll()
                editState = nil
                appState.persist()
            }
        } message: {
            Text("Все операции (\(appState.data.operations.count)) будут удалены безвозвратно. Справочники останутся. Если данные нужны, сначала сделайте экспорт в Excel.")
        }
        .sheet(item: $exportFile) { file in
            ShareSheet(fileURL: file.url) { exportFile = nil }
                .presentationDetents([.medium, .large])
        }
    }

    @ViewBuilder
    private var emptyState: some View {
        if appState.data.operations.isEmpty {
            ContentUnavailableView("Операций пока нет",
                                   systemImage: "tray",
                                   description: Text("Добавьте первую операцию во вкладке «Форма»."))
                .listRowBackground(Color.clear)
        } else {
            ContentUnavailableView.search(text: searchText)
                .listRowBackground(Color.clear)
        }
    }

    private var filtersSheet: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Банк", selection: $filterBankId) {
                        Text("Все").tag(UUID?.none)
                        ForEach(appState.data.banks) { b in Text(b.name).tag(Optional(b.id)) }
                    }
                    Picker("Категория", selection: $filterCategoryName) {
                        Text("Все").tag("")
                        ForEach(categoryNames, id: \.self) { c in Text(c).tag(c) }
                    }
                }
                Section("Период") {
                    OptionalPickerField(label: "С", value: $filterFrom, placeholder: "Не выбрано") { b in
                        DatePicker("", selection: b, displayedComponents: .date).labelsHidden()
                    }
                    OptionalPickerField(label: "По", value: $filterTo, placeholder: "Не выбрано") { b in
                        DatePicker("", selection: b, displayedComponents: .date).labelsHidden()
                    }
                }
                if hasActiveFilters {
                    Section {
                        Button("Сбросить фильтры", role: .destructive) {
                            filterBankId = nil; filterCategoryName = ""; filterFrom = nil; filterTo = nil
                        }
                    }
                }
            }
            .navigationTitle("Фильтры")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { showFilters = false }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    var categoryNames: [String] {
        Array(Set(appState.data.categories.map { $0.name }))
            .sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    func edit(_ rec: OperationRecord) {
        editState = .edit(rec.id)
        goToForm()
    }

    func duplicate(_ rec: OperationRecord) {
        editState = .duplicate(rec.id)
        goToForm()
    }

    func export(_ operations: [OperationRecord]) {
        guard !operations.isEmpty else { return }
        let sorted = operations.sorted { a, b in
            if a.date != b.date { return a.date < b.date }
            if a.time != b.time { return a.time < b.time }
            return a.createdAt < b.createdAt
        }
        let xlsxData = XLSXExporter.buildXLSX(operations: sorted)
        let filename = "operations_\(DateFmt.fileStamp(Date())).xlsx"
        let tmpURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
        do {
            try xlsxData.write(to: tmpURL, options: [.atomic, .completeFileProtection])
            exportFile = ExportFile(url: tmpURL)
        } catch {
            appState.saveError = "Не удалось подготовить файл Excel: \(error.localizedDescription)"
        }
    }
}

/// Строка операции — всегда одинаковой высоты: две строки текста.
/// Сверху категория и сумма, снизу серым — счёт, лицо и время.
/// Нажатие — изменить, смахивание — удалить или копия, долгое нажатие — меню.
struct RecordRow: View {
    let rec: OperationRecord

    var body: some View {
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: rec.isIncome ? "arrow.down" : (rec.isExpense ? "arrow.up" : "arrow.left.arrow.right"),
                      color: rec.isIncome ? Theme.income : (rec.isExpense ? Theme.expense : .gray),
                      size: 36)
            VStack(alignment: .leading, spacing: 2) {
                HStack(alignment: .firstTextBaseline, spacing: Theme.gap) {
                    Text(title).font(Theme.body).lineLimit(1)
                    Spacer(minLength: 0)
                    AmountText(record: rec)
                }
                Text(subtitle).font(Theme.detail).foregroundStyle(.secondary).lineLimit(1)
            }
        }
        .contentShape(Rectangle())
    }

    private var title: String {
        rec.subcategory.isEmpty ? rec.category : "\(rec.category), \(rec.subcategory)"
    }

    private var subtitle: String {
        var parts = [rec.account.isEmpty ? rec.bank : "\(rec.bank), \(rec.account)"]
        if !rec.person.isEmpty { parts.append(rec.person) }
        if !rec.time.isEmpty { parts.append(rec.time) }
        return parts.joined(separator: " · ")
    }
}
