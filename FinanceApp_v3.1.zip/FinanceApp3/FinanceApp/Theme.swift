import SwiftUI

/// Единый визуальный язык приложения в духе Apple Human Interface Guidelines:
/// системные цвета, SF Symbols, скруглённые шрифты для чисел, много воздуха.
enum Theme {
    static let income = Color.green
    /// Палитра для категорий в диаграммах — системные цвета iOS
    static let palette: [Color] = [.blue, .orange, .purple, .teal, .pink, .indigo, .mint, .yellow, .red, .cyan]

    static func color(at index: Int) -> Color { palette[index % palette.count] }

    /// Крупная сумма (герой экрана)
    static func heroNumber(_ size: CGFloat = 40) -> Font {
        .system(size: size, weight: .bold, design: .rounded).monospacedDigit()
    }
}

/// Цветной квадратик с иконкой — как в «Настройках» iPhone
struct IconBadge: View {
    let symbol: String
    let color: Color
    var size: CGFloat = 29

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.5, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(color.gradient, in: RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
            .accessibilityHidden(true)
    }
}

/// Строка-пояснение с иконкой (для экрана «О приложении»)
struct FeatureRow: View {
    let symbol: String
    let color: Color
    let title: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 14) {
            IconBadge(symbol: symbol, color: color)
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.body.weight(.medium))
                Text(text).font(.subheadline).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(.vertical, 4)
    }
}

/// Сумма со знаком: доходы зелёным, расходы — обычным цветом (как в Wallet)
struct AmountText: View {
    let record: OperationRecord
    var font: Font = .body.weight(.semibold)

    var body: some View {
        Text((record.isIncome ? "+" : (record.isExpense ? "−" : "")) + Money.format(record.amount) + " ₽")
            .font(font)
            .monospacedDigit()
            .foregroundStyle(record.isIncome ? Theme.income : Color.primary)
            .lineLimit(1)
    }
}
