import Foundation

// `nonisolated` — модели данных не привязаны к главному потоку.
// Это важно для Xcode 26: в новых проектах всё по умолчанию привязано к
// главному потоку (MainActor), и без этой пометки шифрование в фоне не собралось бы.

nonisolated struct Bank: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
}

nonisolated struct Account: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    var bankId: UUID
}

/// Как операция учитывается в статистике
nonisolated enum OpKind: String, Codable, CaseIterable, Identifiable {
    case income     // доход: прибавляется к балансу
    case expense    // расход: вычитается из баланса
    case neutral    // не учитывается (например, перевод между своими счетами)

    var id: String { rawValue }
    var title: String {
        switch self {
        case .income: return "Доход"
        case .expense: return "Расход"
        case .neutral: return "Не учитывать"
        }
    }
    var symbol: String {
        switch self {
        case .income: return "arrow.down"
        case .expense: return "arrow.up"
        case .neutral: return "arrow.left.arrow.right"
        }
    }

    /// Запасной вариант для операций, тип которых ещё не задан вручную
    static func guessed(fromName name: String) -> OpKind {
        if name.localizedCaseInsensitiveContains("доход") { return .income }
        if name.localizedCaseInsensitiveContains("расход") { return .expense }
        return .neutral
    }
}

nonisolated struct OperationType: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    /// Пусто у операций, созданных до появления настройки — тогда тип угадывается по названию
    var kind: OpKind? = nil

    var effectiveKind: OpKind { kind ?? OpKind.guessed(fromName: name) }
}

nonisolated struct Category: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    var opId: UUID
}

nonisolated struct Subcategory: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    var catId: UUID
}

nonisolated struct Person: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
}

nonisolated struct OperationRecord: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var date: String       // "yyyy-MM-dd"
    var time: String       // "HH:mm" или ""
    var bank: String
    var account: String
    var operation: String
    var category: String
    var subcategory: String
    var person: String
    var amount: Double
    var comment: String
    var createdAt: Double  // timestamp, для сортировки при равных датах и времени

}

nonisolated struct AppData: Codable, Equatable {
    var banks: [Bank] = []
    var accounts: [Account] = []
    var optypes: [OperationType] = []
    var categories: [Category] = []
    var subcategories: [Subcategory] = []
    var persons: [Person] = []
    var operations: [OperationRecord] = []

    /// Тип операции берётся из справочника по названию, которое сохранено в записи.
    /// Если такой операции в справочнике уже нет — определяем по названию.
    func kind(of record: OperationRecord) -> OpKind {
        optypes.first { $0.name == record.operation }?.effectiveKind
            ?? OpKind.guessed(fromName: record.operation)
    }

    func isIncome(_ record: OperationRecord) -> Bool { kind(of: record) == .income }
    func isExpense(_ record: OperationRecord) -> Bool { kind(of: record) == .expense }

    /// Сумма со знаком: доход +, расход −, нейтральные не учитываются
    func signedAmount(_ record: OperationRecord) -> Double {
        switch kind(of: record) {
        case .income: return record.amount
        case .expense: return -record.amount
        case .neutral: return 0
        }
    }
}

// MARK: - Форматирование дат

/// Даты и время всегда в фиксированном формате, независимо от настроек iPhone
/// (12/24-часовой формат, буддийский/японский календарь и т.п.).
nonisolated enum DateFmt {
    private static func make(_ format: String) -> DateFormatter {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.calendar = Calendar(identifier: .gregorian)
        f.timeZone = TimeZone.current
        f.dateFormat = format
        return f
    }

    static func dayString(_ d: Date) -> String { make("yyyy-MM-dd").string(from: d) }
    static func timeString(_ d: Date) -> String { make("HH:mm").string(from: d) }
    static func fileStamp(_ d: Date) -> String { make("yyyy-MM-dd_HHmm").string(from: d) }
    static func day(from s: String) -> Date? { s.isEmpty ? nil : make("yyyy-MM-dd").date(from: s) }
    static func time(from s: String) -> Date? { s.isEmpty ? nil : make("HH:mm").date(from: s) }

    /// "2026-09-15" → "15.09.2026" для показа на экране
    static func display(_ s: String) -> String {
        let parts = s.split(separator: "-")
        guard parts.count == 3 else { return s }
        return "\(parts[2]).\(parts[1]).\(parts[0])"
    }

    /// "2026-09-15" → "Сегодня" / "Вчера" / "15 сентября" / "15 сентября 2025"
    static func humanDay(_ s: String, today: Date = Date()) -> String {
        let parts = s.split(separator: "-")
        guard parts.count == 3, let m = Int(parts[1]), (1...12).contains(m), let d = Int(parts[2]) else { return s }
        let todayStr = dayString(today)
        if s == todayStr { return "Сегодня" }
        if let y = Calendar(identifier: .gregorian).date(byAdding: .day, value: -1, to: today), s == dayString(y) {
            return "Вчера"
        }
        let names = ["января", "февраля", "марта", "апреля", "мая", "июня",
                     "июля", "августа", "сентября", "октября", "ноября", "декабря"]
        let year = String(parts[0])
        return year == String(todayStr.prefix(4)) ? "\(d) \(names[m - 1])" : "\(d) \(names[m - 1]) \(year)"
    }

    /// "2026-09" → "Сентябрь 2026"
    static func monthTitle(_ ym: String) -> String {
        let names = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                     "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]
        let parts = ym.split(separator: "-")
        guard parts.count == 2, let m = Int(parts[1]), (1...12).contains(m) else { return ym }
        return "\(names[m - 1]) \(parts[0])"
    }
}

// MARK: - Деньги

nonisolated enum Money {
    /// "1 234,56" — для показа на экране
    static func format(_ value: Double) -> String {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.numberStyle = .decimal
        f.minimumFractionDigits = 2
        f.maximumFractionDigits = 2
        return f.string(from: NSNumber(value: value)) ?? String(format: "%.2f", value)
    }

    /// Разбор введённой суммы: понимает "1234,56", "1 234.56", "1 234,5".
    /// Возвращает nil, если это не число.
    static func parse(_ text: String) -> Double? {
        var s = text.trimmingCharacters(in: .whitespacesAndNewlines)
        for sp in [" ", "\u{00A0}", "\u{202F}"] { s = s.replacingOccurrences(of: sp, with: "") }
        s = s.replacingOccurrences(of: ",", with: ".")
        guard !s.isEmpty,
              s.allSatisfy({ $0.isASCII && ($0.isNumber || $0 == ".") }),
              s.filter({ $0 == "." }).count <= 1,
              let v = Double(s), v.isFinite else { return nil }
        return (v * 100).rounded() / 100
    }

    /// Сумма для подстановки в поле при редактировании: "50000" или "1234,56"
    static func editString(_ value: Double) -> String {
        if value == value.rounded() { return String(format: "%.0f", value) }
        return String(format: "%.2f", value).replacingOccurrences(of: ".", with: ",")
    }
}
