#if DEBUG
import Foundation

/// Демо-данные ТОЛЬКО для автоматических скриншотов в облачных тестах.
/// Расходы записаны со знаком минус — знак задаёт пользователь, а не тип операции.
/// Код существует лишь в отладочной сборке и включается специальным
/// параметром запуска "-uiTestDemo" — в обычной работе он не срабатывает никогда.
nonisolated enum DemoData {
    static func make() -> AppData {
        var d = AppData()
        let tinkoff = Bank(name: "Тинькофф"), sber = Bank(name: "Сбербанк")
        d.banks = [tinkoff, sber]
        d.accounts = [Account(name: "Основной", bankId: tinkoff.id, currency: .rub),
                      Account(name: "Кредитка", bankId: tinkoff.id, currency: .rub),
                      Account(name: "Валютный", bankId: tinkoff.id, currency: .usd),
                      Account(name: "Старый", bankId: sber.id, currency: .rub, closed: true),
                      Account(name: "Зарплатный", bankId: sber.id, currency: .rub)]
        let income = OperationType(name: "Поступление", kind: .income)
        let expense = OperationType(name: "Трата", kind: .expense)
        d.optypes = [income, expense]
        let salary = Category(name: "Зарплата", opId: income.id)
        let food = Category(name: "Еда", opId: expense.id)
        let home = Category(name: "Дом", opId: expense.id)
        let transport = Category(name: "Транспорт", opId: expense.id)
        d.categories = [salary, food, home, transport]
        d.subcategories = [Subcategory(name: "Кафе", catId: food.id),
                           Subcategory(name: "Продукты", catId: food.id),
                           Subcategory(name: "Коммуналка", catId: home.id),
                           Subcategory(name: "Такси", catId: transport.id)]
        let common = PersonGroup(name: PersonGroup.defaultName)
        let work = PersonGroup(name: "Работа")
        d.personGroups = [common, work]
        d.persons = [Person(name: "Иванов И.И.", groupId: common.id),
                     Person(name: "Петрова А.С.", groupId: common.id, pinned: true),
                     Person(name: "ООО «Ромашка»", groupId: work.id)]

        var t: Double = 1_700_000_000
        func op(_ date: String, _ time: String, _ bank: String, _ acc: String, _ kind: String,
                _ cat: String, _ sub: String, _ person: String, _ amount: Double,
                _ comment: String = "", _ currency: Currency = .rub) -> OperationRecord {
            t += 1
            return OperationRecord(date: date, time: time, bank: bank, account: acc, operation: kind,
                                   category: cat, subcategory: sub, person: person, amount: amount,
                                   comment: comment, createdAt: t, currency: currency)
        }
        d.operations = [
            op("2026-06-05", "10:00", "Сбербанк", "Зарплатный", "Поступление", "Зарплата", "", "ООО «Ромашка»", 120000),
            op("2026-06-12", "19:30", "Тинькофф", "Основной", "Трата", "Еда", "Продукты", "", -8450.40),
            op("2026-07-05", "10:00", "Сбербанк", "Зарплатный", "Поступление", "Зарплата", "", "ООО «Ромашка»", 120000),
            op("2026-07-20", "09:15", "Тинькофф", "Кредитка", "Трата", "Дом", "Коммуналка", "", -6230),
            op("2026-08-05", "10:00", "Сбербанк", "Зарплатный", "Поступление", "Зарплата", "", "ООО «Ромашка»", 125000),
            op("2026-08-14", "13:40", "Тинькофф", "Основной", "Трата", "Еда", "Кафе", "Петрова А.С.", -2340, "Обед"),
            op("2026-09-05", "10:00", "Сбербанк", "Зарплатный", "Поступление", "Зарплата", "", "ООО «Ромашка»", 125000),
            op("2026-09-15", "14:30", "Тинькофф", "Основной", "Трата", "Еда", "Кафе", "Иванов И.И.", -1234.56, "Обед с клиентом"),
            op("2026-09-15", "22:10", "Тинькофф", "Кредитка", "Трата", "Транспорт", "Такси", "", -780),
            op("2026-09-16", "12:00", "Тинькофф", "Валютный", "Трата", "Еда", "Кафе", "", -42.50, "", .usd),
        ]
        d.repairPersonGroups()
        return d
    }
}
#endif
