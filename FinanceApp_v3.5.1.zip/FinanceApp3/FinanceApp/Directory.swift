import Foundation

/// Операции над справочниками в одном месте.
///
/// Главное правило: переименование элемента справочника обязано пройти и по уже
/// сохранённым операциям — в записи лежит название, а не ссылка. Удаление,
/// наоборот, сохранённых операций не трогает: история не должна меняться задним
/// числом из-за того, что счёт закрыли.
extension AppState {

    // MARK: - Переименование

    func renameBank(_ id: UUID, to newName: String) {
        var d = data
        guard let i = d.banks.firstIndex(where: { $0.id == id }), d.banks[i].name != newName else { return }
        let old = d.banks[i].name
        d.banks[i].name = newName
        for k in d.operations.indices where d.operations[k].bank == old {
            d.operations[k].bank = newName
        }
        data = d; persist()
    }

    func renameAccount(_ id: UUID, to newName: String) {
        var d = data
        guard let i = d.accounts.firstIndex(where: { $0.id == id }), d.accounts[i].name != newName else { return }
        let old = d.accounts[i].name
        let bankName = d.banks.first(where: { $0.id == d.accounts[i].bankId })?.name ?? ""
        d.accounts[i].name = newName
        for k in d.operations.indices
        where d.operations[k].bank == bankName && d.operations[k].account == old {
            d.operations[k].account = newName
        }
        data = d; persist()
    }

    func renameOperationType(_ id: UUID, to newName: String) {
        var d = data
        guard let i = d.optypes.firstIndex(where: { $0.id == id }), d.optypes[i].name != newName else { return }
        let old = d.optypes[i].name
        d.optypes[i].name = newName
        for k in d.operations.indices where d.operations[k].operation == old {
            d.operations[k].operation = newName
        }
        data = d; persist()
    }

    func renameCategory(_ id: UUID, to newName: String) {
        var d = data
        guard let i = d.categories.firstIndex(where: { $0.id == id }), d.categories[i].name != newName else { return }
        let old = d.categories[i].name
        let opName = d.optypes.first(where: { $0.id == d.categories[i].opId })?.name ?? ""
        d.categories[i].name = newName
        for k in d.operations.indices
        where d.operations[k].operation == opName && d.operations[k].category == old {
            d.operations[k].category = newName
        }
        data = d; persist()
    }

    func renameSubcategory(_ id: UUID, to newName: String) {
        var d = data
        guard let i = d.subcategories.firstIndex(where: { $0.id == id }),
              d.subcategories[i].name != newName else { return }
        let old = d.subcategories[i].name
        let cat = d.categories.first(where: { $0.id == d.subcategories[i].catId })
        let catName = cat?.name ?? ""
        let opName = d.optypes.first(where: { $0.id == cat?.opId })?.name ?? ""
        d.subcategories[i].name = newName
        for k in d.operations.indices
        where d.operations[k].operation == opName
            && d.operations[k].category == catName
            && d.operations[k].subcategory == old {
            d.operations[k].subcategory = newName
        }
        data = d; persist()
    }

    func renamePerson(_ id: UUID, to newName: String) {
        var d = data
        guard let i = d.persons.firstIndex(where: { $0.id == id }), d.persons[i].name != newName else { return }
        let old = d.persons[i].name
        d.persons[i].name = newName
        for k in d.operations.indices where d.operations[k].person == old {
            d.operations[k].person = newName
        }
        data = d; persist()
    }

    func renamePersonGroup(_ id: UUID, to newName: String) {
        guard let i = data.personGroups.firstIndex(where: { $0.id == id }),
              data.personGroups[i].name != newName else { return }
        data.personGroups[i].name = newName
        persist()
    }

    // MARK: - Удаление (сохранённые операции не затрагиваются)

    func deleteBank(_ id: UUID) {
        data.accounts.removeAll { $0.bankId == id }
        data.banks.removeAll { $0.id == id }
        persist()
    }

    func deleteAccount(_ id: UUID) {
        data.accounts.removeAll { $0.id == id }
        persist()
    }

    func deleteOperationType(_ id: UUID) {
        let catIds = Set(data.categories.filter { $0.opId == id }.map { $0.id })
        data.subcategories.removeAll { catIds.contains($0.catId) }
        data.categories.removeAll { $0.opId == id }
        data.optypes.removeAll { $0.id == id }
        persist()
    }

    func deleteCategory(_ id: UUID) {
        data.subcategories.removeAll { $0.catId == id }
        data.categories.removeAll { $0.id == id }
        persist()
    }

    func deleteSubcategory(_ id: UUID) {
        data.subcategories.removeAll { $0.id == id }
        persist()
    }

    func deletePerson(_ id: UUID) {
        data.persons.removeAll { $0.id == id }
        persist()
    }

    /// Удалить категорию лиц. Сами лица не теряются — переезжают в первую
    /// оставшуюся категорию, иначе они пропали бы из справочника незаметно.
    func deletePersonGroup(_ id: UUID) {
        guard data.personGroups.count > 1 else { return }
        data.personGroups.removeAll { $0.id == id }
        data.repairPersonGroups()
        persist()
    }

    // MARK: - Порядок

    func moveBanks(_ from: IndexSet, _ to: Int) {
        data.banks.move(fromOffsets: from, toOffset: to); persist()
    }
    func moveOperationTypes(_ from: IndexSet, _ to: Int) {
        data.optypes.move(fromOffsets: from, toOffset: to); persist()
    }
    func movePersonGroups(_ from: IndexSet, _ to: Int) {
        data.personGroups.move(fromOffsets: from, toOffset: to); persist()
    }

    /// Перестановка внутри подсписка: двигаем элементы в общем массиве так,
    /// чтобы порядок совпал с тем, что пользователь видит на экране.
    func moveAccounts(in bankId: UUID, _ from: IndexSet, _ to: Int) {
        reorder(&data.accounts, matching: { $0.bankId == bankId }, from, to); persist()
    }
    func moveCategories(in opId: UUID, _ from: IndexSet, _ to: Int) {
        reorder(&data.categories, matching: { $0.opId == opId }, from, to); persist()
    }
    func moveSubcategories(in catId: UUID, _ from: IndexSet, _ to: Int) {
        reorder(&data.subcategories, matching: { $0.catId == catId }, from, to); persist()
    }

    private func reorder<T>(_ array: inout [T], matching belongs: (T) -> Bool,
                            _ from: IndexSet, _ to: Int) {
        let slots = array.indices.filter { belongs(array[$0]) }
        var visible = slots.map { array[$0] }
        visible.move(fromOffsets: from, toOffset: to)
        for (slot, item) in zip(slots, visible) { array[slot] = item }
    }

    // MARK: - Прочее

    func setAccountCurrency(_ id: UUID, _ currency: Currency) {
        guard let i = data.accounts.firstIndex(where: { $0.id == id }) else { return }
        data.accounts[i].currency = currency; persist()
    }

    func setAccountClosed(_ id: UUID, _ closed: Bool) {
        guard let i = data.accounts.firstIndex(where: { $0.id == id }) else { return }
        data.accounts[i].closed = closed; persist()
    }

    func setOperationKind(_ id: UUID, _ kind: OpKind) {
        guard let i = data.optypes.firstIndex(where: { $0.id == id }) else { return }
        data.optypes[i].kind = kind; persist()
    }

    func setPersonPinned(_ id: UUID, _ pinned: Bool) {
        guard let i = data.persons.firstIndex(where: { $0.id == id }) else { return }
        data.persons[i].pinned = pinned; persist()
    }

    func setPersonGroup(_ id: UUID, _ groupId: UUID) {
        guard let i = data.persons.firstIndex(where: { $0.id == id }) else { return }
        data.persons[i].groupId = groupId; persist()
    }

    /// Проверка на дубликат без учёта регистра
    func nameIsFree(_ name: String, among names: [String]) -> Bool {
        !names.contains { $0.compare(name, options: [.caseInsensitive]) == .orderedSame }
    }
}
