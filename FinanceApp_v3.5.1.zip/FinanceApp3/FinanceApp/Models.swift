import Foundation

// `nonisolated` — модели данных не привязаны к главному потоку.
// Это важно для Xcode 26: в новых проектах всё по умолчанию привязано к
// главному потоку (MainActor), и без этой пометки шифрование в фоне не собралось бы.

/// Валюта счёта и операции
nonisolated enum Currency: String, Codable, CaseIterable, Identifiable {
    case rub, usd, eur, cny

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .rub: return "₽"
        case .usd: return "$"
        case .eur: return "€"
        case .cny: return "¥"
        }
    }
    var title: String {
        switch self {
        case .rub: return "Рубль"
        case .usd: return "Доллар"
        case .eur: return "Евро"
        case .cny: return "Юань"
        }
    }
    var code: String { rawValue.uppercased() }
}

nonisolated struct Bank: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
}

nonisolated struct Account: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    var bankId: UUID
    /// Пусто у счетов, заведённых до появления валют — тогда считаем рублёвым
    var currency: Currency? = nil
    /// Пусто у старых счетов — тогда считаем открытым
    var closed: Bool? = nil

    var effectiveCurrency: Currency { currency ?? .rub }
    var isClosed: Bool { closed ?? false }
}

/// Как операция учитывается в статистике
nonisolated enum OpKind: String, Codable, CaseIterable, Identifiable {
    case income     // доход: прибавляется к балансу
    case expense    // расход: вычитается из баланса
    case neutral    // не учитывается (например, перевод между своими счетами)

    var id: String { rawValue }
    var title: String {
        switch self {
        case .income: return "Доход"
        case .expense: return "Расход"
        case .neutral: return "Не учитывать"
        }
    }
    var symbol: String {
        switch self {
        case .income: return "arrow.down"
        case .expense: return "arrow.up"
        case .neutral: return "arrow.left.arrow.right"
        }
    }

    /// Запасной вариант для операций, тип которых ещё не задан вручную
    static func guessed(fromName name: String) -> OpKind {
        if name.localizedCaseInsensitiveContains("доход") { return .income }
        if name.localizedCaseInsensitiveContains("расход") { return .expense }
        return .neutral
    }
}

nonisolated struct OperationType: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    /// Пусто у операций, созданных до появления настройки — тогда тип угадывается по названию
    var kind: OpKind? = nil

    var effectiveKind: OpKind { kind ?? OpKind.guessed(fromName: name) }
}

nonisolated struct Category: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    var opId: UUID
}

nonisolated struct Subcategory: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    var catId: UUID
}

/// Категория лиц — первый уровень справочника «Люди»
nonisolated struct PersonGroup: Identifiable, Codable, Equatable, Hashable {
    static let defaultName = "Общее"

    var id: UUID = UUID()
    var name: String
}

nonisolated struct Person: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var name: String
    /// Пусто у лиц, заведённых до появления категорий — при загрузке уходят в «Общее»
    var groupId: UUID? = nil
    /// Закреплённые лица всегда идут первыми, не считаясь с частотностью
    var pinned: Bool? = nil

    var isPinned: Bool { pinned ?? false }
}

nonisolated struct OperationRecord: Identifiable, Codable, Equatable, Hashable {
    var id: UUID = UUID()
    var date: String       // "yyyy-MM-dd"
    var time: String       // "HH:mm" или ""
    var bank: String
    var account: String
    var operation: String
    var category: String
    var subcategory: String
    var person: String
    var amount: Double
    var comment: String
    var createdAt: Double  // timestamp, для сортировки при равных датах и времени
    /// Пусто у операций, записанных до появления валют — тогда это рубли
    var currency: Currency? = nil

    var effectiveCurrency: Currency { currency ?? .rub }
}

/// Остаток по одному счёту в одной валюте
nonisolated struct AccountBalance: Identifiable, Equatable {
    var bank: String
    var account: String
    var currency: Currency
    var total: Double
    var count: Int
    var closed: Bool

    var id: String { "\(bank)|\(account)|\(currency.rawValue)" }
}

nonisolated struct AppData: Codable, Equatable {
    var banks: [Bank] = []
    var accounts: [Account] = []
    var optypes: [OperationType] = []
    var categories: [Category] = []
    var subcategories: [Subcategory] = []
    var personGroups: [PersonGroup] = []
    var persons: [Person] = []
    var operations: [OperationRecord] = []
    /// Дневной план по расходам. Показывается серой планкой в отчёте
    /// о динамике; пусто — планка не рисуется.
    var dailyPlan: Double? = nil

    enum CodingKeys: String, CodingKey {
        case banks, accounts, optypes, categories, subcategories, personGroups, persons, operations
        case dailyPlan
    }

    init() {
        personGroups = [PersonGroup(name: PersonGroup.defaultName)]
    }

    /// Свой декодер вместо синтезированного: старые файлы не знают о новых полях,
    /// и обычный декодер на них падал бы целиком. `decodeIfPresent` делает любое
    /// новое поле необязательным — это же защитит и будущие версии.
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        banks = try c.decodeIfPresent([Bank].self, forKey: .banks) ?? []
        accounts = try c.decodeIfPresent([Account].self, forKey: .accounts) ?? []
        optypes = try c.decodeIfPresent([OperationType].self, forKey: .optypes) ?? []
        categories = try c.decodeIfPresent([Category].self, forKey: .categories) ?? []
        subcategories = try c.decodeIfPresent([Subcategory].self, forKey: .subcategories) ?? []
        personGroups = try c.decodeIfPresent([PersonGroup].self, forKey: .personGroups) ?? []
        persons = try c.decodeIfPresent([Person].self, forKey: .persons) ?? []
        operations = try c.decodeIfPresent([OperationRecord].self, forKey: .operations) ?? []
        dailyPlan = try c.decodeIfPresent(Double.self, forKey: .dailyPlan)
        repairPersonGroups()
    }

    /// До появления категорий все лица лежали одной кучей — уводим их в «Общее».
    /// Сюда же попадают лица, чья категория была удалена.
    mutating func repairPersonGroups() {
        if personGroups.isEmpty {
            personGroups = [PersonGroup(name: PersonGroup.defaultName)]
        }
        let known = Set(personGroups.map { $0.id })
        let fallback = personGroups[0].id
        for i in persons.indices {
            if let g = persons[i].groupId, known.contains(g) { continue }
            persons[i].groupId = fallback
        }
    }

    // MARK: - Лица

    /// Сколько раз лицо встречается в сохранённых операциях
    func usageCount(_ personName: String) -> Int {
        guard !personName.isEmpty else { return 0 }
        var n = 0
        for op in operations where op.person == personName { n += 1 }
        return n
    }

    /// Счётчик сразу по всем лицам, за один проход по истории
    func personUsage() -> [String: Int] {
        var counts: [String: Int] = [:]
        for op in operations where !op.person.isEmpty {
            counts[op.person, default: 0] += 1
        }
        return counts
    }

    /// Порядок лиц: сначала закреплённые, потом по частотности, при равенстве — по алфавиту.
    /// Ручная сортировка здесь не нужна: порядок считается сам.
    ///
    /// Счётчик берём готовый: вызывать `usageCount` из сравнения значило бы
    /// перебирать всю историю заново на каждую пару.
    func personsOrdered(in groupId: UUID? = nil) -> [Person] {
        var list: [Person] = []
        if let groupId {
            for p in persons where p.groupId == groupId { list.append(p) }
        } else {
            list = persons
        }
        let counts = personUsage()
        list.sort { a, b in
            if a.isPinned != b.isPinned { return a.isPinned }
            let ua: Int = counts[a.name] ?? 0
            let ub: Int = counts[b.name] ?? 0
            if ua != ub { return ua > ub }
            return a.name.localizedStandardCompare(b.name) == .orderedAscending
        }
        return list
    }

    // MARK: - Остатки по счетам

    /// Остатки считаются по суммам КАК ВВЕДЕНЫ, включая операции «Не учитывать»:
    /// перевод между своими счетами не меняет общий баланс, но деньги со счёта
    /// действительно уходят, и в остатке это обязано быть видно.
    func accountBalances() -> [AccountBalance] {
        var map: [String: AccountBalance] = [:]
        func key(_ b: String, _ a: String, _ c: Currency) -> String { "\(b)|\(a)|\(c.rawValue)" }

        // Признак «закрыт» складываем заранее по паре банк+счёт: иначе его
        // пришлось бы искать перебором для каждой операции.
        var closedByAccount: [String: Bool] = [:]
        for acc in accounts {
            guard let bank = banks.first(where: { $0.id == acc.bankId }) else { continue }
            closedByAccount["\(bank.name)|\(acc.name)"] = acc.isClosed
            let k = key(bank.name, acc.name, acc.effectiveCurrency)
            map[k] = AccountBalance(bank: bank.name, account: acc.name,
                                    currency: acc.effectiveCurrency, total: 0, count: 0,
                                    closed: acc.isClosed)
        }
        for op in operations {
            let cur = op.effectiveCurrency
            let k = key(op.bank, op.account, cur)
            if var found = map[k] {
                found.total += op.amount
                found.count += 1
                map[k] = found
            } else {
                // Операция в валюте, отличной от валюты счёта, заводит отдельную
                // строку. Признак «закрыт» берём у самого счёта, иначе закрытый
                // счёт вылез бы наверх как открытый.
                let closed = closedByAccount["\(op.bank)|\(op.account)"] ?? false
                map[k] = AccountBalance(bank: op.bank, account: op.account, currency: cur,
                                        total: op.amount, count: 1, closed: closed)
            }
        }
        return map.values.sorted { a, b in
            if a.closed != b.closed { return !a.closed }
            if a.bank != b.bank { return a.bank.localizedStandardCompare(b.bank) == .orderedAscending }
            if a.account != b.account {
                return a.account.localizedStandardCompare(b.account) == .orderedAscending
            }
            return a.currency.rawValue < b.currency.rawValue
        }
    }

    /// Тип операции берётся из справочника по названию, которое сохранено в записи.
    /// Если такой операции в справочнике уже нет — определяем по названию.
    func kind(of record: OperationRecord) -> OpKind {
        optypes.first { $0.name == record.operation }?.effectiveKind
            ?? OpKind.guessed(fromName: record.operation)
    }

    func isIncome(_ record: OperationRecord) -> Bool { kind(of: record) == .income }
    func isExpense(_ record: OperationRecord) -> Bool { kind(of: record) == .expense }

    /// Сумма для подсчётов. Знак задаёт сам пользователь при вводе и он НЕ меняется:
    /// «Доход»/«Расход» — это только группировка в статистике. «Не учитывать» —
    /// единственный тип, который из подсчёта исключается.
    func signedAmount(_ record: OperationRecord) -> Double {
        kind(of: record) == .neutral ? 0 : record.amount
    }
}

// MARK: - Форматирование дат

/// Даты и время всегда в фиксированном формате, независимо от настроек iPhone
/// (12/24-часовой формат, буддийский/японский календарь и т.п.).
nonisolated enum DateFmt {
    private static func make(_ format: String) -> DateFormatter {
        let f = DateFormatter()
        f.locale = Locale(identifier: "en_US_POSIX")
        f.calendar = Calendar(identifier: .gregorian)
        f.timeZone = TimeZone.current
        f.dateFormat = format
        return f
    }

    /// Форматтеры создаются один раз: построение отчёта перебирает дни
    /// тысячами, а каждый новый `DateFormatter` стоит дорого. Всё это
    /// вызывается с главного потока, так что общий экземпляр безопасен.
    private static let dayFmt = make("yyyy-MM-dd")
    private static let timeFmt = make("HH:mm")
    private static let stampFmt = make("yyyy-MM-dd_HHmm")

    static func dayString(_ d: Date) -> String { dayFmt.string(from: d) }
    static func timeString(_ d: Date) -> String { timeFmt.string(from: d) }
    static func fileStamp(_ d: Date) -> String { stampFmt.string(from: d) }
    static func day(from s: String) -> Date? { s.isEmpty ? nil : dayFmt.date(from: s) }
    static func time(from s: String) -> Date? { s.isEmpty ? nil : timeFmt.date(from: s) }

    /// "2026-09-15" → "15.09.2026" для показа на экране
    static func display(_ s: String) -> String {
        let parts = s.split(separator: "-")
        guard parts.count == 3 else { return s }
        return "\(parts[2]).\(parts[1]).\(parts[0])"
    }

    /// "2026-09-15" → "Сегодня" / "Вчера" / "15 сентября" / "15 сентября 2025"
    static func humanDay(_ s: String, today: Date = Date()) -> String {
        let parts = s.split(separator: "-")
        guard parts.count == 3, let m = Int(parts[1]), (1...12).contains(m), let d = Int(parts[2]) else { return s }
        let todayStr = dayString(today)
        if s == todayStr { return "Сегодня" }
        if let y = Calendar(identifier: .gregorian).date(byAdding: .day, value: -1, to: today), s == dayString(y) {
            return "Вчера"
        }
        let names = ["января", "февраля", "марта", "апреля", "мая", "июня",
                     "июля", "августа", "сентября", "октября", "ноября", "декабря"]
        let year = String(parts[0])
        return year == String(todayStr.prefix(4)) ? "\(d) \(names[m - 1])" : "\(d) \(names[m - 1]) \(year)"
    }

    /// "2026-09-21" → "21.09", а с годом — "21.09.26"
    static func compact(_ s: String, withYear: Bool = false) -> String {
        let p = s.split(separator: "-")
        guard p.count == 3 else { return s }
        let short = "\(p[2]).\(p[1])"
        if !withYear { return short }
        return short + "." + String(p[0].suffix(2))
    }

    static let monthShortNames = ["янв", "фев", "мар", "апр", "май", "июн",
                                  "июл", "авг", "сен", "окт", "ноя", "дек"]

    /// "2026-09" → "сен 26"
    static func monthShort(_ ym: String) -> String {
        let p = ym.split(separator: "-")
        guard p.count >= 2, let m = Int(p[1]), (1...12).contains(m) else { return ym }
        return monthShortNames[m - 1] + " " + String(p[0].suffix(2))
    }

    /// "2026-09" → "Сентябрь 2026"
    static func monthTitle(_ ym: String) -> String {
        let names = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
                     "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]
        let parts = ym.split(separator: "-")
        guard parts.count == 2, let m = Int(parts[1]), (1...12).contains(m) else { return ym }
        return "\(names[m - 1]) \(parts[0])"
    }
}

// MARK: - Деньги

nonisolated enum Money {
    /// Настоящий минус (−, U+2212) вместо дефиса — он одной ширины с цифрами
    static let minus = "\u{2212}"

    /// "1 234,56 ₽" — сумма со знаком валюты
    static func format(_ value: Double, _ currency: Currency) -> String {
        format(value) + "\u{00A0}" + currency.symbol
    }

    /// "1 234,56" или "−1 234,56" — для показа на экране
    static func format(_ value: Double) -> String {
        let f = NumberFormatter()
        f.locale = Locale(identifier: "ru_RU")
        f.numberStyle = .decimal
        f.minimumFractionDigits = 2
        f.maximumFractionDigits = 2
        let s = f.string(from: NSNumber(value: abs(value))) ?? String(format: "%.2f", abs(value))
        return value < 0 ? minus + s : s
    }

    /// Разбор введённой суммы: понимает "1234,56", "1 234.56", "−1 234,5", "-500".
    /// Возвращает nil, если это не число.
    static func parse(_ text: String) -> Double? {
        var s = text.trimmingCharacters(in: .whitespacesAndNewlines)
        for sp in [" ", "\u{00A0}", "\u{202F}"] { s = s.replacingOccurrences(of: sp, with: "") }
        s = s.replacingOccurrences(of: ",", with: ".")
        s = s.replacingOccurrences(of: minus, with: "-")
        var negative = false
        if s.hasPrefix("-") { negative = true; s.removeFirst() }
        else if s.hasPrefix("+") { s.removeFirst() }
        guard !s.isEmpty,
              s.allSatisfy({ $0.isASCII && ($0.isNumber || $0 == ".") }),
              s.filter({ $0 == "." }).count <= 1,
              let v = Double(s), v.isFinite else { return nil }
        let rounded = (v * 100).rounded() / 100
        return negative ? -rounded : rounded
    }

    /// Сумма для подстановки в поле при редактировании: "50 000" или "1 234,56".
    /// Знак в поле не пишется — им управляет отдельная кнопка «плюс/минус».
    static func editString(_ value: Double) -> String {
        let v = abs(value)
        if v == v.rounded() { return groupInput(String(format: "%.0f", v)) }
        let s = String(format: "%.2f", v).replacingOccurrences(of: ".", with: ",")
        return groupInput(s)
    }

    /// Узкий неразрывный пробел между разрядами: он уже обычного и не
    /// переносится, поэтому число не разваливается на две строки.
    static let groupSpace = "\u{202F}"

    /// Приводит то, что человек набрал, к виду «1 234,56»: лишние символы
    /// выбрасываются, разряды разделяются пробелом, копеек не больше двух.
    /// Вызывается на каждое нажатие клавиши, поэтому без словарей и регулярок.
    static func groupInput(_ raw: String) -> String {
        var whole = ""
        var fraction = ""
        var afterComma = false
        for ch in raw {
            if ch.isNumber {
                if afterComma {
                    if fraction.count < 2 { fraction.append(ch) }
                } else {
                    whole.append(ch)
                }
            } else if ch == "," || ch == "." {
                afterComma = true
            }
        }
        while whole.count > 1 && whole.hasPrefix("0") { whole.removeFirst() }

        var grouped = ""
        let digits = Array(whole)
        let total = digits.count
        for i in 0..<total {
            if i > 0 && (total - i) % 3 == 0 { grouped += groupSpace }
            grouped.append(digits[i])
        }
        if !afterComma { return grouped }
        return grouped + "," + fraction
    }
}
