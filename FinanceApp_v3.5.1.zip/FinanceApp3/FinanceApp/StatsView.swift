import SwiftUI

/// Корень вкладки «Статистика».
///
/// Наверху — единственное табло: доходы, расходы и разница за выбранный
/// период. Всё остальное разложено по отчётам: каждый открывается
/// отдельным экраном со своими настройками, чтобы вкладка не превращалась
/// в бесконечную ленту графиков.
struct StatsView: View {
    @EnvironmentObject var appState: AppState

    @State private var span: DateSpan = DateSpan.make(.month)
    @State private var pickedCurrency: Currency? = nil

    var body: some View {
        let currencies: [Currency] = appState.data.currenciesUsed()
        let currency: Currency = Self.resolve(pickedCurrency, among: currencies)

        List {
            Section {
                ScreenHeader(title: "Статистика")
            }
            .plainRow()

            Section {
                PeriodBar(span: $span)
            }

            if currencies.count > 1 {
                Section {
                    Picker("Валюта", selection: currencyBinding(currencies)) {
                        ForEach(currencies) { c in Text(c.symbol + " " + c.code).tag(c) }
                    }
                    .pickerStyle(.segmented)
                }
            }

            heroSection(currency)
            reportsSection
        }
        .themedScreen()
        .navigationDestination(for: ReportRoute.self) { route in
            reportScreen(route, currency: currency)
        }
    }

    /// Выбранная валюта или самая частая. Отдельной функцией, а не
    /// выражением в теле: цепочки с `??` внутри ViewBuilder компилятор
    /// разбирает непозволительно долго.
    private static func resolve(_ picked: Currency?, among list: [Currency]) -> Currency {
        if let picked, list.contains(picked) { return picked }
        if let first = list.first { return first }
        return .rub
    }

    private func currencyBinding(_ list: [Currency]) -> Binding<Currency> {
        Binding(get: { Self.resolve(pickedCurrency, among: list) },
                set: { pickedCurrency = $0 })
    }

    // MARK: - Табло

    @ViewBuilder
    private func heroSection(_ currency: Currency) -> some View {
        let totals = appState.data.sums(in: span, currency: currency)
        let balance: Double = totals.income + totals.expense
        Section {
            VStack(alignment: .leading, spacing: Theme.gap) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(span.title)
                        .font(Theme.caption)
                        .foregroundStyle(.secondary)
                    Text(Money.format(balance, currency))
                        .font(Theme.display)
                        .foregroundStyle(balance < 0 ? Color.red : Color.primary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
                HStack(spacing: Theme.gap) {
                    StatTile(title: "Доходы", value: totals.income,
                             currency: currency, color: Theme.income, symbol: "arrow.down")
                    StatTile(title: "Расходы", value: totals.expense,
                             currency: currency, color: Theme.expense, symbol: "arrow.up")
                }
            }
        }
    }

    // MARK: - Отчёты

    private var reportsSection: some View {
        Section {
            ForEach(ReportRoute.allCases) { route in
                NavigationLink(value: route) {
                    ReportRow(route: route)
                }
                .accessibilityIdentifier("report_" + route.rawValue)
            }
        } header: {
            Text("Отчёты")
        } footer: {
            Text("Период табло и период отчёта задаются независимо: отчёт открывается с текущим периодом, но внутри его можно сменить.")
        }
    }

    @ViewBuilder
    private func reportScreen(_ route: ReportRoute, currency: Currency) -> some View {
        switch route {
        case .dynamics:   DynamicsReport(initial: span, currency: currency)
        case .categories: SharesReport(initial: span, currency: currency, mode: .categories)
        case .persons:    SharesReport(initial: span, currency: currency, mode: .persons)
        case .accounts:   AccountsReport(initial: span, currency: currency)
        case .largest:    LargestReport(initial: span, currency: currency)
        }
    }
}

// MARK: - Список отчётов

nonisolated enum ReportRoute: String, CaseIterable, Identifiable, Hashable {
    case dynamics, categories, persons, accounts, largest

    var id: String { rawValue }

    var title: String {
        switch self {
        case .dynamics:   return "Динамика поступлений и платежей"
        case .categories: return "Структура по категориям"
        case .persons:    return "Структура по контрагентам"
        case .accounts:   return "Обороты и остатки на счетах"
        case .largest:    return "Крупнейшие операции"
        }
    }

    var note: String {
        switch self {
        case .dynamics:   return "График по дням, неделям, месяцам или годам с дневным планом"
        case .categories: return "Доли категорий в доходах и в платежах"
        case .persons:    return "Доли контрагентов в доходах и в платежах"
        case .accounts:   return "Движение за период и остаток по каждому счёту"
        case .largest:    return "Самые крупные записи периода"
        }
    }

    var symbol: String {
        switch self {
        case .dynamics:   return "chart.bar.fill"
        case .categories: return "chart.pie.fill"
        case .persons:    return "person.2.fill"
        case .accounts:   return "building.columns.fill"
        case .largest:    return "arrow.up.arrow.down"
        }
    }

    var color: Color {
        switch self {
        case .dynamics:   return .blue
        case .categories: return .purple
        case .persons:    return .teal
        case .accounts:   return .indigo
        case .largest:    return .orange
        }
    }
}

/// Строка отчёта: та же высота и те же поля, что у строк справочников.
struct ReportRow: View {
    let route: ReportRoute

    var body: some View {
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: route.symbol, color: route.color)
            VStack(alignment: .leading, spacing: 2) {
                Text(route.title).font(Theme.body).lineLimit(1)
                Text(route.note)
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
        }
        .padding(.vertical, 2)
    }
}

/// Плитка «Доходы» / «Расходы» под крупной суммой.
struct StatTile: View {
    let title: String
    let value: Double
    let currency: Currency
    let color: Color
    let symbol: String

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Label(title, systemImage: symbol)
                .font(Theme.caption)
                .foregroundStyle(color)
            Text(Money.format(value, currency))
                .font(Theme.subtitle.monospacedDigit())
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
        .padding(Theme.gap)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(color.opacity(0.1), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }
}
