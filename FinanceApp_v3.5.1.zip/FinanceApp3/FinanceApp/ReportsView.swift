import SwiftUI
import Charts

// MARK: - Выбор периода

/// Переключатель периода: сначала быстрые варианты, ниже — строка
/// произвольного отрезка. Один и тот же на табло и во всех отчётах.
struct PeriodBar: View {
    @Binding var span: DateSpan
    @State private var showCustom = false

    var body: some View {
        VStack(alignment: .leading, spacing: Theme.gap) {
            Picker("Период", selection: presetBinding) {
                ForEach(PeriodPreset.quick) { p in Text(p.title).tag(p) }
            }
            .pickerStyle(.segmented)

            Button {
                showCustom = true
            } label: {
                HStack(spacing: Theme.gap) {
                    Text("Произвольный период").font(Theme.body).foregroundStyle(Color.primary)
                    Spacer(minLength: Theme.gap)
                    Text(span.title)
                        .font(Theme.caption)
                        .foregroundStyle(span.preset == .custom ? Color.accentColor : .secondary)
                        .lineLimit(1)
                }
            }
            .buttonStyle(.plain)
            .accessibilityIdentifier("customPeriod")
        }
        .sheet(isPresented: $showCustom) {
            CustomPeriodSheet(span: $span)
        }
    }

    private var presetBinding: Binding<PeriodPreset> {
        Binding(get: { span.preset }, set: { span = DateSpan.make($0) })
    }
}

/// Две даты и кнопка «Применить». Отдельным окном, чтобы календари
/// не распирали экран отчёта.
struct CustomPeriodSheet: View {
    @Binding var span: DateSpan
    @Environment(\.dismiss) private var dismiss

    @State private var from: Date = Date()
    @State private var to: Date = Date()

    var body: some View {
        NavigationStack {
            List {
                Section {
                    DatePicker("С", selection: $from, displayedComponents: .date)
                        .font(Theme.body)
                    DatePicker("По", selection: $to, displayedComponents: .date)
                        .font(Theme.body)
                } footer: {
                    Text("Границы включаются в расчёт. Если начало позже конца, даты меняются местами.")
                }
            }
            .themedList()
            .navigationTitle("Период")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }.font(Theme.body)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Применить") { apply() }.font(Theme.body.weight(.semibold))
                }
            }
        }
        .onAppear {
            from = span.from
            to = span.to
        }
    }

    private func apply() {
        var result = DateSpan(preset: .custom, from: from, to: to)
        if result.fromKey > result.toKey {
            result = DateSpan(preset: .custom, from: to, to: from)
        }
        span = result
        dismiss()
    }
}

// MARK: - Динамика поступлений и платежей

struct DynamicsReport: View {
    @EnvironmentObject var appState: AppState
    let initial: DateSpan
    let currency: Currency

    @State private var span: DateSpan = DateSpan.make(.month)
    @State private var step: Granularity = .day
    @State private var planText: String = ""
    @State private var loaded = false

    // Готовые массивы, а не склейка на месте: тернарник с `+` и литералом
    // внутри вызова с двумя обобщёнными параметрами — ровно та форма, на
    // которой проверка типов в этом проекте уже дважды упиралась в лимит.
    private static let base: [String] = ["Поступления", "Платежи"]
    private static let baseColors: [Color] = [Theme.income, Theme.expenseBar]
    private static let withPlan: [String] = ["Поступления", "Платежи", "План"]
    private static let withPlanColors: [Color] = [Theme.income, Theme.expenseBar, Color.gray]

    var body: some View {
        let buckets: [Bucket] = appState.data.buckets(span: span, step: step, currency: currency)
        let plan: Double? = Money.parse(planText).map { abs($0) }

        List {
            Section { PeriodBar(span: $span) }

            Section {
                Picker("Шаг", selection: $step) {
                    ForEach(Granularity.allCases) { g in Text(g.title).tag(g) }
                }
                .pickerStyle(.segmented)
            }

            Section {
                if buckets.isEmpty {
                    Text("За выбранный период данных нет.")
                        .font(Theme.body)
                        .foregroundStyle(.secondary)
                } else {
                    chart(Self.visible(buckets), plan: plan)
                        .frame(height: 260)
                        .padding(.vertical, Theme.gap)
                }
            } footer: {
                Text(Self.chartFooter(buckets))
            }

            planSection(buckets)
            totalsSection(buckets)
        }
        .themedList()
        .navigationTitle("Динамика")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear(perform: load)
        .onDisappear { appState.persist() }
    }

    private func load() {
        guard !loaded else { return }
        loaded = true
        span = initial
        if let saved = appState.data.dailyPlan, saved > 0 {
            planText = Money.editString(saved)
        }
    }

    // MARK: График

    private func chart(_ buckets: [Bucket], plan: Double?) -> some View {
        Chart {
            ForEach(buckets) { b in
                bars(b)
            }
            planLine(buckets, plan: plan)
        }
        .chartForegroundStyleScale(domain: plan == nil ? Self.base : Self.withPlan,
                                   range: plan == nil ? Self.baseColors : Self.withPlanColors)
        .chartLegend(position: .top, alignment: .leading)
        .chartXAxis { AxisMarks(values: Self.labels(buckets)) { _ in AxisValueLabel() } }
        .chartYAxis {
            AxisMarks(position: .trailing) { _ in
                AxisGridLine(stroke: StrokeStyle(lineWidth: 0.5, dash: [3]))
                AxisValueLabel()
            }
        }
    }

    @ChartContentBuilder
    private func bars(_ b: Bucket) -> some ChartContent {
        BarMark(x: .value("Период", b.label),
                y: .value("Сумма", abs(b.income)),
                width: .ratio(0.8))
            .cornerRadius(3)
            .foregroundStyle(by: .value("Тип", "Поступления"))
            .position(by: .value("Тип", "Поступления"))
        BarMark(x: .value("Период", b.label),
                y: .value("Сумма", abs(b.expense)),
                width: .ratio(0.8))
            .cornerRadius(3)
            .foregroundStyle(by: .value("Тип", "Платежи"))
            .position(by: .value("Тип", "Платежи"))
    }

    @ChartContentBuilder
    private func planLine(_ buckets: [Bucket], plan: Double?) -> some ChartContent {
        if let plan, plan > 0 {
            ForEach(buckets) { b in
                LineMark(x: .value("Период", b.label),
                         y: .value("Сумма", plan * Double(max(b.days, 1))))
                    .lineStyle(StrokeStyle(lineWidth: 2, dash: [5, 4]))
                    .foregroundStyle(by: .value("Тип", "План"))
            }
        }
    }

    /// Сколько столбцов помещается на графике, не превращаясь в частокол.
    static let maxBars: Int = 120

    /// На графике — последние корзины: при шаге «Дни» и длинном отрезке
    /// их могут быть тысячи, и Charts на таком объёме встаёт.
    private static func visible(_ buckets: [Bucket]) -> [Bucket] {
        guard buckets.count > maxBars else { return buckets }
        return Array(buckets.suffix(maxBars))
    }

    private static func chartFooter(_ buckets: [Bucket]) -> String {
        let common = "Поступления и платежи показаны величиной, без знака: зелёные столбцы — приход, красные — расход."
        guard buckets.count > maxBars else { return common }
        return common + " Столбцов слишком много — показаны последние \(maxBars); для полной картины укрупните шаг."
    }

    /// Подписи оси: при длинном отрезке оставляем примерно восемь штук,
    /// иначе они наезжают друг на друга.
    private static func labels(_ buckets: [Bucket]) -> [String] {
        guard buckets.count > 8 else {
            var all: [String] = []
            for b in buckets { all.append(b.label) }
            return all
        }
        let stride: Int = Int((Double(buckets.count) / 8.0).rounded(.up))
        var result: [String] = []
        var i: Int = 0
        while i < buckets.count {
            result.append(buckets[i].label)
            i += max(stride, 1)
        }
        return result
    }

    // MARK: План

    @ViewBuilder
    private func planSection(_ buckets: [Bucket]) -> some View {
        Section {
            HStack(spacing: Theme.gap) {
                IconBadge(symbol: "target", color: .gray)
                Text("Дневной план").font(Theme.body)
                Spacer(minLength: Theme.gap)
                TextField("не задан", text: planBinding)
                    .keyboardType(.decimalPad)
                    .multilineTextAlignment(.trailing)
                    .font(Theme.body.monospacedDigit())
                    .frame(maxWidth: 140)
                    .accessibilityIdentifier("planField")
                Text(currency.symbol).font(Theme.body).foregroundStyle(.secondary)
            }
        } footer: {
            Text(planFooter(buckets))
        }
    }

    /// Пишем план в память на каждое нажатие, а на диск — один раз, когда
    /// экран закрывается: шифровать файл на каждую цифру незачем.
    private var planBinding: Binding<String> {
        Binding(get: { planText }, set: { newValue in
            planText = Money.groupInput(newValue)
            appState.data.dailyPlan = Money.parse(planText).map { abs($0) }
        })
    }

    private func planFooter(_ buckets: [Bucket]) -> String {
        guard let plan = Money.parse(planText), plan > 0 else {
            return "План расходов на один день. Серая линия на графике показывает его в пересчёте на выбранный шаг."
        }
        var over: Int = 0
        for b in buckets where abs(b.expense) > plan * Double(max(b.days, 1)) { over += 1 }
        if buckets.isEmpty { return "План расходов на один день." }
        return "Превышений плана за период: \(over) из \(buckets.count)."
    }

    // MARK: Итоги

    @ViewBuilder
    private func totalsSection(_ buckets: [Bucket]) -> some View {
        let totals = Self.totals(buckets)
        if !buckets.isEmpty {
            Section {
                TotalRow(title: "Поступления", value: totals.income, currency: currency)
                TotalRow(title: "Платежи", value: totals.expense, currency: currency)
                TotalRow(title: "Разница", value: totals.income + totals.expense,
                         currency: currency, strong: true)
                TotalRow(title: "В среднем за шаг",
                         value: totals.expense / Double(max(buckets.count, 1)),
                         currency: currency)
            } header: {
                Text("Итоги периода")
            }
        }
    }

    private static func totals(_ buckets: [Bucket]) -> (income: Double, expense: Double) {
        var income: Double = 0
        var expense: Double = 0
        for b in buckets {
            income += b.income
            expense += b.expense
        }
        return (income, expense)
    }
}

// MARK: - Структура по категориям и контрагентам

nonisolated enum SharesMode {
    case categories, persons

    var title: String {
        switch self {
        case .categories: return "Категории"
        case .persons:    return "Контрагенты"
        }
    }

    var empty: String {
        switch self {
        case .categories: return "За выбранный период операций нет."
        case .persons:    return "За выбранный период операций с контрагентами нет."
        }
    }
}

struct SharesReport: View {
    @EnvironmentObject var appState: AppState
    let initial: DateSpan
    let currency: Currency
    let mode: SharesMode

    @State private var span: DateSpan = DateSpan.make(.month)
    @State private var loaded = false

    var body: some View {
        let ops: [OperationRecord] = appState.data.records(in: span, currency: currency)
        let split = Self.split(ops, data: appState.data, mode: mode)
        let expense: [ShareRow] = appState.data.shares(split.expense, by: key, limit: 7)
        let income: [ShareRow] = appState.data.shares(split.income, by: key, limit: 7)

        List {
            Section { PeriodBar(span: $span) }

            if expense.isEmpty && income.isEmpty {
                Section {
                    Text(mode.empty).font(Theme.body).foregroundStyle(.secondary)
                }
            }

            if !expense.isEmpty {
                Section("Платежи") {
                    Donut(rows: expense, currency: currency)
                    ShareLegend(rows: expense, currency: currency)
                }
            }

            if !income.isEmpty {
                Section("Поступления") {
                    Donut(rows: income, currency: currency)
                    ShareLegend(rows: income, currency: currency)
                }
            }
        }
        .themedList()
        .navigationTitle(mode.title)
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            guard !loaded else { return }
            loaded = true
            span = initial
        }
    }

    private var key: (OperationRecord) -> String {
        switch mode {
        case .categories: return { $0.category }
        case .persons:    return { $0.person }
        }
    }

    /// Один проход вместо двух `filter`: и быстрее, и компилятору проще.
    private static func split(_ ops: [OperationRecord], data: AppData,
                              mode: SharesMode) -> (income: [OperationRecord], expense: [OperationRecord]) {
        var income: [OperationRecord] = []
        var expense: [OperationRecord] = []
        for op in ops {
            if mode == .persons && op.person.isEmpty { continue }
            let kind = data.kind(of: op)
            if kind == .income { income.append(op) }
            else if kind == .expense { expense.append(op) }
        }
        return (income, expense)
    }
}

/// Круговая диаграмма долей. Угол считается по величине суммы: знак на
/// долю не влияет.
struct Donut: View {
    let rows: [ShareRow]
    let currency: Currency

    var body: some View {
        Chart(Array(rows.enumerated()), id: \.element.id) { index, row in
            SectorMark(angle: .value("Сумма", abs(row.value)),
                       innerRadius: .ratio(0.64),
                       angularInset: 1.5)
                .cornerRadius(4)
                .foregroundStyle(Theme.color(at: index))
        }
        .chartBackground { _ in
            VStack(spacing: 2) {
                Text("Всего").font(Theme.caption).foregroundStyle(.secondary)
                Text(Money.format(Donut.sum(rows), currency))
                    .font(Theme.subtitle.monospacedDigit())
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                    .frame(maxWidth: 130)
            }
        }
        .frame(height: 210)
        .padding(.vertical, Theme.gap)
    }

    /// Число в центре круга — обычный итог со знаком.
    static func sum(_ rows: [ShareRow]) -> Double {
        var total: Double = 0
        for r in rows { total += r.value }
        return total
    }
}

/// Список под диаграммой: цвет, название, доля и сумма.
struct ShareLegend: View {
    let rows: [ShareRow]
    let currency: Currency

    var body: some View {
        let total: Double = AppData.absSum(rows)
        ForEach(Array(rows.enumerated()), id: \.element.id) { index, row in
            HStack(spacing: Theme.gap) {
                Circle().fill(Theme.color(at: index)).frame(width: 10, height: 10)
                Text(row.name).font(Theme.body).lineLimit(1)
                Spacer(minLength: Theme.gap)
                Text(ShareLegend.percent(row.value, of: total))
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
                    .monospacedDigit()
                Text(Money.format(row.value, currency))
                    .font(Theme.body)
                    .monospacedDigit()
            }
        }
    }

    static func percent(_ value: Double, of total: Double) -> String {
        guard abs(total) > 0 else { return "" }
        let share: Double = abs(value) / abs(total) * 100
        return "\(Int(share.rounded())) %"
    }
}

// MARK: - Обороты и остатки

struct AccountsReport: View {
    @EnvironmentObject var appState: AppState
    let initial: DateSpan
    let currency: Currency

    @State private var span: DateSpan = DateSpan.make(.month)
    @State private var loaded = false

    var body: some View {
        let turnovers: [AccountTurnover] = appState.data.accountTurnovers(span: span, currency: currency)
        let balances: [AccountBalance] = appState.data.accountBalances()

        List {
            Section { PeriodBar(span: $span) }

            Section {
                if turnovers.isEmpty {
                    Text("За выбранный период движения по счетам не было.")
                        .font(Theme.body)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(turnovers) { t in
                        AccountLine(bank: t.bank, account: t.account,
                                    note: "операций: \(t.count)",
                                    value: t.total, currency: t.currency, dimmed: false)
                    }
                }
            } header: {
                Text("Обороты за период")
            } footer: {
                Text("Сумма всех операций счёта за период, включая переводы между своими счетами.")
            }

            Section {
                ForEach(balances) { b in
                    AccountLine(bank: b.bank, account: b.account,
                                note: b.closed ? "закрыт" : nil,
                                value: b.total, currency: b.currency, dimmed: b.closed)
                }
            } header: {
                Text("Остатки на счетах")
            } footer: {
                Text("Остаток рассчитывается по всей истории и не зависит от выбранного периода.")
            }
        }
        .themedList()
        .navigationTitle("Счета")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            guard !loaded else { return }
            loaded = true
            span = initial
        }
    }
}

/// Строка «банк · счёт — сумма». Одинаковая в обеих таблицах.
struct AccountLine: View {
    let bank: String
    let account: String
    var note: String? = nil
    let value: Double
    let currency: Currency
    var dimmed: Bool = false

    var body: some View {
        HStack(spacing: Theme.gap) {
            VStack(alignment: .leading, spacing: 2) {
                Text(bank).font(Theme.body).lineLimit(1)
                Text(subtitle).font(Theme.caption).foregroundStyle(.secondary).lineLimit(1)
            }
            Spacer(minLength: Theme.gap)
            Text(Money.format(value, currency))
                .font(Theme.subtitle)
                .monospacedDigit()
                .foregroundStyle(value < 0 ? Color.red : Color.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
        .padding(.vertical, 2)
        .opacity(dimmed ? 0.5 : 1)
    }

    private var subtitle: String {
        guard let note, !note.isEmpty else { return account }
        return account + " · " + note
    }
}

// MARK: - Крупнейшие операции

struct LargestReport: View {
    @EnvironmentObject var appState: AppState
    let initial: DateSpan
    let currency: Currency

    @State private var span: DateSpan = DateSpan.make(.month)
    @State private var loaded = false

    var body: some View {
        let rows: [OperationRecord] = Self.top(appState.data.records(in: span, currency: currency))

        List {
            Section { PeriodBar(span: $span) }

            Section {
                if rows.isEmpty {
                    Text("За выбранный период операций нет.")
                        .font(Theme.body)
                        .foregroundStyle(.secondary)
                } else {
                    ForEach(rows) { rec in
                        RecordRow(rec: rec, kind: appState.data.kind(of: rec))
                    }
                }
            } header: {
                Text("Двадцать крупнейших")
            } footer: {
                Text("Записи отсортированы по величине суммы, без учёта знака.")
            }
        }
        .themedList()
        .navigationTitle("Крупнейшие")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            guard !loaded else { return }
            loaded = true
            span = initial
        }
    }

    private static func top(_ ops: [OperationRecord]) -> [OperationRecord] {
        var list: [OperationRecord] = ops
        list.sort(by: LargestReport.byAmount)
        guard list.count > 20 else { return list }
        return Array(list.prefix(20))
    }

    private static func byAmount(_ a: OperationRecord, _ b: OperationRecord) -> Bool {
        let ma: Double = abs(a.amount)
        let mb: Double = abs(b.amount)
        if ma != mb { return ma > mb }
        return a.date > b.date
    }
}

/// Итоговая строка отчёта.
struct TotalRow: View {
    let title: String
    let value: Double
    let currency: Currency
    var strong: Bool = false

    var body: some View {
        HStack(spacing: Theme.gap) {
            Text(title).font(Theme.body)
            Spacer(minLength: Theme.gap)
            Text(Money.format(value, currency))
                .font(strong ? Theme.subtitle.monospacedDigit() : Theme.body.monospacedDigit())
                .foregroundStyle(value < 0 ? Color.red : Color.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
    }
}
