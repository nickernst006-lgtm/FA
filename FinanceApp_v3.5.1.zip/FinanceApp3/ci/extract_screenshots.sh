#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
mkdir -p screenshots
if [ -d results/ui.xcresult ]; then
  xcrun xcresulttool export attachments --path results/ui.xcresult --output-path _att || true
  python3 - <<'EOF2'
import json, os, re, shutil
src_dir, dst_dir = "_att", "screenshots"
names = {}
try:
    for test in json.load(open(os.path.join(src_dir, "manifest.json"))):
        for a in test.get("attachments", []):
            names[a["exportedFileName"]] = a.get("suggestedHumanReadableName") or a["exportedFileName"]
except Exception as e:
    print("manifest:", e)
n = 0
for f in sorted(os.listdir(src_dir)) if os.path.isdir(src_dir) else []:
    if not f.lower().endswith((".png", ".jpg", ".jpeg")):
        continue
    name = names.get(f, f)
    name = name.split("_0_")[0]
    base, ext = os.path.splitext(name)
    if not ext: ext = os.path.splitext(f)[1] or ".png"
    # только безопасные символы (двоеточия и т.п. ломают выгрузку артефакта)
    base = re.sub(r'[^0-9A-Za-zА-Яа-яЁё_\-]+', "_", base).strip("_") or "screenshot"
    dst = os.path.join(dst_dir, base + ext)
    i = 2
    while os.path.exists(dst):
        dst = os.path.join(dst_dir, f"{base}_{i}{ext}"); i += 1
    shutil.copy(os.path.join(src_dir, f), dst); n += 1
print("Скриншотов:", n)
EOF2
fi
ls -la screenshots
