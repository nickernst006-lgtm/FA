#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
set -o pipefail
FMT=cat; command -v xcbeautify >/dev/null && FMT=xcbeautify
xcodebuild test \
  -project FinanceApp.xcodeproj -scheme FinanceApp \
  -destination "id=$SIM_UDID" \
  -only-testing:FinanceAppUITests \
  -resultBundlePath results/ui.xcresult \
  2>&1 | tee ui-tests.log | $FMT
