#!/bin/bash
# Итоговая таблица на странице запуска. Статусы шагов приходят через переменные окружения.
st() { case "$1" in success) echo "✅";; failure) echo "❌ ОШИБКА";; skipped|"") echo "— не выполнялось";; *) echo "$1";; esac; }
{
  echo "## Результат"
  echo "| Шаг | Итог |"
  echo "|---|---|"
  echo "| Файлы на месте | $(st "$S_PREP") |"
  echo "| Xcode | $(st "$S_XCODE") |"
  echo "| Проект Xcode | $(st "$S_GEN") |"
  echo "| Компиляция для iPhone | $(st "$S_COMPILE") |"
  echo "| Юнит-тесты | $(st "$S_UNIT") |"
  echo "| UI-тесты и скриншоты | $(st "$S_UI") |"
  echo ""
  if ls *.log >/dev/null 2>&1; then
    ERR=$(grep -hE "error:|: error|XCTAssert|Failed to|failed -|\) failed" *.log | grep -vE "^\s*$|Test Suite|TEST FAILED|^[0-9]{4}-[0-9]{2}-[0-9]{2} " | sort -u | head -30)
    if [ -n "$ERR" ]; then
      echo "### Ошибки"
      echo '```'
      echo "$ERR" | cut -c1-300
      echo '```'
    fi
  fi
  N=$(ls screenshots 2>/dev/null | grep -ciE '\.(png|jpe?g)$')
  echo "Скриншотов: ${N:-0}. Файлы — внизу страницы, в разделе **Artifacts**."
} >> "$GITHUB_STEP_SUMMARY"
