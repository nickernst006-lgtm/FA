#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
mkdir -p Payload
cp -R build/Build/Products/Release-iphoneos/FinanceApp.app Payload/
zip -qry FinanceApp-unsigned.ipa Payload
ls -la FinanceApp-unsigned.ipa
