#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
set -o pipefail
FMT=cat; command -v xcbeautify >/dev/null && FMT=xcbeautify
xcodebuild test \
  -project FinanceApp.xcodeproj -scheme FinanceApp \
  -destination "id=$SIM_UDID" \
  -only-testing:FinanceAppTests \
  -resultBundlePath results/unit.xcresult \
  2>&1 | tee unit-tests.log | $FMT
