#!/bin/bash
# Шаг облачной сборки (вызывается из .github/workflows/build.yml)
zip -qry FinanceApp-Xcode-project.zip FinanceApp FinanceApp.xcodeproj FinanceAppTests FinanceAppUITests project.yml README.md ci || true
