import SwiftUI

/// Единая дизайн-система приложения (в духе Apple Human Interface Guidelines).
///
/// Размеров текста ровно ЧЕТЫРЕ, один шрифт (системный SF):
///   • `Theme.title`    — крупный: заголовки разделов и экранов;
///   • `Theme.subtitle` — средний: важные подзаголовки и названия строк;
///   • `Theme.body`     — малый: обычный текст;
///   • `Theme.caption`  — очень малый: уточнения и подписи серым.
/// Плюс один отдельный размер `Theme.display` — только для крупных цифр
/// (сумма в форме, баланс в статистике). Это не текст, а табло.
///
/// Отступы — один шаг сетки `Theme.gap` и одинаковое расстояние между блоками.
enum Theme {
    // Типографика: четыре размера и ничего кроме них
    static let title: Font = .title2.weight(.semibold)
    static let subtitle: Font = .headline
    static let body: Font = .body
    static let caption: Font = .subheadline

    /// Табло для крупных чисел. Один размер на всё приложение.
    static let display: Font = .system(size: 40, weight: .bold).monospacedDigit()

    // Отступы
    static let gap: CGFloat = 12             // между элементами внутри строки
    static let sectionSpacing: CGFloat = 24  // между блоками на всех экранах
    static let iconSize: CGFloat = 30

    // Цвета
    static let income = Color.green
    static let expense = Color.orange
    static let palette: [Color] = [.blue, .orange, .purple, .teal, .pink, .indigo, .mint, .yellow, .red, .cyan]
    static func color(at index: Int) -> Color { palette[index % palette.count] }
}

extension View {
    /// Одинаковое расстояние между блоками на всех экранах
    func themedList() -> some View {
        self.listSectionSpacing(Theme.sectionSpacing)
    }
}

/// Цветной квадратик с иконкой — как в «Настройках» iPhone
struct IconBadge: View {
    let symbol: String
    let color: Color
    var size: CGFloat = Theme.iconSize

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.5, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(color.gradient, in: RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
            .accessibilityHidden(true)
    }
}

/// Строка «иконка + текст» — одинаковая во всех списках
struct IconRow: View {
    let title: String
    let symbol: String
    let color: Color

    var body: some View {
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: symbol, color: color)
            Text(title).font(Theme.body)
        }
    }
}

/// Строка-пояснение с иконкой (для экрана «О приложении»)
struct FeatureRow: View {
    let symbol: String
    let color: Color
    let title: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: Theme.gap) {
            IconBadge(symbol: symbol, color: color)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(Theme.body)
                Text(text).font(Theme.caption).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

/// Сумма ровно с тем знаком, который ввёл пользователь.
/// Тип операции («Доход»/«Расход») знак НЕ меняет — он только группирует.
/// Плюс показывается зелёным, минус — основным цветом (как в Wallet).
struct AmountText: View {
    let amount: Double
    var currency: Currency = .rub
    var font: Font = Theme.subtitle

    var body: some View {
        Text(Money.format(amount, currency))
            .font(font)
            .monospacedDigit()
            .foregroundStyle(amount > 0 ? Theme.income : Color.primary)
            .lineLimit(1)
            .layoutPriority(1)
    }
}
