import SwiftUI
import UIKit
import UIKit.UIGestureRecognizerSubclass

/// Поле даты/времени, которое по умолчанию ПУСТОЕ (nil) и заполняется только
/// вручную — по требованию: "всегда ввожу дату и время вручную".
struct OptionalPickerField<Content: View>: View {
    let label: String
    var symbol: String? = nil
    var color: Color = .accentColor
    @Binding var value: Date?
    let placeholder: String
    let pickerContent: (Binding<Date>) -> Content

    init(label: String, symbol: String? = nil, color: Color = .accentColor,
         value: Binding<Date?>, placeholder: String,
         @ViewBuilder pickerContent: @escaping (Binding<Date>) -> Content) {
        self.label = label
        self.symbol = symbol
        self.color = color
        self._value = value
        self.placeholder = placeholder
        self.pickerContent = pickerContent
    }

    var body: some View {
        HStack(spacing: Theme.gap) {
            if let symbol {
                IconBadge(symbol: symbol, color: color)
            }
            Text(label)
            Spacer()
            if let v = value {
                pickerContent(Binding(get: { v }, set: { value = $0 }))
                Button {
                    withAnimation { value = nil }
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.tertiary)
                        .imageScale(.large)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Очистить \(label.lowercased())")
            } else {
                Button(placeholder) {
                    withAnimation { value = Date() }
                }
                .buttonStyle(.borderless)
                .foregroundStyle(Color.accentColor)
            }
        }
    }
}

/// Системное меню "Поделиться" для экспорта файла.
/// После закрытия меню временный файл удаляется — расшифрованные данные
/// не остаются лежать на диске.
struct ShareSheet: UIViewControllerRepresentable {
    let fileURL: URL
    var onFinish: () -> Void = {}

    func makeUIViewController(context: Context) -> UIActivityViewController {
        let vc = UIActivityViewController(activityItems: [fileURL], applicationActivities: nil)
        let url = fileURL
        let finish = onFinish
        vc.completionWithItemsHandler = { _, _, _, _ in
            try? FileManager.default.removeItem(at: url)
            finish()
        }
        return vc
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}

/// Обёртка, чтобы показывать лист экспорта через .sheet(item:)
struct ExportFile: Identifiable {
    let id = UUID()
    let url: URL
}

// MARK: - Отслеживание активности для автоблокировки

/// Распознаватель, который только «замечает» касание и сразу отказывается от него,
/// поэтому никак не мешает кнопкам, спискам и полям ввода.
final class TouchObserverRecognizer: UIGestureRecognizer, UIGestureRecognizerDelegate {
    var onTouch: (() -> Void)?

    /// Настройка «невмешательства»: касания проходят дальше без задержек
    func configurePassThrough() {
        cancelsTouchesInView = false
        delaysTouchesBegan = false
        delaysTouchesEnded = false
        delegate = self
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent) {
        onTouch?()
        state = .failed
    }

    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer,
                           shouldRecognizeSimultaneouslyWith other: UIGestureRecognizer) -> Bool {
        true
    }
}

/// Невидимый вид, который вешает TouchObserverRecognizer на всё окно приложения.
struct ActivityCatcher: UIViewRepresentable {
    let onActivity: () -> Void

    final class CatcherView: UIView {
        var onActivity: (() -> Void)?
        private var installed: TouchObserverRecognizer?

        override func didMoveToWindow() {
            super.didMoveToWindow()
            guard let window, installed == nil else { return }
            let rec = TouchObserverRecognizer(target: nil, action: nil)
            rec.configurePassThrough()
            rec.onTouch = { [weak self] in self?.onActivity?() }
            window.addGestureRecognizer(rec)
            installed = rec
        }
    }

    func makeUIView(context: Context) -> CatcherView {
        let v = CatcherView()
        v.isUserInteractionEnabled = false
        v.backgroundColor = .clear
        v.onActivity = onActivity
        return v
    }

    func updateUIView(_ uiView: CatcherView, context: Context) {
        uiView.onActivity = onActivity
    }
}

/// Экран-заглушка: закрывает данные в переключателе приложений
/// и когда приложение неактивно.
struct PrivacyCover: View {
    var body: some View {
        ZStack {
            Color(.systemBackground).ignoresSafeArea()
            VStack(spacing: 12) {
                AppBadge(size: 80)
                Text("N Finance").font(Theme.subtitle)
            }
        }
    }
}

/// Логотип приложения (золотая монета N) внутри интерфейса
struct AppBadge: View {
    var size: CGFloat = 46
    var body: some View {
        Image("AppLogo")
            .resizable()
            .interpolation(.high)
            .frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: size * 0.2237, style: .continuous))
            .accessibilityHidden(true)
    }
}

/// Красная строка-действие: и текст, и иконка красные (в списках iOS
/// стандартная `Label` в destructive-кнопке оставляет иконку синей).
struct DestructiveRow: View {
    let title: String
    var symbol: String = "trash"
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: Theme.gap) {
                Image(systemName: symbol)
                    .imageScale(.medium)
                Text(title)
                    .font(Theme.body)
            }
            .foregroundStyle(.red)
        }
        .buttonStyle(.plain)
        .accessibilityLabel(title)
    }
}

// MARK: - Дата и время

nonisolated enum DateTimeMode { case date, time }

/// Строка даты или времени в форме. Поле по умолчанию ПУСТОЕ и заполняется
/// только вручную — по требованию: «всегда ввожу дату и время вручную».
struct DateTimeRow: View {
    let label: String
    let symbol: String
    let color: Color
    let mode: DateTimeMode
    @Binding var value: Date?

    @State private var showPicker = false

    var body: some View {
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: symbol, color: color)
            Text(label).font(Theme.body)
            Spacer(minLength: Theme.gap)
            if let v = value {
                Button(display(v)) { showPicker = true }
                    .font(Theme.body)
                    .buttonStyle(.borderless)
                    .monospacedDigit()
                Button {
                    withAnimation { value = nil }
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(.tertiary)
                        .imageScale(.large)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Очистить \(label.lowercased())")
            } else {
                Button("Выбрать") { showPicker = true }
                    .font(Theme.body)
                    .buttonStyle(.borderless)
            }
        }
        .sheet(isPresented: $showPicker) {
            DateTimeSheet(mode: mode, initial: value ?? Date()) { picked in
                value = picked
                showPicker = false
            }
            .presentationDetents([.height(mode == .date ? 470 : 320)])
            .presentationDragIndicator(.visible)
        }
    }

    private func display(_ d: Date) -> String {
        mode == .date ? DateFmt.display(DateFmt.dayString(d)) : DateFmt.timeString(d)
    }
}

/// Окно выбора, которое закрывается само.
struct DateTimeSheet: View {
    let mode: DateTimeMode
    let initial: Date
    var onPick: (Date) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var value: Date
    @State private var closeTask: Task<Void, Never>? = nil

    init(mode: DateTimeMode, initial: Date, onPick: @escaping (Date) -> Void) {
        self.mode = mode
        self.initial = initial
        self.onPick = onPick
        _value = State(initialValue: initial)
    }

    /// Пишем через свою привязку, а не через `.onChange`: календарь вызывает
    /// сеттер на каждое касание дня, даже если пользователь ткнул тот же день,
    /// который уже подсвечен, — а `.onChange` в этом случае не сработал бы,
    /// и самый частый выбор «сегодня» не закрывал бы окно.
    private var picked: Binding<Date> {
        Binding(get: { value }, set: { newValue in
            value = newValue
            handle(newValue)
        })
    }

    var body: some View {
        NavigationStack {
            Group {
                if mode == .date {
                    DatePicker("", selection: picked, displayedComponents: .date)
                        .datePickerStyle(.graphical)
                        .labelsHidden()
                } else {
                    DatePicker("", selection: picked, displayedComponents: .hourAndMinute)
                        .datePickerStyle(.wheel)
                        .labelsHidden()
                }
            }
            .padding(.horizontal, Theme.gap)
            .navigationTitle(mode == .date ? "Дата" : "Время")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { closeTask?.cancel(); dismiss() }
                        .font(Theme.body)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { closeTask?.cancel(); onPick(value) }
                        .font(Theme.body.weight(.semibold))
                }
            }
        }
        .onDisappear { closeTask?.cancel() }
    }

    private func handle(_ newValue: Date) {
        closeTask?.cancel()
        if mode == .date {
            onPick(newValue)                       // день выбран — закрываем сразу
        } else {
            // Колесо времени шлёт изменение на каждый щелчок. Без паузы окно
            // захлопывалось бы, пока крутишь часы, не дав добраться до минут.
            closeTask = Task { @MainActor in
                try? await Task.sleep(nanoseconds: 700_000_000)
                guard !Task.isCancelled else { return }
                onPick(newValue)
            }
        }
    }
}

// MARK: - Справочники

/// Поле названия. Записывает изменение по «Готово» и при уходе фокуса —
/// отдельная кнопка сохранения на таком экране была бы лишней.
struct NameField: View {
    let initial: String
    var placeholder: String = "Название"
    var onCommit: (String) -> Void

    @State private var text = ""
    @State private var loaded = false
    @FocusState private var focused: Bool

    var body: some View {
        TextField(placeholder, text: $text)
            .font(Theme.body)
            .focused($focused)
            .submitLabel(.done)
            .onSubmit(commit)
            .onChange(of: focused) { _, isFocused in if !isFocused { commit() } }
            .onAppear {
                guard !loaded else { return }
                text = initial
                loaded = true
            }
    }

    private func commit() {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { text = initial; return }   // пустое имя не принимаем
        onCommit(trimmed)
    }
}

/// Строка выбора с галочкой — валюта, группа в статистике, категория лица
struct ChoiceRow: View {
    let title: String
    var symbol: String? = nil
    var color: Color = .gray
    var detail: String? = nil
    let selected: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: Theme.gap) {
                if let symbol { IconBadge(symbol: symbol, color: color) }
                Text(title).font(Theme.body).foregroundStyle(Color.primary)
                Spacer(minLength: Theme.gap)
                if let detail {
                    Text(detail).font(Theme.caption).foregroundStyle(.secondary)
                }
                Image(systemName: "checkmark")
                    .font(Theme.body.weight(.semibold))
                    .foregroundStyle(Color.accentColor)
                    .opacity(selected ? 1 : 0)          // место под галочку занято всегда:
            }                                            // иначе строки дёргаются при выборе
        }
        .buttonStyle(.plain)
        .accessibilityAddTraits(selected ? [.isSelected] : [])
    }
}

/// Строка справочника внутри перехода на отдельный экран
struct DirectoryRow: View {
    let name: String
    var note: String? = nil
    var detail: String? = nil

    var body: some View {
        HStack(spacing: Theme.gap) {
            VStack(alignment: .leading, spacing: 2) {
                Text(name).font(Theme.body)
                if let note {
                    Text(note).font(Theme.caption).foregroundStyle(.secondary)
                }
            }
            Spacer(minLength: Theme.gap)
            if let detail {
                Text(detail).font(Theme.caption).foregroundStyle(.secondary)
            }
        }
    }
}

/// Строка справочника с переименованием на месте — для нижнего уровня,
/// куда проваливаться уже некуда (подкатегории)
struct EditableRow: View {
    let name: String
    var onRename: (String) -> Void
    var onDelete: () -> Void
    @State private var isEditing = false
    @State private var editText = ""
    @State private var focusRequested = false
    @FocusState private var focused: Bool

    var body: some View {
        HStack(spacing: Theme.gap) {
            if isEditing {
                TextField("Название", text: $editText)
                    .font(Theme.body)
                    .textFieldStyle(.roundedBorder)
                    .focused($focused)
                    .submitLabel(.done)
                    .onSubmit(commit)
                    // Фокус ставим, когда поле уже в иерархии: запись в @FocusState
                    // в том же проходе обновления просто теряется, и клавиатура
                    // не поднималась бы. Флаг — чтобы клавиатура не всплывала
                    // заново каждый раз, когда строка возвращается при прокрутке.
                    .onAppear {
                        guard !focusRequested else { return }
                        focusRequested = true
                        focused = true
                    }
                    .onChange(of: focused) { _, isFocused in
                        if !isFocused { commit() }   // ушёл фокус — режим правки закрыт
                    }
                Button("Готово", action: commit)
                    .font(Theme.body)
                    .buttonStyle(.borderless)
            } else {
                Text(name).font(Theme.body)
                Spacer(minLength: Theme.gap)
                Button {
                    editText = name
                    isEditing = true
                } label: {
                    Image(systemName: "pencil")
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("Переименовать \(name)")

                Button(action: onDelete) {
                    Image(systemName: "trash").foregroundStyle(.red)
                }
                .buttonStyle(.borderless)
                .accessibilityLabel("Удалить \(name)")
            }
        }
    }

    private func commit() {
        let trimmed = editText.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty && trimmed != name { onRename(trimmed) }
        isEditing = false
        focusRequested = false
    }
}

/// Строка добавления нового значения в справочник.
/// `onAdd` возвращает false, если такое имя уже есть: тогда поле не очищается
/// и подсвечивается — иначе ввод исчезал бы молча, будто всё получилось.
struct AddRow: View {
    let placeholder: String
    var onAdd: (String) -> Bool
    @State private var text = ""
    @State private var duplicate = false

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            HStack(spacing: Theme.gap) {
                TextField(placeholder, text: $text)
                    .font(Theme.body)
                    .submitLabel(.done)
                    .onSubmit(add)
                    .onChange(of: text) { _, _ in duplicate = false }
                Button("Добавить", action: add)
                    .font(Theme.body)
                    .buttonStyle(.borderless)
                    .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
            if duplicate {
                Text("Такое название уже есть")
                    .font(Theme.caption)
                    .foregroundStyle(.red)
            }
        }
    }

    private func add() {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        if onAdd(trimmed) {
            text = ""
            duplicate = false
        } else {
            duplicate = true
        }
    }
}
