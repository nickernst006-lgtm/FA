import SwiftUI
import Charts

struct StatsView: View {
    @EnvironmentObject var appState: AppState

    enum Period: String, CaseIterable, Identifiable {
        case month = "Месяц"
        case year = "Год"
        case all = "Всё время"
        var id: String { rawValue }
    }
    @State private var period: Period = .month
    @State private var pickedCurrency: Currency? = nil

    // MARK: - Модели строк

    struct Total: Identifiable {
        let name: String
        let value: Double
        var id: String { name }
    }

    /// Итог по одной валюте — для строки «Итого» под остатками
    struct CurrencyTotal: Identifiable {
        let currency: Currency
        let total: Double
        var id: String { currency.rawValue }
    }

    struct MonthPoint: Identifiable {
        let month: String   // "2026-09"
        let kind: String    // "Доходы" / "Расходы"
        let value: Double
        /// Подпись на оси. Хранится, а не вычисляется: если в выборку попали
        /// сентябри двух разных лет, без года они слились бы в один столбец —
        /// ось группирует точки именно по подписи.
        let label: String

        var id: String { month + kind }

        static func label(for month: String, withYear: Bool) -> String {
            let names = ["янв", "фев", "мар", "апр", "май", "июн",
                         "июл", "авг", "сен", "окт", "ноя", "дек"]
            let parts = month.split(separator: "-")
            guard parts.count == 2, let m = Int(parts[1]), (1...12).contains(m) else { return month }
            let short: String = names[m - 1]
            if !withYear { return short }
            return short + " " + String(parts[0].suffix(2))
        }
    }

    /// Всё посчитанное за один проход.
    ///
    /// Вынесено из `body` намеренно: SwiftUI разбирает типы внутри ViewBuilder
    /// целиком, и десяток `let` подряд рядом с деревом представлений перестаёт
    /// укладываться в отведённое компилятору время — сборка падает с
    /// «unable to type-check this expression in reasonable time».
    struct Digest {
        var currency: Currency = .rub
        var available: [Currency] = []
        var income: Double = 0
        var expense: Double = 0
        var balance: Double = 0
        var expenseByCategory: [Total] = []
        var incomeByCategory: [Total] = []
        var byAccount: [Total] = []
        var byPerson: [Total] = []
        var balances: [AccountBalance] = []
        var currencyTotals: [CurrencyTotal] = []
        var points: [MonthPoint] = []
        var hasOperations = false
    }

    // MARK: - Выборка и подсчёты

    var operations: [OperationRecord] {
        let today = DateFmt.dayString(Date())
        switch period {
        case .all: return appState.data.operations
        case .month:
            let prefix = String(today.prefix(7))
            return appState.data.operations.filter { $0.date.hasPrefix(prefix) }
        case .year:
            let prefix = String(today.prefix(4))
            return appState.data.operations.filter { $0.date.hasPrefix(prefix) }
        }
    }

    var periodTitle: String {
        let today = DateFmt.dayString(Date())
        switch period {
        case .month: return DateFmt.monthTitle(String(today.prefix(7)))
        case .year: return "\(today.prefix(4)) год"
        case .all: return "За всё время"
        }
    }

    /// Валюты, которые реально встречаются за период, по убыванию частоты
    func usedCurrencies(_ ops: [OperationRecord]) -> [Currency] {
        var count: [Currency: Int] = [:]
        for op in ops { count[op.effectiveCurrency, default: 0] += 1 }
        var list: [Currency] = Array(count.keys)
        // При равной частоте нужен запасной признак: порядок ключей словаря
        // не определён, и переключатель валют переставлялся бы сам собой.
        list.sort { a, b in
            let ca: Int = count[a] ?? 0
            let cb: Int = count[b] ?? 0
            if ca != cb { return ca > cb }
            return a.rawValue < b.rawValue
        }
        return list
    }

    /// Порядок сводных списков: сначала по величине, при равенстве по алфавиту.
    ///
    /// Именованной функцией, а не замыканием на месте. Цепочка `map → sorted`
    /// с тернарником и `abs()` внутри — ровно то выражение, на котором компилятор
    /// дважды упёрся в «unable to type-check this expression in reasonable time».
    private static func byMagnitude(_ a: Total, _ b: Total) -> Bool {
        let ma: Double = abs(a.value)
        let mb: Double = abs(b.value)
        if ma != mb { return ma > mb }
        return a.name.localizedStandardCompare(b.name) == .orderedAscending
    }

    func totals(_ ops: [OperationRecord], key: (OperationRecord) -> String, limit: Int) -> [Total] {
        var dict: [String: Double] = [:]
        for op in ops { dict[key(op), default: 0] += op.amount }

        // Собираем и сортируем по шагам, с явными типами: так компилятору
        // нечего выводить и выражение остаётся простым.
        var list: [Total] = []
        list.reserveCapacity(dict.count)
        for (rawName, value) in dict {
            let name: String = rawName.isEmpty ? "Без названия" : rawName
            list.append(Total(name: name, value: value))
        }
        list.sort(by: StatsView.byMagnitude)

        guard list.count > limit else { return list }
        var rest: Double = 0
        for item in list[limit...] { rest += item.value }
        var top: [Total] = Array(list.prefix(limit))
        top.append(Total(name: "Остальное", value: rest))
        return top
    }

    func monthPoints(_ ops: [OperationRecord]) -> [MonthPoint] {
        let data = appState.data
        var dict: [String: (income: Double, expense: Double)] = [:]
        for op in ops {
            guard op.date.count >= 7 else { continue }
            let m = String(op.date.prefix(7))
            var cur = dict[m] ?? (income: 0, expense: 0)
            switch data.kind(of: op) {
            case .income: cur.income += op.amount
            case .expense: cur.expense += op.amount
            case .neutral: break
            }
            dict[m] = cur
        }
        let months: [String] = Array(dict.keys.sorted().suffix(12))
        var years: Set<String> = []
        for m in months { years.insert(String(m.prefix(4))) }
        let withYear: Bool = years.count > 1
        var points: [MonthPoint] = []
        for m in months {
            let v = dict[m] ?? (income: 0, expense: 0)
            let title = MonthPoint.label(for: m, withYear: withYear)
            points.append(MonthPoint(month: m, kind: "Доходы", value: v.income, label: title))
            points.append(MonthPoint(month: m, kind: "Расходы", value: v.expense, label: title))
        }
        return points
    }

    /// Итоги по каждой валюте: остатки разных валют складывать нельзя
    func balanceTotals(_ balances: [AccountBalance]) -> [CurrencyTotal] {
        var sums: [Currency: Double] = [:]
        for b in balances { sums[b.currency, default: 0] += b.total }
        var keys: [Currency] = Array(sums.keys)
        keys.sort { $0.rawValue < $1.rawValue }
        var result: [CurrencyTotal] = []
        for k in keys {
            result.append(CurrencyTotal(currency: k, total: sums[k] ?? 0))
        }
        return result
    }

    /// Складывать рубли с долларами нельзя, поэтому доходы, расходы и диаграммы
    /// считаются по одной валюте. Переключатель появляется, только если валют
    /// в данных больше одной.
    func makeDigest() -> Digest {
        let data = appState.data
        let periodOps = operations
        let available: [Currency] = usedCurrencies(periodOps)

        // Разложено на шаги вместо `flatMap { … ? … : nil } ?? … ?? .rub`:
        // цепочка из двух `??` вокруг замыкания с тернарником — тот же шаблон,
        // на котором компилятор не укладывается в отведённое время.
        var currency: Currency = .rub
        if let picked = pickedCurrency, available.contains(picked) {
            currency = picked
        } else if let first = available.first {
            currency = first
        }

        var ops: [OperationRecord] = []
        for op in periodOps where op.effectiveCurrency == currency { ops.append(op) }

        // Один проход вместо шести отдельных filter: и быстрее, и компилятору
        // нечего разбирать в длинных цепочках.
        // Знак берётся из самой операции: тип только распределяет по группам.
        var income: Double = 0
        var expense: Double = 0
        var incomeOps: [OperationRecord] = []
        var expenseOps: [OperationRecord] = []
        var personOps: [OperationRecord] = []
        for op in ops {
            let kind = data.kind(of: op)
            if kind == .income {
                income += op.amount
                incomeOps.append(op)
            } else if kind == .expense {
                expense += op.amount
                expenseOps.append(op)
            }
            if !op.person.isEmpty { personOps.append(op) }
        }

        var d = Digest()
        d.currency = currency
        d.available = available
        d.hasOperations = !ops.isEmpty
        d.income = income
        d.expense = expense
        d.balance = income + expense
        d.expenseByCategory = totals(expenseOps, key: { $0.category }, limit: 6)
        d.incomeByCategory = totals(incomeOps, key: { $0.category }, limit: 6)
        d.byAccount = totals(ops, key: { "\($0.bank), \($0.account)" }, limit: 8)
        d.byPerson = totals(personOps, key: { $0.person }, limit: 8)
        d.balances = data.accountBalances()
        d.currencyTotals = balanceTotals(d.balances)
        // График строится по всей истории, но тоже в одной валюте — иначе
        // в одном столбце сложились бы рубли с долларами.
        d.points = monthPoints(data.operations.filter { $0.effectiveCurrency == currency })
        return d
    }

    // MARK: - Экран

    var body: some View {
        let d = makeDigest()
        List {
            filtersSection(d)
            heroSection(d)
            balancesSection(d)
            categoriesSection(d)
            monthsSection(d)
            breakdownSection(d)
        }
        .navigationTitle("Статистика")
        .themedList()
        .animation(.default, value: period)
    }

    @ViewBuilder
    private func filtersSection(_ d: Digest) -> some View {
        Section {
            Picker("Период", selection: $period) {
                ForEach(Period.allCases) { p in Text(p.rawValue).tag(p) }
            }
            .pickerStyle(.segmented)

            if d.available.count > 1 {
                Picker("Валюта", selection: currencyBinding(d)) {
                    ForEach(d.available) { c in Text("\(c.symbol) \(c.code)").tag(c) }
                }
                .pickerStyle(.segmented)
                .padding(.top, 6)
            }
        }
        .listRowBackground(Color.clear)
        .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 4, trailing: 0))
    }

    private func currencyBinding(_ d: Digest) -> Binding<Currency> {
        Binding(get: { d.currency }, set: { pickedCurrency = $0 })
    }

    @ViewBuilder
    private func heroSection(_ d: Digest) -> some View {
        Section {
            VStack(alignment: .leading, spacing: Theme.gap) {
                VStack(alignment: .leading, spacing: 4) {
                    Text(periodTitle).font(Theme.caption).foregroundStyle(.secondary)
                    Text(Money.format(d.balance, d.currency))
                        .font(Theme.display)
                        .foregroundStyle(d.balance < 0 ? Color.red : Color.primary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
                HStack(spacing: Theme.gap) {
                    statTile("Доходы", d.income, d.currency, Theme.income, "arrow.down")
                    statTile("Расходы", d.expense, d.currency, Theme.expense, "arrow.up")
                }
            }
            .padding(.vertical, Theme.gap / 2)
        }
    }

    @ViewBuilder
    private func balancesSection(_ d: Digest) -> some View {
        if !d.balances.isEmpty {
            Section {
                ForEach(d.balances) { b in
                    balanceRow(b)
                }
                ForEach(d.currencyTotals) { t in
                    totalRow(t)
                }
            } header: {
                Text("Остатки по счетам")
            } footer: {
                Text("Остаток — сумма всех операций по счёту за всё время, независимо от выбранного периода. Переводы между своими счетами тоже учитываются: общий баланс они не меняют, а деньги со счёта уходят.")
            }
        }
    }

    private func balanceRow(_ b: AccountBalance) -> some View {
        HStack(spacing: Theme.gap) {
            VStack(alignment: .leading, spacing: 2) {
                Text(b.account).font(Theme.body)
                Text(b.closed ? "\(b.bank) · закрыт" : b.bank)
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer(minLength: Theme.gap)
            Text(Money.format(b.total, b.currency))
                .font(Theme.subtitle)
                .monospacedDigit()
                .foregroundStyle(b.total < 0 ? Color.red : Color.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
        .padding(.vertical, 2)
        .opacity(b.closed ? 0.5 : 1)
    }

    private func totalRow(_ t: CurrencyTotal) -> some View {
        HStack(spacing: Theme.gap) {
            Text("Итого, \(t.currency.code)").font(Theme.body)
            Spacer(minLength: Theme.gap)
            Text(Money.format(t.total, t.currency))
                .font(Theme.subtitle)
                .monospacedDigit()
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
    }

    @ViewBuilder
    private func categoriesSection(_ d: Digest) -> some View {
        if !d.hasOperations {
            Section {
                ContentUnavailableView("Нет операций",
                                       systemImage: "chart.pie",
                                       description: Text("За выбранный период операций нет."))
            }
        } else {
            if !d.expenseByCategory.isEmpty {
                Section("Расходы по категориям") {
                    donut(d.expenseByCategory, total: d.expense, currency: d.currency)
                    legend(d.expenseByCategory, total: d.expense, currency: d.currency)
                }
            }
            if !d.incomeByCategory.isEmpty {
                Section("Доходы по категориям") {
                    legend(d.incomeByCategory, total: d.income, currency: d.currency)
                }
            }
        }
    }

    @ViewBuilder
    private func monthsSection(_ d: Digest) -> some View {
        if d.points.count >= 2 {
            Section("По месяцам") {
                monthsChart(d.points)
                    .frame(height: 220)
                    .padding(.vertical, Theme.gap)
            }
        }
    }

    private static let barScale: KeyValuePairs<String, Color> =
        ["Доходы": Theme.income, "Расходы": Theme.expense]

    private func monthsChart(_ points: [MonthPoint]) -> some View {
        Chart {
            ForEach(points) { p in
                BarMark(x: .value("Месяц", p.label),
                        y: .value("Сумма", p.value),
                        width: .ratio(0.7))
                    .cornerRadius(4)
                    .foregroundStyle(by: .value("Тип", p.kind))
                    .position(by: .value("Тип", p.kind))
            }
            zeroLine
        }
        .chartForegroundStyleScale(Self.barScale)
        .chartLegend(position: .top, alignment: .leading)
        .chartYAxis { yAxis }
    }

    private var zeroLine: some ChartContent {
        RuleMark(y: .value("Ноль", 0))
            .lineStyle(StrokeStyle(lineWidth: 1))
            .foregroundStyle(Color.secondary.opacity(0.45))
    }

    private var yAxis: some AxisContent {
        AxisMarks(position: .trailing) { _ in
            AxisGridLine(stroke: StrokeStyle(lineWidth: 0.5, dash: [3]))
            AxisValueLabel()
        }
    }

    @ViewBuilder
    private func breakdownSection(_ d: Digest) -> some View {
        if d.hasOperations {
            Section("Обороты по счетам") {
                plainList(d.byAccount, currency: d.currency)
            }
            if !d.byPerson.isEmpty {
                Section("Лица") {
                    plainList(d.byPerson, currency: d.currency)
                }
            }
        }
    }

    // MARK: - Кирпичики

    private func statTile(_ title: String, _ value: Double, _ currency: Currency,
                          _ color: Color, _ symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Label(title, systemImage: symbol)
                .font(Theme.caption)
                .foregroundStyle(color)
            Text(Money.format(value, currency))
                .font(Theme.subtitle.monospacedDigit())
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
        .padding(Theme.gap)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(color.opacity(0.1), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    /// Доли на круге считаются по величине суммы (по модулю) — знак на угол не влияет
    private func donut(_ items: [Total], total: Double, currency: Currency) -> some View {
        Chart(Array(items.enumerated()), id: \.element.id) { index, item in
            SectorMark(angle: .value("Сумма", abs(item.value)),
                       innerRadius: .ratio(0.64),
                       angularInset: 1.5)
                .cornerRadius(4)
                .foregroundStyle(Theme.color(at: index))
        }
        .chartBackground { _ in
            VStack(spacing: 2) {
                Text("Всего").font(Theme.caption).foregroundStyle(.secondary)
                Text(Money.format(total, currency))
                    .font(Theme.subtitle.monospacedDigit())
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                    .frame(maxWidth: 120)
            }
        }
        .frame(height: 220)
        .padding(.vertical, Theme.gap)
    }

    private func legend(_ items: [Total], total: Double, currency: Currency) -> some View {
        ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
            HStack(spacing: Theme.gap) {
                Circle().fill(Theme.color(at: index)).frame(width: 10, height: 10)
                Text(item.name).font(Theme.body).lineLimit(1)
                Spacer(minLength: Theme.gap)
                Text(percent(item.value, of: total))
                    .font(Theme.caption).foregroundStyle(.secondary).monospacedDigit()
                Text(Money.format(item.value, currency))
                    .font(Theme.body).monospacedDigit()
            }
        }
    }

    /// Доля в процентах. Вынесено из вью: тернарник с интерполяцией и
    /// арифметикой внутри Text — ровно тот шаблон, на котором компилятор
    /// перестаёт укладываться в отведённое время.
    private func percent(_ value: Double, of total: Double) -> String {
        guard abs(total) > 0 else { return "" }
        let share = abs(value) / abs(total) * 100
        return "\(Int(share.rounded())) %"
    }

    private func plainList(_ items: [Total], currency: Currency) -> some View {
        // Явный проход вместо `max(items.map { abs($0.value) }.max() ?? 1, 0.01)`:
        // обобщённый `max` над литералом внутри цепочки `map → max → ??`
        // компилятор разбирает неоправданно долго.
        var maxVal: Double = 0.01
        for item in items {
            let m: Double = abs(item.value)
            if m > maxVal { maxVal = m }
        }
        return ForEach(items) { item in
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(item.name).font(Theme.body).lineLimit(1)
                    Spacer(minLength: Theme.gap)
                    Text(Money.format(item.value, currency)).font(Theme.body).monospacedDigit()
                }
                GeometryReader { geo in
                    let ratio = CGFloat(abs(item.value) / maxVal)
                    Capsule()
                        .fill(Color.accentColor.opacity(0.18))
                        .overlay(alignment: .leading) {
                            Capsule()
                                .fill(Color.accentColor.gradient)
                                .frame(width: max(4, geo.size.width * ratio))
                        }
                }
                .frame(height: 5)
            }
            .padding(.vertical, 2)
        }
    }
}
