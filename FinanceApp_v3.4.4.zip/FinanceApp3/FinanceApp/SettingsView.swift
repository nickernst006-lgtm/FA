import SwiftUI

/// Справочники. На корневом экране виден только ПЕРВЫЙ уровень — банки,
/// операции и категории лиц. Всё, что внутри (счета, категории, подкатегории,
/// сами лица), настраивается на отдельных экранах: вложенные раскрывающиеся
/// списки на четыре уровня читались плохо и путали.
struct SettingsView: View {
    @EnvironmentObject var appState: AppState

    var body: some View {
        List {
            Section {
                ForEach(appState.data.banks) { bank in
                    NavigationLink(value: DirectoryRoute.bank(bank.id)) {
                        DirectoryRow(name: bank.name, detail: accountsNote(bank))
                    }
                    .accessibilityIdentifier("dir_" + bank.name)
                }
                .onMove { appState.moveBanks($0, $1) }
                AddRow(placeholder: "Новый банк") { name in
                    guard appState.nameIsFree(name, among: appState.data.banks.map { $0.name }) else { return false }
                    appState.data.banks.append(Bank(name: name))
                    appState.persist()
                    return true
                }
            } header: {
                Label("Банки и счета", systemImage: "building.columns")
            } footer: {
                Text("Нажмите на банк, чтобы завести счета, указать их валюту и отметить закрытые.")
            }

            Section {
                ForEach(appState.data.optypes) { op in
                    NavigationLink(value: DirectoryRoute.operation(op.id)) {
                        DirectoryRow(name: op.name,
                                     note: op.effectiveKind.title,
                                     detail: categoriesNote(op))
                    }
                    .accessibilityIdentifier("dir_" + op.name)
                }
                .onMove { appState.moveOperationTypes($0, $1) }
                AddRow(placeholder: "Новая операция") { name in
                    guard appState.nameIsFree(name, among: appState.data.optypes.map { $0.name }) else { return false }
                    appState.data.optypes.append(OperationType(name: name))
                    appState.persist()
                    return true
                }
            } header: {
                Label("Операции и категории", systemImage: "square.grid.2x2")
            } footer: {
                Text("Нажмите на операцию, чтобы выбрать группу в статистике и настроить категории. «Доход» и «Расход» — только группы: знак суммы вы ставите сами при вводе.")
            }

            Section {
                ForEach(appState.data.personGroups) { group in
                    NavigationLink(value: DirectoryRoute.personGroup(group.id)) {
                        DirectoryRow(name: group.name, detail: personsNote(group))
                    }
                    .accessibilityIdentifier("dir_" + group.name)
                }
                .onMove { appState.movePersonGroups($0, $1) }
                AddRow(placeholder: "Новая категория лиц") { name in
                    guard appState.nameIsFree(name, among: appState.data.personGroups.map { $0.name }) else { return false }
                    appState.data.personGroups.append(PersonGroup(name: name))
                    appState.persist()
                    return true
                }
            } header: {
                Label("Люди", systemImage: "person.2")
            } footer: {
                Text("Лица разложены по категориям. Внутри категории они сами встают по частоте использования, а нужные можно закрепить сверху.")
            }
        }
        .navigationTitle("Настройки")
        .themedList()
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) { EditButton() }
        }
        .navigationDestination(for: DirectoryRoute.self) { route in
            switch route {
            case .bank(let id):        BankScreen(bankId: id)
            case .account(let id):     AccountScreen(accountId: id)
            case .operation(let id):   OperationTypeScreen(opId: id)
            case .category(let id):    CategoryScreen(catId: id)
            case .personGroup(let id): PersonGroupScreen(groupId: id)
            case .person(let id):      PersonScreen(personId: id)
            }
        }
    }

    private func accountsNote(_ bank: Bank) -> String {
        let all = appState.data.accounts.filter { $0.bankId == bank.id }
        let open = all.filter { !$0.isClosed }.count
        if all.isEmpty { return "нет счетов" }
        return all.count == open ? "\(all.count)" : "\(open) из \(all.count)"
    }

    private func categoriesNote(_ op: OperationType) -> String {
        let n = appState.data.categories.filter { $0.opId == op.id }.count
        return n == 0 ? "нет категорий" : "\(n)"
    }

    private func personsNote(_ group: PersonGroup) -> String {
        let n = appState.data.persons.filter { $0.groupId == group.id }.count
        return n == 0 ? "пусто" : "\(n)"
    }
}

/// Куда можно провалиться из справочников
enum DirectoryRoute: Hashable {
    case bank(UUID)
    case account(UUID)
    case operation(UUID)
    case category(UUID)
    case personGroup(UUID)
    case person(UUID)
}

// MARK: - Банк

struct BankScreen: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let bankId: UUID
    @State private var confirmDelete = false

    private var bank: Bank? { appState.data.banks.first { $0.id == bankId } }
    private var accounts: [Account] { appState.data.accounts.filter { $0.bankId == bankId } }

    var body: some View {
        if let bank {
            List {
                Section("Название") {
                    NameField(initial: bank.name, placeholder: "Название банка") {
                        appState.renameBank(bankId, to: $0)
                    }
                }

                Section {
                    ForEach(accounts) { acc in
                        NavigationLink(value: DirectoryRoute.account(acc.id)) {
                            DirectoryRow(name: acc.name,
                                         note: acc.isClosed ? "закрыт" : nil,
                                         detail: acc.effectiveCurrency.symbol)
                        }
                        .accessibilityIdentifier("dir_" + acc.name)
                    }
                    .onMove { appState.moveAccounts(in: bankId, $0, $1) }
                    AddRow(placeholder: "Новый счёт") { name in
                        guard appState.nameIsFree(name, among: accounts.map { $0.name }) else { return false }
                        appState.data.accounts.append(Account(name: name, bankId: bankId, currency: .rub))
                        appState.persist()
                        return true
                    }
                } header: {
                    Text("Счета")
                } footer: {
                    Text("У каждого счёта своя валюта. Закрытый счёт остаётся в истории и в остатках, но не предлагается при вводе новой операции.")
                }

                Section {
                    DestructiveRow(title: "Удалить банк") { confirmDelete = true }
                }
            }
            .navigationTitle(bank.name)
            .navigationBarTitleDisplayMode(.inline)
            .themedList()
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { EditButton() }
            }
            .alert("Удалить банк?", isPresented: $confirmDelete) {
                Button("Отмена", role: .cancel) {}
                Button("Удалить", role: .destructive) {
                    appState.deleteBank(bankId)
                    dismiss()
                }
            } message: {
                Text("Банк будет удалён вместе со всеми его счетами. Уже сохранённые операции не изменятся.")
            }
        } else {
            ContentUnavailableView("Банк удалён", systemImage: "building.columns")
        }
    }
}

// MARK: - Счёт

struct AccountScreen: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let accountId: UUID
    @State private var confirmDelete = false

    private var account: Account? { appState.data.accounts.first { $0.id == accountId } }

    var body: some View {
        if let account {
            List {
                Section("Название") {
                    NameField(initial: account.name, placeholder: "Название счёта") {
                        appState.renameAccount(accountId, to: $0)
                    }
                }

                Section {
                    ForEach(Currency.allCases) { cur in
                        ChoiceRow(title: cur.title,
                                  detail: "\(cur.symbol)  \(cur.code)",
                                  selected: account.effectiveCurrency == cur) {
                            appState.setAccountCurrency(accountId, cur)
                        }
                    }
                } header: {
                    Text("Валюта счёта")
                } footer: {
                    Text("Валюта подставляется в форму, когда вы выбираете этот счёт. При вводе её можно поменять.")
                }

                Section {
                    ChoiceRow(title: "Открыт", symbol: "checkmark.circle.fill", color: .green,
                              selected: !account.isClosed) {
                        appState.setAccountClosed(accountId, false)
                    }
                    ChoiceRow(title: "Закрыт", symbol: "xmark.circle.fill", color: .gray,
                              selected: account.isClosed) {
                        appState.setAccountClosed(accountId, true)
                    }
                } header: {
                    Text("Состояние")
                } footer: {
                    Text("Остаток по закрытому счёту продолжает считаться — он просто уходит в конец таблицы.")
                }

                Section {
                    DestructiveRow(title: "Удалить счёт") { confirmDelete = true }
                }
            }
            .navigationTitle(account.name)
            .navigationBarTitleDisplayMode(.inline)
            .themedList()
            .alert("Удалить счёт?", isPresented: $confirmDelete) {
                Button("Отмена", role: .cancel) {}
                Button("Удалить", role: .destructive) {
                    appState.deleteAccount(accountId)
                    dismiss()
                }
            } message: {
                Text("Счёт будет удалён из справочника. Уже сохранённые операции не изменятся.")
            }
        } else {
            ContentUnavailableView("Счёт удалён", systemImage: "creditcard")
        }
    }
}

// MARK: - Операция

struct OperationTypeScreen: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let opId: UUID
    @State private var confirmDelete = false

    private var op: OperationType? { appState.data.optypes.first { $0.id == opId } }
    private var categories: [Category] { appState.data.categories.filter { $0.opId == opId } }

    var body: some View {
        if let op {
            List {
                Section("Название") {
                    NameField(initial: op.name, placeholder: "Название операции") {
                        appState.renameOperationType(opId, to: $0)
                    }
                }

                Section {
                    ForEach(OpKind.allCases) { kind in
                        ChoiceRow(title: kind.title,
                                  symbol: kind.symbol,
                                  color: color(for: kind),
                                  selected: op.effectiveKind == kind) {
                            appState.setOperationKind(opId, kind)
                        }
                    }
                } header: {
                    Text("Группа в статистике")
                } footer: {
                    Text("Это только группа — знак суммы задаёте вы сами при вводе, и он остаётся таким, как вы ввели. «Не учитывать» исключает операцию из доходов и расходов, но на остаток счёта она всё равно влияет.")
                }

                Section {
                    ForEach(categories) { cat in
                        NavigationLink(value: DirectoryRoute.category(cat.id)) {
                            DirectoryRow(name: cat.name, detail: subcategoriesNote(cat))
                        }
                        .accessibilityIdentifier("dir_" + cat.name)
                    }
                    .onMove { appState.moveCategories(in: opId, $0, $1) }
                    AddRow(placeholder: "Новая категория") { name in
                        guard appState.nameIsFree(name, among: categories.map { $0.name }) else { return false }
                        appState.data.categories.append(Category(name: name, opId: opId))
                        appState.persist()
                        return true
                    }
                } header: {
                    Text("Категории")
                } footer: {
                    Text("Нажмите на категорию, чтобы настроить её подкатегории.")
                }

                Section {
                    DestructiveRow(title: "Удалить операцию") { confirmDelete = true }
                }
            }
            .navigationTitle(op.name)
            .navigationBarTitleDisplayMode(.inline)
            .themedList()
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { EditButton() }
            }
            .alert("Удалить операцию?", isPresented: $confirmDelete) {
                Button("Отмена", role: .cancel) {}
                Button("Удалить", role: .destructive) {
                    appState.deleteOperationType(opId)
                    dismiss()
                }
            } message: {
                Text("Операция будет удалена вместе со всеми категориями и подкатегориями внутри неё. Уже сохранённые операции не изменятся.")
            }
        } else {
            ContentUnavailableView("Операция удалена", systemImage: "square.grid.2x2")
        }
    }

    private func subcategoriesNote(_ cat: Category) -> String {
        let n = appState.data.subcategories.filter { $0.catId == cat.id }.count
        return n == 0 ? "нет подкатегорий" : "\(n)"
    }

    private func color(for kind: OpKind) -> Color {
        switch kind {
        case .income: return Theme.income
        case .expense: return Theme.expense
        case .neutral: return .gray
        }
    }
}

// MARK: - Категория

struct CategoryScreen: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let catId: UUID
    @State private var confirmDelete = false

    private var cat: Category? { appState.data.categories.first { $0.id == catId } }
    private var subs: [Subcategory] { appState.data.subcategories.filter { $0.catId == catId } }

    var body: some View {
        if let cat {
            List {
                Section("Название") {
                    NameField(initial: cat.name, placeholder: "Название категории") {
                        appState.renameCategory(catId, to: $0)
                    }
                }

                Section {
                    ForEach(subs) { sub in
                        EditableRow(name: sub.name,
                                    onRename: { appState.renameSubcategory(sub.id, to: $0) },
                                    onDelete: { appState.deleteSubcategory(sub.id) })
                    }
                    .onMove { appState.moveSubcategories(in: catId, $0, $1) }
                    AddRow(placeholder: "Новая подкатегория") { name in
                        guard appState.nameIsFree(name, among: subs.map { $0.name }) else { return false }
                        appState.data.subcategories.append(Subcategory(name: name, catId: catId))
                        appState.persist()
                        return true
                    }
                } header: {
                    Text("Подкатегории")
                } footer: {
                    Text("Это нижний уровень справочника. Порядок можно менять кнопкой «Изменить».")
                }

                Section {
                    DestructiveRow(title: "Удалить категорию") { confirmDelete = true }
                }
            }
            .navigationTitle(cat.name)
            .navigationBarTitleDisplayMode(.inline)
            .themedList()
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) { EditButton() }
            }
            .alert("Удалить категорию?", isPresented: $confirmDelete) {
                Button("Отмена", role: .cancel) {}
                Button("Удалить", role: .destructive) {
                    appState.deleteCategory(catId)
                    dismiss()
                }
            } message: {
                Text("Категория будет удалена вместе с подкатегориями. Уже сохранённые операции не изменятся.")
            }
        } else {
            ContentUnavailableView("Категория удалена", systemImage: "square.grid.2x2")
        }
    }
}

// MARK: - Категория лиц

struct PersonGroupScreen: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let groupId: UUID
    @State private var confirmDelete = false

    private var group: PersonGroup? { appState.data.personGroups.first { $0.id == groupId } }
    private var people: [Person] { appState.data.personsOrdered(in: groupId) }

    var body: some View {
        if let group {
            List {
                Section("Название") {
                    NameField(initial: group.name, placeholder: "Название категории") {
                        appState.renamePersonGroup(groupId, to: $0)
                    }
                }

                Section {
                    ForEach(people) { person in
                        NavigationLink(value: DirectoryRoute.person(person.id)) {
                            PersonRow(person: person, uses: appState.data.usageCount(person.name))
                        }
                        .accessibilityIdentifier("dir_" + person.name)
                        .swipeActions(edge: .leading) {
                            Button {
                                appState.setPersonPinned(person.id, !person.isPinned)
                            } label: {
                                Label(person.isPinned ? "Открепить" : "Закрепить",
                                      systemImage: person.isPinned ? "pin.slash" : "pin")
                            }
                            .tint(.orange)
                        }
                    }
                    AddRow(placeholder: "Новое лицо") { name in
                        guard appState.nameIsFree(name, among: appState.data.persons.map { $0.name }) else { return false }
                        appState.data.persons.append(Person(name: name, groupId: groupId))
                        appState.persist()
                        return true
                    }
                } header: {
                    Text("Лица")
                } footer: {
                    Text("Порядок считается сам: сначала закреплённые, дальше по числу операций. Закрепить можно смахиванием строки вправо.")
                }

                if appState.data.personGroups.count > 1 {
                    Section {
                        DestructiveRow(title: "Удалить категорию") { confirmDelete = true }
                    }
                }
            }
            .navigationTitle(group.name)
            .navigationBarTitleDisplayMode(.inline)
            .themedList()
            .alert("Удалить категорию лиц?", isPresented: $confirmDelete) {
                Button("Отмена", role: .cancel) {}
                Button("Удалить", role: .destructive) {
                    appState.deletePersonGroup(groupId)
                    dismiss()
                }
            } message: {
                Text("Сами лица не пропадут — они переедут в первую оставшуюся категорию.")
            }
        } else {
            ContentUnavailableView("Категория удалена", systemImage: "person.2")
        }
    }
}

/// Строка лица: имя, закрепление и сколько раз встречается в операциях
struct PersonRow: View {
    let person: Person
    let uses: Int

    var body: some View {
        HStack(spacing: Theme.gap) {
            if person.isPinned {
                Image(systemName: "pin.fill")
                    .font(Theme.caption)
                    .foregroundStyle(.orange)
                    .accessibilityLabel("Закреплено")
            }
            Text(person.name).font(Theme.body)
            Spacer(minLength: Theme.gap)
            Text(uses == 0 ? "не использовалось" : "\(uses)")
                .font(Theme.caption)
                .foregroundStyle(.secondary)
                .monospacedDigit()
        }
    }
}

// MARK: - Лицо

struct PersonScreen: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let personId: UUID
    @State private var confirmDelete = false

    private var person: Person? { appState.data.persons.first { $0.id == personId } }

    var body: some View {
        if let person {
            List {
                Section("Имя") {
                    NameField(initial: person.name, placeholder: "Имя или название") {
                        appState.renamePerson(personId, to: $0)
                    }
                }

                Section {
                    ChoiceRow(title: "Закрепить сверху", symbol: "pin.fill", color: .orange,
                              selected: person.isPinned) {
                        appState.setPersonPinned(personId, !person.isPinned)
                    }
                } footer: {
                    Text("Закреплённые лица всегда идут первыми, не считаясь с частотностью.")
                }

                Section {
                    ForEach(appState.data.personGroups) { group in
                        ChoiceRow(title: group.name, selected: person.groupId == group.id) {
                            appState.setPersonGroup(personId, group.id)
                        }
                    }
                } header: {
                    Text("Категория")
                } footer: {
                    Text("Операций с этим лицом: \(appState.data.usageCount(person.name)).")
                }

                Section {
                    DestructiveRow(title: "Удалить лицо") { confirmDelete = true }
                }
            }
            .navigationTitle(person.name)
            .navigationBarTitleDisplayMode(.inline)
            .themedList()
            .alert("Удалить лицо?", isPresented: $confirmDelete) {
                Button("Отмена", role: .cancel) {}
                Button("Удалить", role: .destructive) {
                    appState.deletePerson(personId)
                    dismiss()
                }
            } message: {
                Text("Лицо будет удалено из справочника. Уже сохранённые операции не изменятся.")
            }
        } else {
            ContentUnavailableView("Лицо удалено", systemImage: "person")
        }
    }
}
