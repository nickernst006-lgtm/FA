import SwiftUI
import Charts

struct StatsView: View {
    @EnvironmentObject var appState: AppState

    enum Period: String, CaseIterable, Identifiable {
        case month = "Месяц"
        case year = "Год"
        case all = "Всё время"
        var id: String { rawValue }
    }
    @State private var period: Period = .month

    struct Total: Identifiable {
        let name: String
        let value: Double
        var id: String { name }
    }

    struct MonthPoint: Identifiable {
        let month: String   // "2026-09"
        let kind: String    // "Доходы" / "Расходы"
        let value: Double
        var id: String { month + kind }
        /// "2026-09" → "сен"
        var label: String {
            let names = ["янв", "фев", "мар", "апр", "май", "июн", "июл", "авг", "сен", "окт", "ноя", "дек"]
            let parts = month.split(separator: "-")
            guard parts.count == 2, let m = Int(parts[1]), (1...12).contains(m) else { return month }
            return names[m - 1]
        }
    }

    var operations: [OperationRecord] {
        let today = DateFmt.dayString(Date())
        switch period {
        case .all: return appState.data.operations
        case .month:
            let prefix = String(today.prefix(7))
            return appState.data.operations.filter { $0.date.hasPrefix(prefix) }
        case .year:
            let prefix = String(today.prefix(4))
            return appState.data.operations.filter { $0.date.hasPrefix(prefix) }
        }
    }

    var periodTitle: String {
        let today = DateFmt.dayString(Date())
        switch period {
        case .month: return DateFmt.monthTitle(String(today.prefix(7)))
        case .year: return "\(today.prefix(4)) год"
        case .all: return "За всё время"
        }
    }

    /// Суммы по разрезу. Знак берётся как есть, а порядок — по величине
    /// (по модулю), чтобы самые крупные строки были сверху независимо от знака.
    func totals(_ ops: [OperationRecord], key: (OperationRecord) -> String, limit: Int) -> [Total] {
        var dict: [String: Double] = [:]
        for op in ops { dict[key(op), default: 0] += op.amount }
        let sorted = dict.map { Total(name: $0.key.isEmpty ? "Без названия" : $0.key, value: $0.value) }
            .sorted { abs($0.value) > abs($1.value) }
        guard sorted.count > limit else { return sorted }
        let rest = sorted[limit...].reduce(0) { $0 + $1.value }
        return Array(sorted.prefix(limit)) + [Total(name: "Остальное", value: rest)]
    }

    func monthPoints(_ ops: [OperationRecord]) -> [MonthPoint] {
        let data = appState.data
        var dict: [String: (income: Double, expense: Double)] = [:]
        for op in ops {
            guard op.date.count >= 7 else { continue }
            let m = String(op.date.prefix(7))
            var cur = dict[m] ?? (income: 0, expense: 0)
            switch data.kind(of: op) {
            case .income: cur.income += op.amount
            case .expense: cur.expense += op.amount
            case .neutral: break
            }
            dict[m] = cur
        }
        var points: [MonthPoint] = []
        for m in dict.keys.sorted().suffix(12) {
            let v = dict[m] ?? (income: 0, expense: 0)
            points.append(MonthPoint(month: m, kind: "Доходы", value: v.income))
            points.append(MonthPoint(month: m, kind: "Расходы", value: v.expense))
        }
        return points
    }

    var body: some View {
        let ops = operations
        let data = appState.data
        // Знак берётся из самой операции: тип только распределяет по группам
        let income = ops.filter { data.isIncome($0) }.reduce(0) { $0 + $1.amount }
        let expense = ops.filter { data.isExpense($0) }.reduce(0) { $0 + $1.amount }
        let balance = income + expense
        let expenseByCategory = totals(ops.filter { data.isExpense($0) }, key: { $0.category }, limit: 6)
        let incomeByCategory = totals(ops.filter { data.isIncome($0) }, key: { $0.category }, limit: 6)
        let byAccount = totals(ops, key: { "\($0.bank), \($0.account)" }, limit: 8)
        let byPerson = totals(ops.filter { !$0.person.isEmpty }, key: { $0.person }, limit: 8)
        let points = monthPoints(appState.data.operations)

        List {
            Section {
                Picker("Период", selection: $period) {
                    ForEach(Period.allCases) { p in Text(p.rawValue).tag(p) }
                }
                .pickerStyle(.segmented)
            }
            .listRowBackground(Color.clear)
            .listRowInsets(EdgeInsets(top: 0, leading: 0, bottom: 4, trailing: 0))

            Section {
                VStack(alignment: .leading, spacing: Theme.gap) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text(periodTitle).font(Theme.detail).foregroundStyle(.secondary)
                        Text(Money.format(balance) + " ₽")
                            .font(Theme.hero(40))
                            .foregroundStyle(balance < 0 ? Color.red : Color.primary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.5)
                    }
                    HStack(spacing: Theme.gap) {
                        statTile("Доходы", income, Theme.income, "arrow.down")
                        statTile("Расходы", expense, Theme.expense, "arrow.up")
                    }
                }
                .padding(.vertical, Theme.gap / 2)
            }

            if ops.isEmpty {
                Section {
                    ContentUnavailableView("Нет операций",
                                           systemImage: "chart.pie",
                                           description: Text("За выбранный период операций нет."))
                }
            } else {
                if !expenseByCategory.isEmpty {
                    Section("Расходы по категориям") {
                        donut(expenseByCategory, total: expense)
                        legend(expenseByCategory, total: expense)
                    }
                }
                if !incomeByCategory.isEmpty {
                    Section("Доходы по категориям") {
                        legend(incomeByCategory, total: income)
                    }
                }
            }

            if points.count >= 2 {
                Section("По месяцам") {
                    Chart {
                        ForEach(points) { p in
                            BarMark(
                                x: .value("Месяц", p.label),
                                y: .value("Сумма", p.value),
                                width: .ratio(0.7)
                            )
                            .cornerRadius(4)
                            .foregroundStyle(by: .value("Тип", p.kind))
                            .position(by: .value("Тип", p.kind))
                        }
                        RuleMark(y: .value("Ноль", 0))
                            .lineStyle(StrokeStyle(lineWidth: 1))
                            .foregroundStyle(Color.secondary.opacity(0.45))
                    }
                    .chartForegroundStyleScale(["Доходы": Theme.income, "Расходы": Theme.expense])
                    .chartLegend(position: .top, alignment: .leading)
                    .chartYAxis {
                        AxisMarks(position: .trailing) { _ in
                            AxisGridLine(stroke: StrokeStyle(lineWidth: 0.5, dash: [3]))
                            AxisValueLabel()
                        }
                    }
                    .frame(height: 220)
                    .padding(.vertical, Theme.gap)
                }
            }

            if !ops.isEmpty {
                Section("Счета") { plainList(byAccount) }
                if !byPerson.isEmpty {
                    Section("Лица") { plainList(byPerson) }
                }
            }
        }
        .navigationTitle("Статистика")
        .themedList()
        .animation(.default, value: period)
    }

    private func statTile(_ title: String, _ value: Double, _ color: Color, _ symbol: String) -> some View {
        VStack(alignment: .leading, spacing: 4) {
            Label(title, systemImage: symbol)
                .font(Theme.detail)
                .foregroundStyle(color)
            Text(Money.format(value))
                .font(Theme.bodyStrong.monospacedDigit())
                .lineLimit(1)
                .minimumScaleFactor(0.6)
        }
        .padding(Theme.gap)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(color.opacity(0.1), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
    }

    /// Доли на круге считаются по величине суммы (по модулю) — знак на угол не влияет
    private func donut(_ items: [Total], total: Double) -> some View {
        Chart(Array(items.enumerated()), id: \.element.id) { index, item in
            SectorMark(
                angle: .value("Сумма", abs(item.value)),
                innerRadius: .ratio(0.64),
                angularInset: 1.5
            )
            .cornerRadius(4)
            .foregroundStyle(Theme.color(at: index))
        }
        .chartBackground { _ in
            VStack(spacing: 2) {
                Text("Всего").font(Theme.detail).foregroundStyle(.secondary)
                Text(Money.format(total))
                    .font(Theme.bodyStrong.monospacedDigit())
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)
                    .frame(maxWidth: 120)
            }
        }
        .frame(height: 220)
        .padding(.vertical, Theme.gap)
    }

    private func legend(_ items: [Total], total: Double) -> some View {
        ForEach(Array(items.enumerated()), id: \.element.id) { index, item in
            HStack(spacing: Theme.gap) {
                Circle().fill(Theme.color(at: index)).frame(width: 10, height: 10)
                Text(item.name).font(Theme.body).lineLimit(1)
                Spacer()
                Text(abs(total) > 0 ? "\(Int((abs(item.value) / abs(total) * 100).rounded())) %" : "")
                    .font(Theme.detail).foregroundStyle(.secondary).monospacedDigit()
                Text(Money.format(item.value))
                    .font(Theme.body).monospacedDigit()
            }
        }
    }

    private func plainList(_ items: [Total]) -> some View {
        let maxVal = max(items.map { abs($0.value) }.max() ?? 1, 0.01)
        return ForEach(items) { item in
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(item.name).font(Theme.body).lineLimit(1)
                    Spacer()
                    Text(Money.format(item.value)).font(Theme.body).monospacedDigit()
                }
                GeometryReader { geo in
                    Capsule()
                        .fill(Color.accentColor.opacity(0.18))
                        .overlay(alignment: .leading) {
                            Capsule()
                                .fill(Color.accentColor.gradient)
                                .frame(width: max(4, geo.size.width * CGFloat(abs(item.value) / maxVal)))
                        }
                }
                .frame(height: 5)
            }
            .padding(.vertical, 2)
        }
    }
}
