import SwiftUI

/// Единая дизайн-система приложения (в духе Apple Human Interface Guidelines).
///
/// Типографика — только три уровня, один шрифт (системный SF):
///   • крупный  — заголовки разделов (большие заголовки навигации) и главная сумма;
///   • средний  — основной текст строк (`Theme.body`);
///   • малый    — уточнения серым цветом (`Theme.detail`).
/// Отступы — один шаг сетки `Theme.gap` и одинаковое расстояние между блоками.
enum Theme {
    // Типографика
    static let body: Font = .body
    static let bodyStrong: Font = .body.weight(.semibold)
    static let detail: Font = .subheadline
    static func hero(_ size: CGFloat = 40) -> Font { .system(size: size, weight: .bold).monospacedDigit() }

    // Отступы
    static let gap: CGFloat = 12          // между элементами внутри строки
    static let sectionSpacing: CGFloat = 24  // между блоками на всех экранах
    static let iconSize: CGFloat = 30

    // Цвета
    static let income = Color.green
    static let expense = Color.orange
    static let palette: [Color] = [.blue, .orange, .purple, .teal, .pink, .indigo, .mint, .yellow, .red, .cyan]
    static func color(at index: Int) -> Color { palette[index % palette.count] }
}

extension View {
    /// Одинаковое расстояние между блоками на всех экранах
    func themedList() -> some View {
        self.listSectionSpacing(Theme.sectionSpacing)
    }
}

/// Цветной квадратик с иконкой — как в «Настройках» iPhone
struct IconBadge: View {
    let symbol: String
    let color: Color
    var size: CGFloat = Theme.iconSize

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.5, weight: .semibold))
            .foregroundStyle(.white)
            .frame(width: size, height: size)
            .background(color.gradient, in: RoundedRectangle(cornerRadius: size * 0.24, style: .continuous))
            .accessibilityHidden(true)
    }
}

/// Строка «иконка + текст» — одинаковая во всех списках
struct IconRow: View {
    let title: String
    let symbol: String
    let color: Color

    var body: some View {
        HStack(spacing: Theme.gap) {
            IconBadge(symbol: symbol, color: color)
            Text(title).font(Theme.body)
        }
    }
}

/// Строка-пояснение с иконкой (для экрана «О приложении»)
struct FeatureRow: View {
    let symbol: String
    let color: Color
    let title: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: Theme.gap) {
            IconBadge(symbol: symbol, color: color)
            VStack(alignment: .leading, spacing: 2) {
                Text(title).font(Theme.body)
                Text(text).font(Theme.detail).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

/// Сумма ровно с тем знаком, который ввёл пользователь.
/// Тип операции («Доход»/«Расход») знак НЕ меняет — он только группирует.
/// Плюс показывается зелёным, минус — основным цветом (как в Wallet).
struct AmountText: View {
    let amount: Double
    var font: Font = Theme.bodyStrong

    var body: some View {
        Text(Money.format(amount) + " ₽")
            .font(font)
            .monospacedDigit()
            .foregroundStyle(amount > 0 ? Theme.income : Color.primary)
            .lineLimit(1)
            .layoutPriority(1)
    }
}
