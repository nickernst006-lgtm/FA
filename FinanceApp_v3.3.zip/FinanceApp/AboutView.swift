import SwiftUI

struct AboutView: View {
    @EnvironmentObject var appState: AppState
    @State private var showResetSheet = false
    @State private var resetConfirmText = ""
    @State private var showChangePassword = false

    var appVersion: String {
        let v = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "3.3"
        return v
    }

    var body: some View {
        List {
            Section {
                VStack(spacing: 10) {
                    AppBadge(size: 88)
                        .shadow(color: .black.opacity(0.15), radius: 12, y: 6)
                    Text("N Finance").font(.title2.bold())
                    Text("Версия \(appVersion)").font(Theme.detail).foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, Theme.gap)
            }
            .listRowBackground(Color.clear)

            Section {
                Button {
                    appState.lock()
                } label: {
                    IconRow(title: "Заблокировать сейчас", symbol: "lock.fill", color: .blue)
                        .foregroundStyle(Color.primary)
                }
                Button {
                    showChangePassword = true
                } label: {
                    HStack {
                        IconRow(title: "Сменить пароль", symbol: "key.fill", color: .gray)
                            .foregroundStyle(Color.primary)
                        Spacer()
                        Image(systemName: "chevron.right").font(Theme.detail.weight(.semibold)).foregroundStyle(.tertiary)
                    }
                }
            }

            Section("Как защищены данные") {
                FeatureRow(symbol: "wifi.slash", color: .green, title: "Без интернета",
                           text: "В приложении нет ни одного сетевого запроса. Серверов и облака нет.")
                FeatureRow(symbol: "iphone", color: .blue, title: "Только на этом iPhone",
                           text: "Данные лежат во внутренней папке приложения и не попадают в резервные копии iCloud.")
                FeatureRow(symbol: "lock.shield.fill", color: .indigo, title: "Шифрование AES-256",
                           text: "Ключ выводится из пароля (PBKDF2, 250 000 итераций). Пароль нигде не хранится.")
                FeatureRow(symbol: "timer", color: .orange, title: "Автоблокировка",
                           text: "Через 5 минут бездействия ключ удаляется из памяти. В переключателе приложений содержимое скрыто.")
                FeatureRow(symbol: "square.and.arrow.up", color: .teal, title: "Экспорт только вручную",
                           text: "Данные покидают приложение только через экспорт в Excel. Временный файл сразу удаляется.")
            }

            Section {
                Button(role: .destructive) {
                    resetConfirmText = ""
                    showResetSheet = true
                } label: {
                    IconRow(title: "Сбросить приложение", symbol: "trash.fill", color: .red)
                }
            } footer: {
                Text("Удаляет все операции, справочники и пароль. Действие нельзя отменить.")
            }
        }
        .navigationTitle("О приложении")
        .themedList()
        .sheet(isPresented: $showChangePassword) {
            ChangePasswordView()
                .environmentObject(appState)
        }
        .sheet(isPresented: $showResetSheet) {
            NavigationStack {
                Form {
                    Section {
                        Text("Будут уничтожены все операции, справочники и пароль. Восстановить их будет невозможно.")
                    }
                    Section {
                        TextField("Введите УДАЛИТЬ", text: $resetConfirmText)
                            .textInputAutocapitalization(.characters)
                            .autocorrectionDisabled()
                    } footer: {
                        Text("Для подтверждения введите слово УДАЛИТЬ заглавными буквами.")
                    }
                    Section {
                        Button("Удалить всё", role: .destructive) {
                            appState.fullReset()
                            showResetSheet = false
                        }
                        .frame(maxWidth: .infinity)
                        .disabled(resetConfirmText.trimmingCharacters(in: .whitespaces) != "УДАЛИТЬ")
                    }
                }
                .navigationTitle("Сброс")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Отмена") { showResetSheet = false }
                    }
                }
            }
            .presentationDetents([.medium, .large])
        }
    }
}

struct ChangePasswordView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    @State private var oldPw = ""
    @State private var newPw1 = ""
    @State private var newPw2 = ""
    @State private var errorText = ""
    @State private var done = false

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField("Текущий пароль", text: $oldPw)
                }
                Section {
                    SecureField("Новый пароль (мин. 4 символа)", text: $newPw1)
                    SecureField("Повторите новый пароль", text: $newPw2)
                } footer: {
                    Text("Все данные будут перешифрованы новым ключом. Забытый пароль восстановить невозможно.")
                }
                if !errorText.isEmpty {
                    Section { Text(errorText).foregroundStyle(.red).font(Theme.detail) }
                }
                if done {
                    Section { Label("Пароль изменён", systemImage: "checkmark.circle.fill").foregroundStyle(.green) }
                }
                Section {
                    Button {
                        submit()
                    } label: {
                        HStack {
                            if appState.isBusy { ProgressView() }
                            Text(appState.isBusy ? "Перешифровка…" : "Сменить пароль")
                        }
                        .frame(maxWidth: .infinity)
                    }
                    .disabled(appState.isBusy || done || oldPw.isEmpty || newPw1.isEmpty)
                }
            }
            .navigationTitle("Смена пароля")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(done ? "Готово" : "Отмена") { dismiss() }
                }
            }
            .interactiveDismissDisabled(appState.isBusy)
        }
    }

    func submit() {
        errorText = ""
        guard newPw1 == newPw2 else { errorText = "Новые пароли не совпадают."; return }
        guard newPw1 != oldPw else { errorText = "Новый пароль совпадает с текущим."; return }
        let old = oldPw, new = newPw1
        Task {
            if let err = await appState.changePassword(old: old, new: new) {
                errorText = err
            } else {
                oldPw = ""; newPw1 = ""; newPw2 = ""
                done = true
            }
        }
    }
}
