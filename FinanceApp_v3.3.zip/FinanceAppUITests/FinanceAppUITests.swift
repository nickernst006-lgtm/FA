import XCTest

// UI-тесты: запускают приложение в симуляторе iPhone в облаке, «нажимают»
// кнопки как человек и сохраняют скриншоты каждого экрана.

final class FinanceAppUITests: XCTestCase {

    private let password = "test1234"

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    @MainActor
    private func snap(_ app: XCUIApplication, _ name: String) {
        let a = XCTAttachment(screenshot: app.screenshot())
        a.name = name
        a.lifetime = .keepAlways
        add(a)
    }

    /// Создаёт пароль при первом запуске или входит, если пароль уже есть
    @MainActor
    private func unlock(_ app: XCUIApplication, screenshotPrefix: String? = nil) {
        let setup1 = app.secureTextFields["setupPassword1"]
        let login = app.secureTextFields["loginPassword"]
        let appeared = setup1.waitForExistence(timeout: 10) || login.waitForExistence(timeout: 2)
        XCTAssertTrue(appeared, "не появился экран пароля")

        if setup1.exists {
            if let p = screenshotPrefix { snap(app, "\(p)_Создание_пароля") }
            setup1.tap()
            setup1.typeText(password)
            let setup2 = app.secureTextFields["setupPassword2"]
            setup2.tap()
            setup2.typeText(password)
            app.buttons["setupSubmit"].tap()
        } else {
            if let p = screenshotPrefix { snap(app, "\(p)_Вход") }
            login.tap()
            login.typeText(password)
            app.buttons["loginSubmit"].tap()
        }
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 60), "не открылся главный экран")
    }

    /// Тест 0: пустая история — проверяем, что заглушка ровно по центру экрана
    @MainActor
    func test0_EmptyHistoryIsCentered() throws {
        let app = XCUIApplication()
        app.launch()
        unlock(app)

        tab(app, 1)
        let title = app.staticTexts["Операций пока нет"]
        XCTAssertTrue(title.waitForExistence(timeout: 10), "нет заглушки пустой истории")
        snap(app, "00_История_пустая")

        // Заглушка должна стоять по центру списка по горизонтали и вертикали
        let screen = app.windows.firstMatch.frame
        let box = title.frame
        let dx = abs(box.midX - screen.midX)
        XCTAssertLessThan(dx, 8, "заглушка не по центру по горизонтали")
        XCTAssertGreaterThan(box.midY, screen.height * 0.3, "заглушка прижата к верху экрана")
        XCTAssertLessThan(box.midY, screen.height * 0.7, "заглушка прижата к низу экрана")
    }

    /// Тест 1: проходит по всем вкладкам и делает скриншоты
    @MainActor
    func test1_AllScreensScreenshots() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-uiTestDemo"]
        app.launch()
        unlock(app, screenshotPrefix: "01")

        snap(app, "02_Форма")

        tab(app, 1)
        _ = app.staticTexts["15.09.2026"].waitForExistence(timeout: 5)
        snap(app, "03_История")

        tab(app, 2)
        sleep(1)
        snap(app, "04_Статистика")
        app.swipeUp()
        snap(app, "05_Статистика_ниже")

        tab(app, 3)
        sleep(1)
        snap(app, "06_Настройки")

        tab(app, 4)
        sleep(1)
        snap(app, "07_О_приложении")

        // Блокировка вручную и повторный вход
        app.buttons["Заблокировать сейчас"].tap()
        XCTAssertTrue(app.secureTextFields["loginPassword"].waitForExistence(timeout: 5), "не заблокировалось")
        snap(app, "08_Заблокировано")
        let login = app.secureTextFields["loginPassword"]
        login.tap()
        login.typeText("wrong-password")
        app.buttons["loginSubmit"].tap()
        XCTAssertTrue(app.staticTexts["Неверный пароль. Попробуйте снова."].waitForExistence(timeout: 30))
        snap(app, "09_Неверный_пароль")
        login.tap()
        login.typeText(password)
        app.buttons["loginSubmit"].tap()
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 60))
    }

    /// Тест 2: заполняет форму как пользователь и проверяет, что операция сохранилась
    @MainActor
    func test2_AddOperationThroughForm() throws {
        let app = XCUIApplication()
        app.launch()
        unlock(app)

        tab(app, 0)

        // Дата
        app.buttons["Выбрать"].firstMatch.tap()

        // Банк → Счёт (зависимый список)
        choose(app, picker: "Банк", option: "Тинькофф")
        choose(app, picker: "Счёт", option: "Основной")
        // Операция → Категория → Подкатегория
        choose(app, picker: "Операция", option: "Трата")
        choose(app, picker: "Категория", option: "Еда")
        choose(app, picker: "Подкатегория", option: "Продукты")

        // Лицо через поиск
        app.buttons["personButton"].tap()
        let search = app.searchFields.firstMatch
        XCTAssertTrue(search.waitForExistence(timeout: 5))
        search.tap()
        search.typeText("Petr")   // такого лица нет — проверим кнопку «Добавить в справочник»
        snap(app, "10_Поиск_лица")
        let add = app.buttons.matching(NSPredicate(format: "label BEGINSWITH 'Добавить'")).firstMatch
        XCTAssertTrue(add.waitForExistence(timeout: 5), "нет кнопки добавления лица")
        add.tap()
        XCTAssertTrue(app.buttons["personButton"].waitForExistence(timeout: 5), "окно выбора лица не закрылось")

        // Сумма со знаком: минус ставит сам пользователь, тип операции знак не меняет
        let amount = app.textFields["amountField"]
        amount.tap()
        amount.typeText("1500,50")
        let minusButton = app.buttons["signMinus"]
        XCTAssertTrue(minusButton.waitForExistence(timeout: 5), "нет переключателя знака")
        minusButton.tap()
        snap(app, "11_Форма_заполнена")

        let done = app.buttons["Готово"].firstMatch
        if done.exists && done.isHittable { done.tap() }
        let save = app.buttons["saveButton"]
        if !save.isHittable { app.swipeUp() }
        save.tap()

        XCTAssertTrue(app.descendants(matching: .any)
                        .matching(NSPredicate(format: "label CONTAINS 'Операция сохранена'"))
                        .firstMatch.waitForExistence(timeout: 5),
                      "не появилось подтверждение сохранения")
        snap(app, "12_Сохранено")

        tab(app, 1)
        let found = app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS '500,50'")).firstMatch
        XCTAssertTrue(found.waitForExistence(timeout: 5), "новая операция не появилась в истории")
        // Введённый минус должен сохраниться как есть
        let negative = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "\u{2212}1")).firstMatch
        XCTAssertTrue(negative.waitForExistence(timeout: 5), "минус не сохранился в сумме")
        snap(app, "13_История_с_новой_операцией")
    }

    /// Тест 3: экран операции, окно подтверждения удаления и настройка группы операции
    @MainActor
    func test3_DetailDeleteAlertAndOperationEditor() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-uiTestDemo"]
        app.launch()
        unlock(app)

        // Экран одной операции
        tab(app, 1)
        let firstRow = app.cells.element(boundBy: 0)
        XCTAssertTrue(firstRow.waitForExistence(timeout: 10), "нет строк в истории")
        firstRow.tap()

        let deleteButton = app.buttons["Удалить операцию"]
        XCTAssertTrue(deleteButton.waitForExistence(timeout: 10), "не открылся экран операции")
        snap(app, "14_Экран_операции")

        // Окно подтверждения должно быть системным алертом по центру
        deleteButton.tap()
        let alert = app.alerts.firstMatch
        XCTAssertTrue(alert.waitForExistence(timeout: 5), "нет окна подтверждения удаления")
        snap(app, "15_Подтверждение_удаления")
        let screen = app.windows.firstMatch.frame
        XCTAssertLessThan(abs(alert.frame.midX - screen.midX), 8, "окно не по центру по горизонтали")
        XCTAssertLessThan(abs(alert.frame.midY - screen.midY), screen.height * 0.2, "окно не по центру по вертикали")
        alert.buttons["Отмена"].tap()

        // Группа операции — по нажатию на название операции
        tab(app, 3)
        let opName = app.buttons.matching(NSPredicate(format: "label BEGINSWITH 'Настроить'")).firstMatch
        XCTAssertTrue(opName.waitForExistence(timeout: 10), "нет кнопки настройки операции")
        opName.tap()
        XCTAssertTrue(app.staticTexts["Группа в статистике"].waitForExistence(timeout: 5),
                      "не открылся экран настройки операции")
        snap(app, "16_Настройка_операции")
        app.buttons["Отмена"].firstMatch.tap()
    }

    /// Вкладки теперь без подписей — нажимаем по порядку: 0 Форма, 1 История, 2 Статистика, 3 Настройки, 4 О приложении
    @MainActor
    private func tab(_ app: XCUIApplication, _ index: Int) {
        let button = app.tabBars.buttons.element(boundBy: index)
        XCTAssertTrue(button.waitForExistence(timeout: 10), "нет вкладки \(index)")
        button.tap()
    }

    /// Выбор значения в выпадающем списке формы
    @MainActor
    private func choose(_ app: XCUIApplication, picker: String, option: String) {
        let row = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", picker)).firstMatch
        XCTAssertTrue(row.waitForExistence(timeout: 5), "нет списка \(picker)")
        if !row.isHittable { app.swipeUp() }
        row.tap()
        let item = app.buttons[option].firstMatch
        XCTAssertTrue(item.waitForExistence(timeout: 5), "в списке \(picker) нет «\(option)»")
        item.tap()
    }
}
