import SwiftUI
import UIKit

struct FormView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var onSaved: () -> Void

    @State private var date: Date? = nil
    @State private var time: Date? = nil
    @State private var bankId: UUID? = nil
    @State private var accountId: UUID? = nil
    @State private var opId: UUID? = nil
    @State private var categoryId: UUID? = nil
    @State private var subcategoryId: UUID? = nil
    @State private var personName: String = ""
    @State private var amountText: String = ""
    @State private var isNegative: Bool = false
    @State private var currency: Currency = .rub
    @State private var comment: String = ""
    @State private var errorText: String = ""
    @State private var showPersonPicker = false
    @State private var savedBanner = false
    @State private var savedCount = 0
    @FocusState private var amountFocused: Bool

    var accounts: [Account] {
        guard let bankId else { return [] }
        return appState.data.accounts.filter {
            $0.bankId == bankId && (!$0.isClosed || $0.id == accountId)
        }
    }
    var categories: [Category] {
        guard let opId else { return [] }
        return appState.data.categories.filter { $0.opId == opId }
    }
    var subcategories: [Subcategory] {
        guard let categoryId else { return [] }
        return appState.data.subcategories.filter { $0.catId == categoryId }
    }

    var isEditing: Bool {
        if case .edit = editState { return true }
        return false
    }
    var isDuplicating: Bool {
        if case .duplicate = editState { return true }
        return false
    }

    // Зависимые списки: при РУЧНОЙ смене банка сбрасывается счёт, при смене
    // операции — категория и подкатегория. Сброс сделан в самих привязках,
    // а не через .onChange, иначе при загрузке операции на редактирование
    // .onChange срабатывал позже и стирал только что подставленные значения.
    private var bankBinding: Binding<UUID?> {
        Binding(get: { bankId }, set: { newValue in
            if newValue != bankId { accountId = nil }
            bankId = newValue
        })
    }
    private var opBinding: Binding<UUID?> {
        Binding(get: { opId }, set: { newValue in
            if newValue != opId { categoryId = nil; subcategoryId = nil }
            opId = newValue
        })
    }
    /// Счёт задаёт валюту операции. Дальше её можно поменять значком у суммы.
    private var accountBinding: Binding<UUID?> {
        Binding(get: { accountId }, set: { newValue in
            accountId = newValue
            if let id = newValue, let acc = appState.data.accounts.first(where: { $0.id == id }) {
                currency = acc.effectiveCurrency
            }
        })
    }
    private var categoryBinding: Binding<UUID?> {
        Binding(get: { categoryId }, set: { newValue in
            if newValue != categoryId { subcategoryId = nil }
            categoryId = newValue
        })
    }

    var body: some View {
        ScrollViewReader { proxy in
            Form {
                if editState != nil {
                    Section {
                        HStack {
                            Label(isEditing ? "Редактирование" : "Копия операции",
                                  systemImage: isEditing ? "pencil" : "doc.on.doc")
                                .font(Theme.body)
                                .foregroundStyle(Color.accentColor)
                            Spacer()
                            Button("Отменить") { resetAll() }
                                .font(Theme.body)
                                .buttonStyle(.borderless)
                        }
                    }
                }

                // Сумма — главный элемент экрана
                Section {
                    VStack(spacing: Theme.gap) {
                        HStack(alignment: .firstTextBaseline, spacing: 6) {
                            Text(isNegative ? Money.minus : "+")
                                .font(Theme.display)
                                .foregroundStyle(isNegative ? Color.primary : Theme.income)
                            TextField("0", text: $amountText)
                                .keyboardType(.decimalPad)
                                .font(Theme.display)
                                .multilineTextAlignment(.leading)
                                .fixedSize()
                                .focused($amountFocused)
                                .accessibilityIdentifier("amountField")
                            currencyMenu
                        }
                        signPicker
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, Theme.gap)
                } footer: {
                    Text("Знак суммы выбираете вы сами — тип операции его не меняет. Нажмите на значок валюты, чтобы сменить её.")
                }
                .id(FormView.topAnchor)

                Section {
                    DateTimeRow(label: "Дата", symbol: "calendar", color: .red,
                                mode: .date, value: $date)
                    DateTimeRow(label: "Время", symbol: "clock", color: .indigo,
                                mode: .time, value: $time)
                }

                Section {
                    Picker(selection: bankBinding) {
                        Text("Не выбран").tag(UUID?.none)
                        ForEach(appState.data.banks) { b in
                            Text(b.name).tag(Optional(b.id))
                        }
                    } label: {
                        rowLabel("Банк", "building.columns.fill", .blue)
                    }
                    Picker(selection: accountBinding) {
                        Text(accounts.isEmpty && bankId != nil ? "Нет счетов" : "Не выбран").tag(UUID?.none)
                        ForEach(accounts) { a in
                            Text(a.name).tag(Optional(a.id))
                        }
                    } label: {
                        rowLabel("Счёт", "creditcard.fill", .teal)
                    }
                    .disabled(bankId == nil)
                }

                Section {
                    Picker(selection: opBinding) {
                        Text("Не выбрана").tag(UUID?.none)
                        ForEach(appState.data.optypes) { o in
                            Text(o.name).tag(Optional(o.id))
                        }
                    } label: {
                        rowLabel("Операция", "arrow.left.arrow.right", .orange)
                    }
                    Picker(selection: categoryBinding) {
                        Text(categories.isEmpty && opId != nil ? "Нет категорий" : "Не выбрана").tag(UUID?.none)
                        ForEach(categories) { c in
                            Text(c.name).tag(Optional(c.id))
                        }
                    } label: {
                        rowLabel("Категория", "square.grid.2x2.fill", .purple)
                    }
                    .disabled(opId == nil)
                    Picker(selection: $subcategoryId) {
                        Text(subcategories.isEmpty && categoryId != nil ? "Нет подкатегорий" : "Не выбрана").tag(UUID?.none)
                        ForEach(subcategories) { s in
                            Text(s.name).tag(Optional(s.id))
                        }
                    } label: {
                        rowLabel("Подкатегория", "square.grid.3x3.fill", .pink)
                    }
                    .disabled(categoryId == nil)
                }

                Section {
                    Button {
                        showPersonPicker = true
                    } label: {
                        HStack {
                            rowLabel("Лицо", "person.fill", .green)
                            Spacer()
                            Text(personName.isEmpty ? "Не выбрано" : personName)
                                .foregroundStyle(Color.secondary)
                            Image(systemName: "chevron.right")
                                .font(Theme.caption.weight(.semibold))
                                .foregroundStyle(.tertiary)
                        }
                    }
                    .tint(.primary)
                    .accessibilityIdentifier("personButton")

                    TextField("Комментарий", text: $comment, axis: .vertical)
                        .lineLimit(1...4)
                }

                if !errorText.isEmpty {
                    Section {
                        Label(errorText, systemImage: "exclamationmark.circle.fill")
                            .foregroundStyle(.red)
                            .font(Theme.caption)
                    }
                }
            }
            .navigationTitle(isEditing ? "Редактирование" : "Новая операция")
            .themedList()
            .scrollDismissesKeyboard(.interactively)
            .safeAreaInset(edge: .bottom) {
                Button { save(proxy) } label: {
                    Text(isEditing ? "Сохранить изменения" : (isDuplicating ? "Сохранить копию" : "Сохранить"))
                        .font(Theme.subtitle)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 6)
                }
                .buttonStyle(.borderedProminent)
                .buttonBorderShape(.capsule)
                .controlSize(.large)
                .padding(.horizontal, 20)
                .padding(.vertical, Theme.gap)
                .background(.bar)
                .accessibilityIdentifier("saveButton")
            }
            .toolbar {
                ToolbarItemGroup(placement: .keyboard) {
                    Button {
                        isNegative.toggle()
                    } label: {
                        Label(isNegative ? "Сделать плюсом" : "Сделать минусом",
                              systemImage: "plus.forwardslash.minus")
                    }
                    Spacer()
                    Button("Готово") { hideKeyboard() }
                }
            }
            .overlay(alignment: .top) {
                if savedBanner {
                    Label("Операция сохранена", systemImage: "checkmark.circle.fill")
                        .font(Theme.subtitle)
                        .padding(.horizontal, 20).padding(.vertical, Theme.gap)
                        .background(.regularMaterial, in: Capsule())
                        .shadow(color: .black.opacity(0.08), radius: 12, y: 4)
                        .foregroundStyle(.green)
                        .padding(.top, 8)
                        .transition(.move(edge: .top).combined(with: .opacity))
                }
            }
            .sensoryFeedback(.success, trigger: savedCount)
            .sheet(isPresented: $showPersonPicker) {
                PersonPickerView(selectedName: $personName)
                    .environmentObject(appState)
            }
            .onAppear { loadFromEditStateIfNeeded() }
            .onChange(of: editState) { _, _ in loadFromEditStateIfNeeded() }
        }
    }

    /// Якорь, к которому экран возвращается после сохранения
    static let topAnchor = "formTop"

    /// Выбор валюты прямо у суммы
    private var currencyMenu: some View {
        Menu {
            ForEach(Currency.allCases) { c in
                Button {
                    currency = c
                } label: {
                    if currency == c {
                        Label("\(c.title) · \(c.symbol)", systemImage: "checkmark")
                    } else {
                        Text("\(c.title) · \(c.symbol)")
                    }
                }
            }
        } label: {
            Text(currency.symbol)
                .font(Theme.display)
                .foregroundStyle(Color.accentColor)
        }
        .accessibilityIdentifier("currencyButton")
        .accessibilityLabel("Валюта: \(currency.title)")
    }

    /// Выбор знака суммы: на цифровой клавиатуре iPhone минуса нет,
    /// поэтому знак ставится отдельным переключателем.
    private var signPicker: some View {
        HStack(spacing: 0) {
            signButton(negative: false, title: "Плюс", symbol: "plus")
            signButton(negative: true, title: "Минус", symbol: "minus")
        }
        .padding(3)
        .background(Color(.tertiarySystemFill), in: Capsule())
        .frame(maxWidth: 260)
    }

    private func signButton(negative: Bool, title: String, symbol: String) -> some View {
        let active = isNegative == negative
        return Button {
            isNegative = negative
        } label: {
            Label(title, systemImage: symbol)
                .font(Theme.body.weight(active ? .semibold : .regular))
                .foregroundStyle(active ? Color.primary : Color.secondary)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 7)
                .background {
                    if active {
                        Capsule().fill(Color(.systemBackground))
                            .shadow(color: .black.opacity(0.10), radius: 3, y: 1)
                    }
                }
        }
        .buttonStyle(.plain)
        .accessibilityIdentifier(negative ? "signMinus" : "signPlus")
        .accessibilityAddTraits(active ? [.isSelected] : [])
    }

    private func rowLabel(_ title: String, _ symbol: String, _ color: Color) -> some View {
        IconRow(title: title, symbol: symbol, color: color)
    }

    private func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }

    func loadFromEditStateIfNeeded() {
        guard let editState else { return }
        let targetId: UUID
        switch editState {
        case .edit(let id): targetId = id
        case .duplicate(let id): targetId = id
        }
        guard let rec = appState.data.operations.first(where: { $0.id == targetId }) else { return }
        fillForm(from: rec)
    }

    func fillForm(from rec: OperationRecord) {
        date = DateFmt.day(from: rec.date)
        time = DateFmt.time(from: rec.time)
        // Прямое присваивание @State (минуя привязки) — зависимые поля не сбрасываются
        let bank = appState.data.banks.first(where: { $0.name == rec.bank })
        bankId = bank?.id
        accountId = appState.data.accounts.first(where: { $0.name == rec.account && $0.bankId == bank?.id })?.id
        let op = appState.data.optypes.first(where: { $0.name == rec.operation })
        opId = op?.id
        let cat = appState.data.categories.first(where: { $0.name == rec.category && $0.opId == op?.id })
        categoryId = cat?.id
        subcategoryId = appState.data.subcategories.first(where: { $0.name == rec.subcategory && $0.catId == cat?.id })?.id
        personName = rec.person
        amountText = Money.editString(rec.amount)
        isNegative = rec.amount < 0
        currency = rec.effectiveCurrency
        comment = rec.comment
        errorText = ""

        var lost: [String] = []
        if bankId == nil { lost.append("банк «\(rec.bank)»") }
        if accountId == nil { lost.append("счёт «\(rec.account)»") }
        if opId == nil { lost.append("операция «\(rec.operation)»") }
        if categoryId == nil { lost.append("категория «\(rec.category)»") }
        if !rec.subcategory.isEmpty && subcategoryId == nil { lost.append("подкатегория «\(rec.subcategory)»") }
        if !lost.isEmpty {
            errorText = "В справочниках больше нет: " + lost.joined(separator: ", ") + ". Выберите заново."
        }
    }

    func resetAll() {
        editState = nil
        date = nil; time = nil
        bankId = nil; accountId = nil
        opId = nil; categoryId = nil; subcategoryId = nil
        personName = ""; amountText = ""; comment = ""
        isNegative = false
        currency = .rub
        errorText = ""
    }

    func save(_ proxy: ScrollViewProxy? = nil) {
        errorText = ""
        var missing: [String] = []

        if date == nil { missing.append("Дата") }
        let bank = bankId.flatMap { id in appState.data.banks.first(where: { $0.id == id }) }
        if bank == nil { missing.append("Банк") }
        let account = accountId.flatMap { id in appState.data.accounts.first(where: { $0.id == id }) }
        if account == nil { missing.append("Счёт") }
        let op = opId.flatMap { id in appState.data.optypes.first(where: { $0.id == id }) }
        if op == nil { missing.append("Операция") }
        let category = categoryId.flatMap { id in appState.data.categories.first(where: { $0.id == id }) }
        if category == nil { missing.append("Категория") }
        let subcategory = subcategoryId.flatMap { id in appState.data.subcategories.first(where: { $0.id == id }) }

        // В поле вводится только модуль суммы, знак задаёт переключатель «плюс/минус»
        let magnitude = Money.parse(amountText).map { abs($0) }
        if magnitude == nil || magnitude! <= 0 { missing.append("Сумма") }
        let amount = magnitude.map { isNegative ? -$0 : $0 }

        guard missing.isEmpty, let date, let bank, let account, let op, let category, let amount else {
            errorText = "Заполните обязательные поля: " + missing.joined(separator: ", ")
            return
        }

        let dateStr = DateFmt.dayString(date)
        let timeStr = time.map { DateFmt.timeString($0) } ?? ""
        let trimmedComment = comment.trimmingCharacters(in: .whitespacesAndNewlines)

        func makeRecord(id: UUID = UUID(), createdAt: Double = Date().timeIntervalSince1970) -> OperationRecord {
            OperationRecord(id: id, date: dateStr, time: timeStr, bank: bank.name, account: account.name,
                            operation: op.name, category: category.name, subcategory: subcategory?.name ?? "",
                            person: personName, amount: amount, comment: trimmedComment,
                            createdAt: createdAt, currency: currency)
        }

        switch editState {
        case .edit(let id):
            if let idx = appState.data.operations.firstIndex(where: { $0.id == id }) {
                let createdAt = appState.data.operations[idx].createdAt
                appState.data.operations[idx] = makeRecord(id: id, createdAt: createdAt)
            }
            appState.persist()
            resetAll()
            onSaved()
        case .duplicate:
            appState.data.operations.append(makeRecord())
            appState.persist()
            resetAll()
            onSaved()
        case nil:
            appState.data.operations.append(makeRecord())
            appState.persist()
            // Для быстрого ввода серии операций оставляем дату, банк, счёт, операцию
            // и знак — очищаем только сумму, лицо и комментарий.
            amountText = ""; comment = ""; personName = ""
            // Клавиатура уходит, экран возвращается к сумме: следующую операцию
            // вводят с самого верха, а не с того места, где нажали «Сохранить».
            hideKeyboard()
            withAnimation { proxy?.scrollTo(FormView.topAnchor, anchor: .top) }
            showSavedBanner()
        }
    }

    private func showSavedBanner() {
        savedCount += 1
        withAnimation { savedBanner = true }
        Task {
            try? await Task.sleep(nanoseconds: 1_600_000_000)
            withAnimation { savedBanner = false }
        }
    }
}

/// Экран выбора лица. Лица разложены по категориям, но ПОИСК идёт только по
/// именам: набирая текст, человек ищет конкретное лицо, а не категорию, и
/// совпадение по названию категории выдавало бы лишнее.
struct PersonPickerView: View {
    @EnvironmentObject var appState: AppState
    @Binding var selectedName: String
    @Environment(\.dismiss) var dismiss
    @State private var query = ""

    var trimmedQuery: String { query.trimmingCharacters(in: .whitespacesAndNewlines) }

    /// Категория с подходящими лицами. Отдельная структура, а не кортеж:
    /// ключевые пути к элементам кортежа Swift не поддерживает, а ForEach их требует.
    struct PersonSection: Identifiable {
        let group: PersonGroup
        let people: [Person]
        var id: UUID { group.id }
    }

    /// Пустые категории при поиске не показываем.
    private var sections: [PersonSection] {
        appState.data.personGroups.compactMap { group in
            var people = appState.data.personsOrdered(in: group.id)
            if !trimmedQuery.isEmpty {
                people = people.filter { $0.name.localizedCaseInsensitiveContains(trimmedQuery) }
            }
            return people.isEmpty ? nil : PersonSection(group: group, people: people)
        }
    }

    private var nothingFound: Bool { sections.isEmpty }

    var exactMatchExists: Bool {
        appState.data.persons.contains {
            $0.name.compare(trimmedQuery, options: [.caseInsensitive, .diacriticInsensitive]) == .orderedSame
        }
    }

    /// Куда попадёт новое лицо, добавленное прямо из поиска
    private var defaultGroupId: UUID? { appState.data.personGroups.first?.id }

    var body: some View {
        NavigationStack {
            List {
                if !selectedName.isEmpty || (!trimmedQuery.isEmpty && !exactMatchExists) {
                    Section {
                        if !trimmedQuery.isEmpty && !exactMatchExists {
                            Button {
                                appState.data.persons.append(Person(name: trimmedQuery,
                                                                    groupId: defaultGroupId))
                                appState.persist()
                                selectedName = trimmedQuery
                                dismiss()
                            } label: {
                                Label("Добавить «\(trimmedQuery)» в справочник",
                                      systemImage: "person.badge.plus")
                                    .font(Theme.body)
                            }
                        }
                        if !selectedName.isEmpty {
                            Button("Очистить выбор", role: .destructive) {
                                selectedName = ""
                                dismiss()
                            }
                            .font(Theme.body)
                        }
                    }
                }

                ForEach(sections) { section in
                    Section(section.group.name) {
                        ForEach(section.people) { p in
                            Button {
                                selectedName = p.name
                                dismiss()
                            } label: {
                                HStack(spacing: Theme.gap) {
                                    if p.isPinned {
                                        Image(systemName: "pin.fill")
                                            .font(Theme.caption)
                                            .foregroundStyle(.orange)
                                            .accessibilityLabel("Закреплено")
                                    }
                                    Text(p.name).font(Theme.body).foregroundStyle(.primary)
                                    Spacer(minLength: Theme.gap)
                                    if p.name == selectedName {
                                        Image(systemName: "checkmark")
                                            .font(Theme.body.weight(.semibold))
                                            .foregroundStyle(Color.accentColor)
                                    }
                                }
                            }
                        }
                    }
                }

                if nothingFound {
                    Text(trimmedQuery.isEmpty
                         ? "Справочник лиц пуст. Начните вводить имя в поиске, чтобы добавить."
                         : "Лицо не найдено.")
                        .font(Theme.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .themedList()
            .searchable(text: $query, placement: .navigationBarDrawer(displayMode: .always),
                        prompt: "Поиск по имени")
            .navigationTitle("Выберите лицо")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Отмена") { dismiss() }.font(Theme.body)
                }
            }
        }
    }
}
