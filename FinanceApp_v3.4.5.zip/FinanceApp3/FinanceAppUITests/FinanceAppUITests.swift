import XCTest

// UI-тесты: запускают приложение в симуляторе iPhone в облаке, «нажимают»
// кнопки как человек и сохраняют скриншоты каждого экрана.

final class FinanceAppUITests: XCTestCase {

    private let password = "test1234"

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    @MainActor
    private func snap(_ app: XCUIApplication, _ name: String) {
        let a = XCTAttachment(screenshot: app.screenshot())
        a.name = name
        a.lifetime = .keepAlways
        add(a)
    }

    /// Создаёт пароль при первом запуске или входит, если пароль уже есть
    @MainActor
    private func unlock(_ app: XCUIApplication, screenshotPrefix: String? = nil) {
        let setup1 = app.secureTextFields["setupPassword1"]
        let login = app.secureTextFields["loginPassword"]
        let appeared = setup1.waitForExistence(timeout: 10) || login.waitForExistence(timeout: 2)
        XCTAssertTrue(appeared, "не появился экран пароля")

        if setup1.exists {
            if let p = screenshotPrefix { snap(app, "\(p)_Создание_пароля") }
            setup1.tap()
            setup1.typeText(password)
            let setup2 = app.secureTextFields["setupPassword2"]
            setup2.tap()
            setup2.typeText(password)
            app.buttons["setupSubmit"].tap()
        } else {
            if let p = screenshotPrefix { snap(app, "\(p)_Вход") }
            login.tap()
            login.typeText(password)
            app.buttons["loginSubmit"].tap()
        }
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 60), "не открылся главный экран")
    }

    /// Тест 0: пустая история — проверяем, что заглушка ровно по центру экрана
    @MainActor
    func test0_EmptyHistoryIsCentered() throws {
        let app = XCUIApplication()
        app.launch()
        unlock(app)

        tab(app, 1)
        let title = app.staticTexts["Операций пока нет"]
        XCTAssertTrue(title.waitForExistence(timeout: 10), "нет заглушки пустой истории")
        snap(app, "00_История_пустая")

        // Заглушка должна стоять по центру списка по горизонтали и вертикали
        let screen = app.windows.firstMatch.frame
        let box = title.frame
        let dx = abs(box.midX - screen.midX)
        XCTAssertLessThan(dx, 8, "заглушка не по центру по горизонтали")
        XCTAssertGreaterThan(box.midY, screen.height * 0.3, "заглушка прижата к верху экрана")
        XCTAssertLessThan(box.midY, screen.height * 0.7, "заглушка прижата к низу экрана")
    }

    /// Тест 1: проходит по всем вкладкам и делает скриншоты
    @MainActor
    func test1_AllScreensScreenshots() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-uiTestDemo"]
        app.launch()
        unlock(app, screenshotPrefix: "01")

        snap(app, "02_Форма")

        tab(app, 1)
        _ = app.staticTexts["15.09.2026"].waitForExistence(timeout: 5)
        snap(app, "03_История")

        tab(app, 2)
        sleep(1)
        snap(app, "04_Статистика")
        app.swipeUp()
        snap(app, "05_Статистика_ниже")

        tab(app, 3)
        sleep(1)
        snap(app, "06_Настройки")

        tab(app, 4)
        sleep(1)
        snap(app, "07_О_приложении")

        // Блокировка вручную и повторный вход
        app.buttons["Заблокировать сейчас"].tap()
        XCTAssertTrue(app.secureTextFields["loginPassword"].waitForExistence(timeout: 5), "не заблокировалось")
        snap(app, "08_Заблокировано")
        let login = app.secureTextFields["loginPassword"]
        login.tap()
        login.typeText("wrong-password")
        app.buttons["loginSubmit"].tap()
        XCTAssertTrue(app.staticTexts["Неверный пароль. Попробуйте снова."].waitForExistence(timeout: 30))
        snap(app, "09_Неверный_пароль")
        login.tap()
        login.typeText(password)
        app.buttons["loginSubmit"].tap()
        XCTAssertTrue(app.tabBars.firstMatch.waitForExistence(timeout: 60))
    }

    /// Тест 2: заполняет форму как пользователь и проверяет, что операция сохранилась
    @MainActor
    func test2_AddOperationThroughForm() throws {
        let app = XCUIApplication()
        app.launch()
        unlock(app)

        tab(app, 0)

        // Дата и время: теперь каждое открывает отдельное окно, которое нужно закрыть.
        // Дата и время в приложении всегда вводятся вручную, поля стартуют пустыми.
        pickDateTime(app, title: "Дата")
        pickDateTime(app, title: "Время")

        // Банк → Счёт (зависимый список)
        choose(app, picker: "Банк", option: "Тинькофф")
        choose(app, picker: "Счёт", option: "Основной")
        // Операция → Категория → Подкатегория
        choose(app, picker: "Операция", option: "Трата")
        choose(app, picker: "Категория", option: "Еда")
        choose(app, picker: "Подкатегория", option: "Продукты")

        // Лицо через поиск
        let personButton = app.buttons["personButton"]
        XCTAssertTrue(reveal(app, personButton), "нет кнопки выбора лица")
        personButton.tap()
        let search = app.searchFields.firstMatch
        XCTAssertTrue(search.waitForExistence(timeout: 5))
        search.tap()
        search.typeText("Petr")   // такого лица нет — проверим кнопку «Добавить в справочник»
        snap(app, "10_Поиск_лица")
        let add = app.buttons.matching(NSPredicate(format: "label BEGINSWITH 'Добавить'")).firstMatch
        XCTAssertTrue(add.waitForExistence(timeout: 5), "нет кнопки добавления лица")
        add.tap()
        XCTAssertTrue(app.buttons["personButton"].waitForExistence(timeout: 5), "окно выбора лица не закрылось")

        // Сумма со знаком: минус ставит сам пользователь, тип операции знак не меняет
        // Сумма — в самом верху формы, а мы успели прокрутить список вниз.
        // Проверять существование до прокрутки нельзя: строки за краем экрана
        // в iOS просто не созданы. Ищем сразу прокруткой.
        let amount = app.textFields["amountField"]
        XCTAssertTrue(reveal(app, amount), "нет поля суммы")
        amount.tap()
        amount.typeText("1500,50")
        let minusButton = app.buttons["signMinus"]
        XCTAssertTrue(reveal(app, minusButton), "нет переключателя знака")
        minusButton.tap()
        snap(app, "11_Форма_заполнена")

        let done = app.buttons["Готово"].firstMatch
        if done.exists && done.isHittable { done.tap() }
        let save = app.buttons["saveButton"]
        XCTAssertTrue(reveal(app, save), "нет кнопки сохранения")
        save.tap()

        XCTAssertTrue(app.descendants(matching: .any)
                        .matching(NSPredicate(format: "label CONTAINS 'Операция сохранена'"))
                        .firstMatch.waitForExistence(timeout: 5),
                      "не появилось подтверждение сохранения")
        snap(app, "12_Сохранено")

        tab(app, 1)
        let found = app.descendants(matching: .any).matching(NSPredicate(format: "label CONTAINS '500,50'")).firstMatch
        XCTAssertTrue(found.waitForExistence(timeout: 5), "новая операция не появилась в истории")
        // Введённый минус должен сохраниться как есть
        let negative = app.descendants(matching: .any)
            .matching(NSPredicate(format: "label CONTAINS %@", "\u{2212}1")).firstMatch
        XCTAssertTrue(negative.waitForExistence(timeout: 5), "минус не сохранился в сумме")
        snap(app, "13_История_с_новой_операцией")
    }

    /// Тест 3: экран операции, окно подтверждения удаления и настройка группы операции
    @MainActor
    func test3_DetailDeleteAlertAndOperationEditor() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-uiTestDemo"]
        app.launch()
        unlock(app)

        // Экран одной операции
        tab(app, 1)
        // По опознавательному знаку, а не «первая ячейка на экране»: заголовок
        // раздела с датой тоже считается ячейкой, и нажатие по нему ничего не даёт
        let firstRow = app.descendants(matching: .any)
            .matching(identifier: "historyRow").firstMatch
        XCTAssertTrue(firstRow.waitForExistence(timeout: 10), "нет строк в истории")
        XCTAssertTrue(reveal(app, firstRow), "строка истории не показалась на экране")
        firstRow.tap()

        let detailBar = app.navigationBars["Операция"]
        if !detailBar.waitForExistence(timeout: 5), firstRow.exists, firstRow.isHittable {
            // Первое касание после прокрутки список иногда забирает себе
            firstRow.tap()
        }
        XCTAssertTrue(detailBar.waitForExistence(timeout: 10),
                      "не открылся экран операции")
        snap(app, "14_Экран_операции")

        // Кнопка удаления — в самом низу длинного экрана, её нужно доскроллить
        let deleteButton = app.buttons["Удалить операцию"]
        XCTAssertTrue(reveal(app, deleteButton), "нет кнопки удаления операции")

        // Окно подтверждения должно быть системным алертом по центру
        deleteButton.tap()
        let alert = app.alerts.firstMatch
        XCTAssertTrue(alert.waitForExistence(timeout: 5), "нет окна подтверждения удаления")
        snap(app, "15_Подтверждение_удаления")
        let screen = app.windows.firstMatch.frame
        XCTAssertLessThan(abs(alert.frame.midX - screen.midX), 8, "окно не по центру по горизонтали")
        XCTAssertLessThan(abs(alert.frame.midY - screen.midY), screen.height * 0.2, "окно не по центру по вертикали")
        alert.buttons["Отмена"].tap()

        // Справочники: с корневого экрана проваливаемся в операцию, оттуда в категорию
        tab(app, 3)
        snap(app, "16_Настройки_первый_уровень")
        // Строка справочника подписана «Трата, Расход, 3 категории» — ищем по
        // отдельному опознавательному знаку, а не по видимому тексту
        let opRow = app.buttons["dir_Трата"].firstMatch
        XCTAssertTrue(opRow.waitForExistence(timeout: 10), "нет строки операции в настройках")
        XCTAssertTrue(reveal(app, opRow), "строка операции не показалась на экране")
        opRow.tap()
        XCTAssertTrue(app.staticTexts["Группа в статистике"].waitForExistence(timeout: 5),
                      "не открылся экран операции")
        snap(app, "17_Экран_операции")

        let catRow = app.buttons["dir_Еда"].firstMatch
        XCTAssertTrue(catRow.waitForExistence(timeout: 5), "нет категории внутри операции")
        XCTAssertTrue(reveal(app, catRow), "категория не показалась на экране")
        catRow.tap()
        XCTAssertTrue(app.staticTexts["Подкатегории"].waitForExistence(timeout: 5),
                      "не открылся экран категории")
        snap(app, "18_Экран_категории")
    }

    /// Тест 4: банк со счетами, валюта счёта и таблица остатков в статистике
    @MainActor
    func test4_AccountsCurrencyAndBalances() throws {
        let app = XCUIApplication()
        app.launchArguments = ["-uiTestDemo"]
        app.launch()
        unlock(app)

        tab(app, 3)
        let bankRow = app.buttons["dir_Тинькофф"].firstMatch
        XCTAssertTrue(bankRow.waitForExistence(timeout: 10), "нет банка в настройках")
        XCTAssertTrue(reveal(app, bankRow), "строка банка не показалась на экране")
        bankRow.tap()
        XCTAssertTrue(app.staticTexts["Счета"].waitForExistence(timeout: 5), "не открылся экран банка")
        snap(app, "19_Экран_банка")

        let accRow = app.buttons["dir_Валютный"].firstMatch
        XCTAssertTrue(accRow.waitForExistence(timeout: 5), "нет счёта внутри банка")
        XCTAssertTrue(reveal(app, accRow), "строка счёта не показалась на экране")
        accRow.tap()
        XCTAssertTrue(app.staticTexts["Валюта счёта"].waitForExistence(timeout: 5),
                      "не открылся экран счёта")
        snap(app, "20_Экран_счёта")

        tab(app, 2)
        let balances = app.staticTexts["Остатки по счетам"]
        XCTAssertTrue(reveal(app, balances), "нет таблицы остатков в статистике")
        snap(app, "21_Остатки_по_счетам")
    }

    /// Прокручивает экран, пока элемент не окажется видимым и нажимаемым.
    ///
    /// SwiftUI-список создаёт только видимые строки: то, что ушло за нижний край,
    /// в дереве доступности просто отсутствует, и `waitForExistence` ждёт его зря.
    /// Поэтому листаем сами — сначала вниз, потом, если не нашли, вверх.
    @MainActor
    @discardableResult
    private func reveal(_ app: XCUIApplication, _ element: XCUIElement, swipes: Int = 6) -> Bool {
        if hittable(element, within: 2) { return true }
        for _ in 0..<swipes {
            app.swipeUp()
            if hittable(element, within: 1) { return true }
        }
        for _ in 0..<(swipes * 2) {
            app.swipeDown()
            if hittable(element, within: 1) { return true }
        }
        return hittable(element, within: 1)
    }

    /// `isHittable` на долю секунды бывает ложным, пока список доезжает после
    /// прокрутки. Даём ему это время, иначе пролистнём мимо нужной строки.
    @MainActor
    private func hittable(_ element: XCUIElement, within seconds: TimeInterval) -> Bool {
        let deadline = Date().addingTimeInterval(seconds)
        while Date() < deadline {
            if element.exists && element.isHittable { return true }
            usleep(150_000)
        }
        return element.exists && element.isHittable
    }

    /// Вкладки теперь без подписей — нажимаем по порядку: 0 Форма, 1 История, 2 Статистика, 3 Настройки, 4 О приложении
    @MainActor
    private func tab(_ app: XCUIApplication, _ index: Int) {
        let button = app.tabBars.buttons.element(boundBy: index)
        XCTAssertTrue(button.waitForExistence(timeout: 10), "нет вкладки \(index)")
        button.tap()
    }

    /// Открывает окно даты или времени и закрывает его кнопкой «Готово».
    /// Оба поля стартуют пустыми, поэтому строка подписана «Выбрать».
    @MainActor
    private func pickDateTime(_ app: XCUIApplication, title: String) {
        let row = app.buttons.matching(NSPredicate(format: "label == 'Выбрать'")).firstMatch
        XCTAssertTrue(reveal(app, row), "нет строки «\(title)»")
        row.tap()

        let sheet = app.navigationBars[title]
        XCTAssertTrue(sheet.waitForExistence(timeout: 5), "не открылось окно «\(title)»")
        let done = sheet.buttons["Готово"]
        XCTAssertTrue(done.waitForExistence(timeout: 5), "в окне «\(title)» нет кнопки «Готово»")
        done.tap()
        XCTAssertFalse(sheet.waitForExistence(timeout: 3), "окно «\(title)» не закрылось")
    }

    /// Выбор значения в выпадающем списке формы
    @MainActor
    private func choose(_ app: XCUIApplication, picker: String, option: String) {
        let row = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", picker)).firstMatch
        XCTAssertTrue(reveal(app, row), "нет списка \(picker)")
        row.tap()
        // Ищем по началу строки: счета теперь подписаны с валютой — «Основной · ₽»
        let item = app.buttons.matching(NSPredicate(format: "label BEGINSWITH %@", option)).firstMatch
        XCTAssertTrue(item.waitForExistence(timeout: 5), "в списке \(picker) нет «\(option)»")
        item.tap()
    }
}
