import Foundation

// MARK: - Период

/// Быстрые варианты периода. «Произвольный» задаётся двумя датами вручную.
nonisolated enum PeriodPreset: String, CaseIterable, Identifiable {
    case week, month, year, all, custom

    var id: String { rawValue }

    var title: String {
        switch self {
        case .week:   return "Неделя"
        case .month:  return "Месяц"
        case .year:   return "Год"
        case .all:    return "Все"
        case .custom: return "Период"
        }
    }

    /// В переключателе показываем только быстрые варианты: произвольный
    /// период выбирается отдельной строкой с двумя датами.
    static var quick: [PeriodPreset] { [.week, .month, .year, .all] }
}

/// Отрезок времени, по которому считается отчёт.
///
/// Даты в записях хранятся строками «ГГГГ-ММ-ДД», поэтому сравнение идёт
/// по строкам: они упорядочены так же, как сами даты, и не зависят от
/// часового пояса.
nonisolated struct DateSpan: Equatable {
    var preset: PeriodPreset = .month
    var from: Date = Date()
    var to: Date = Date()

    static func calendar() -> Calendar {
        var cal = Calendar(identifier: .gregorian)
        cal.firstWeekday = 2   // неделя начинается с понедельника
        return cal
    }

    /// Границы быстрого варианта: начало текущей недели, месяца или года.
    static func make(_ preset: PeriodPreset, today: Date = Date()) -> DateSpan {
        let cal = calendar()
        var span = DateSpan(preset: preset, from: today, to: today)
        switch preset {
        case .week:
            let comps = cal.dateComponents([.yearForWeekOfYear, .weekOfYear], from: today)
            let start = cal.date(from: comps) ?? today
            span.from = start
            span.to = cal.date(byAdding: .day, value: 6, to: start) ?? today
        case .month:
            let comps = cal.dateComponents([.year, .month], from: today)
            let start = cal.date(from: comps) ?? today
            span.from = start
            span.to = DateSpan.lastDay(of: start, unit: .month, cal: cal)
        case .year:
            let comps = cal.dateComponents([.year], from: today)
            let start = cal.date(from: comps) ?? today
            span.from = start
            span.to = DateSpan.lastDay(of: start, unit: .year, cal: cal)
        case .all:
            span.from = cal.date(byAdding: .year, value: -50, to: today) ?? today
        case .custom:
            span.from = cal.date(byAdding: .month, value: -1, to: today) ?? today
        }
        return span
    }

    /// Последний день месяца или года. Подпись обещает «Сентябрь 2026» —
    /// значит и считать надо весь сентябрь, а не до сегодняшнего числа.
    private static func lastDay(of start: Date, unit: Calendar.Component, cal: Calendar) -> Date {
        guard let next = cal.date(byAdding: unit, value: 1, to: start),
              let last = cal.date(byAdding: .day, value: -1, to: next) else { return start }
        return last
    }

    var fromKey: String { DateFmt.dayString(from) }
    var toKey: String { DateFmt.dayString(to) }

    func contains(_ day: String) -> Bool {
        guard !day.isEmpty else { return false }
        if preset == .all { return true }
        return day >= fromKey && day <= toKey
    }

    var title: String {
        switch preset {
        case .all:   return "За всё время"
        case .month: return DateFmt.monthTitle(String(fromKey.prefix(7)))
        case .year:  return String(fromKey.prefix(4)) + " год"
        case .week, .custom:
            return DateFmt.display(fromKey) + " — " + DateFmt.display(toKey)
        }
    }
}

// MARK: - Шаг отчёта

/// Как часто снимаются данные в отчёте о динамике.
nonisolated enum Granularity: String, CaseIterable, Identifiable {
    case day, week, month, year

    var id: String { rawValue }

    var title: String {
        switch self {
        case .day:   return "Дни"
        case .week:  return "Недели"
        case .month: return "Месяцы"
        case .year:  return "Годы"
        }
    }
}

/// Одна точка отчёта о динамике: сколько пришло, сколько ушло и сколько
/// календарных дней в неё попало — по дням считается планка плана.
nonisolated struct Bucket: Identifiable, Equatable {
    var key: String
    var label: String
    var income: Double = 0
    var expense: Double = 0
    var days: Int = 0

    var id: String { key }

    /// Ключ и подпись корзины, в которую попадает день.
    ///
    /// `withYear` нужен, когда отрезок пересекает границу года: без года
    /// «21.09» двух разных лет слились бы в один столбец — ось группирует
    /// точки именно по подписи.
    static func stamp(for date: Date, step: Granularity, cal: Calendar,
                      withYear: Bool = false) -> (key: String, label: String) {
        switch step {
        case .day:
            let key = DateFmt.dayString(date)
            return (key, DateFmt.compact(key, withYear: withYear))
        case .week:
            let comps = cal.dateComponents([.yearForWeekOfYear, .weekOfYear], from: date)
            let start = cal.date(from: comps) ?? date
            let key = DateFmt.dayString(start)
            return (key, DateFmt.compact(key, withYear: withYear))
        case .month:
            let key = String(DateFmt.dayString(date).prefix(7))
            return (key, DateFmt.monthShort(key))
        case .year:
            let key = String(DateFmt.dayString(date).prefix(4))
            return (key, key)
        }
    }
}

/// Строка отчёта об оборотах: банк, счёт и сумма за период.
nonisolated struct AccountTurnover: Identifiable, Equatable {
    var bank: String
    var account: String
    var currency: Currency
    var total: Double
    var count: Int

    var id: String { bank + "|" + account + "|" + currency.rawValue }
}

/// Строка сводного отчёта: название и величина.
nonisolated struct ShareRow: Identifiable, Equatable {
    var name: String
    var value: Double
    var id: String { name }
}

// MARK: - Расчёты

extension AppData {

    /// Операции периода в одной валюте. Всё остальное считается уже от них.
    /// Имя не `operations`, чтобы не спорить с одноимённым хранимым полем.
    func records(in span: DateSpan, currency: Currency) -> [OperationRecord] {
        var result: [OperationRecord] = []
        for op in operations {
            guard op.effectiveCurrency == currency else { continue }
            guard span.contains(op.date) else { continue }
            result.append(op)
        }
        return result
    }

    /// Самая ранняя и самая поздняя даты в истории — границы «Всего времени».
    /// Записи с датой в будущем приложение разрешает, поэтому конец тоже
    /// считается по данным, а не по сегодняшнему дню.
    func dataBounds() -> (first: String, last: String)? {
        var first: String? = nil
        var last: String? = nil
        for op in operations where !op.date.isEmpty {
            if let f = first { if op.date < f { first = op.date } } else { first = op.date }
            if let l = last { if op.date > l { last = op.date } } else { last = op.date }
        }
        guard let f = first, let l = last else { return nil }
        return (f, l)
    }

    /// Отрезок, ограниченный реальными данными: «Всё время» без этого
    /// растянулось бы на пятьдесят лет пустых корзин.
    /// Самый длинный отрезок, который имеет смысл разбивать по дням.
    /// Дальше корзины обрезаются, и обрезается НАЧАЛО: свежие данные важнее.
    static let maxDays: Int = 4000

    func clamped(_ span: DateSpan) -> DateSpan {
        var result = span
        if span.preset == .all {
            guard let bounds = dataBounds(),
                  let from = DateFmt.day(from: bounds.first),
                  let to = DateFmt.day(from: bounds.last) else {
                // истории нет — берём один сегодняшний день, иначе получим
                // полвека пустых корзин и намертво повешенный график
                result.from = result.to
                return result
            }
            result.from = from
            result.to = to
            // Дальше отрезок должен работать как обычный: у «Всего времени»
            // проверка `contains` пропускает любой день, и обрезка начала
            // не действовала бы — операции до границы падали бы в первую корзину.
            result.preset = .custom
        }

        let cal = DateSpan.calendar()
        let days = cal.dateComponents([.day], from: cal.startOfDay(for: result.from),
                                      to: cal.startOfDay(for: result.to)).day ?? 0
        if days >= AppData.maxDays,
           let shifted = cal.date(byAdding: .day, value: -(AppData.maxDays - 1), to: result.to) {
            result.from = shifted
            result.preset = .custom
        }
        return result
    }

    /// Корзины отчёта о динамике. Пустые дни тоже попадают в ответ —
    /// иначе на графике пропадали бы провалы, а планка плана считалась
    /// бы не по всем дням.
    func buckets(span: DateSpan, step: Granularity, currency: Currency) -> [Bucket] {
        let cal = DateSpan.calendar()
        let real = clamped(span)
        let toKey = real.toKey

        var result: [Bucket] = []
        var index: [String: Int] = [:]

        let withYear: Bool = String(real.fromKey.prefix(4)) != String(toKey.prefix(4))
        var cursor: Date = cal.startOfDay(for: real.from)
        var guardCount: Int = 0
        while guardCount <= AppData.maxDays {
            let dayKey = DateFmt.dayString(cursor)
            if dayKey > toKey { break }
            guardCount += 1
            let stamp = Bucket.stamp(for: cursor, step: step, cal: cal, withYear: withYear)
            if let i = index[stamp.key] {
                result[i].days += 1
            } else {
                index[stamp.key] = result.count
                result.append(Bucket(key: stamp.key, label: stamp.label, days: 1))
            }
            guard let next = cal.date(byAdding: .day, value: 1, to: cursor) else { break }
            cursor = next
        }

        for op in records(in: real, currency: currency) {
            guard let date = DateFmt.day(from: op.date) else { continue }
            let stamp = Bucket.stamp(for: date, step: step, cal: cal, withYear: withYear)
            guard let i = index[stamp.key] else { continue }
            let kind = self.kind(of: op)
            if kind == .income {
                result[i].income += op.amount
            } else if kind == .expense {
                result[i].expense += op.amount
            }
        }
        return result
    }

    /// Обороты по счетам за период: сумма всех операций счёта, включая
    /// переводы, — они меняют остаток конкретного счёта.
    func accountTurnovers(span: DateSpan, currency: Currency) -> [AccountTurnover] {
        var sums: [String: Double] = [:]
        var counts: [String: Int] = [:]
        var names: [String: (bank: String, account: String)] = [:]

        for op in records(in: span, currency: currency) {
            let key = op.bank + "|" + op.account
            sums[key, default: 0] += op.amount
            counts[key, default: 0] += 1
            names[key] = (op.bank, op.account)
        }

        var result: [AccountTurnover] = []
        result.reserveCapacity(sums.count)
        for (key, total) in sums {
            let name = names[key] ?? (bank: "", account: "")
            result.append(AccountTurnover(bank: name.bank,
                                          account: name.account,
                                          currency: currency,
                                          total: total,
                                          count: counts[key] ?? 0))
        }
        result.sort(by: AppData.byTurnover)
        return result
    }

    private static func byTurnover(_ a: AccountTurnover, _ b: AccountTurnover) -> Bool {
        let ma: Double = abs(a.total)
        let mb: Double = abs(b.total)
        if ma != mb { return ma > mb }
        if a.bank != b.bank { return a.bank.localizedStandardCompare(b.bank) == .orderedAscending }
        return a.account.localizedStandardCompare(b.account) == .orderedAscending
    }

    /// Доли по произвольному признаку: категория, лицо, счёт.
    /// Мелочь сворачивается в «Остальное», чтобы круг оставался читаемым.
    func shares(_ ops: [OperationRecord], by key: (OperationRecord) -> String, limit: Int) -> [ShareRow] {
        var dict: [String: Double] = [:]
        for op in ops { dict[key(op), default: 0] += op.amount }

        var list: [ShareRow] = []
        list.reserveCapacity(dict.count)
        for (rawName, value) in dict {
            let name: String = rawName.isEmpty ? "Без названия" : rawName
            list.append(ShareRow(name: name, value: value))
        }
        list.sort(by: AppData.byShare)

        guard list.count > limit else { return list }
        var rest: Double = 0
        for item in list[limit...] { rest += item.value }
        var top: [ShareRow] = Array(list.prefix(limit))
        top.append(ShareRow(name: "Остальное", value: rest))
        return top
    }

    /// Сумма модулей: именно от неё считаются доли на круге. Знак суммы
    /// задаёт пользователь, поэтому в одной группе могут встретиться и
    /// платёж, и возврат — тогда сумма со знаками для долей не годится.
    static func absSum(_ rows: [ShareRow]) -> Double {
        var total: Double = 0
        for r in rows { total += abs(r.value) }
        return total
    }

    private static func byShare(_ a: ShareRow, _ b: ShareRow) -> Bool {
        let ma: Double = abs(a.value)
        let mb: Double = abs(b.value)
        if ma != mb { return ma > mb }
        return a.name.localizedStandardCompare(b.name) == .orderedAscending
    }

    /// Валюты, встречающиеся в истории, по убыванию частоты.
    func currenciesUsed() -> [Currency] {
        var count: [Currency: Int] = [:]
        for op in operations { count[op.effectiveCurrency, default: 0] += 1 }
        var list: [Currency] = Array(count.keys)
        list.sort { a, b in
            let ca: Int = count[a] ?? 0
            let cb: Int = count[b] ?? 0
            if ca != cb { return ca > cb }
            return a.rawValue < b.rawValue
        }
        return list
    }

    /// Границы быстрого варианта с оглядкой на данные: у «Всех» это
    /// первая и последняя записи, иначе в полях дат стояло бы «минус
    /// пятьдесят лет». Признак периода при этом сохраняется.
    func span(for preset: PeriodPreset) -> DateSpan {
        var result = DateSpan.make(preset)
        guard preset == .all else { return result }
        guard let bounds = dataBounds(),
              let from = DateFmt.day(from: bounds.first),
              let to = DateFmt.day(from: bounds.last) else { return result }
        result.from = from
        result.to = to
        return result
    }

    /// Доходы и расходы периода одной валюты. Знак берётся из записи:
    /// тип операции только распределяет по группам.
    func sums(in span: DateSpan, currency: Currency) -> (income: Double, expense: Double) {
        var income: Double = 0
        var expense: Double = 0
        for op in records(in: span, currency: currency) {
            let kind = self.kind(of: op)
            if kind == .income { income += op.amount }
            else if kind == .expense { expense += op.amount }
        }
        return (income, expense)
    }
}
