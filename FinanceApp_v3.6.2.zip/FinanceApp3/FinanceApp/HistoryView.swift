import SwiftUI

struct HistoryView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var goToForm: () -> Void

    @State private var filterBankId: UUID? = nil
    @State private var filterCategoryName: String = ""
    @State private var filterFrom: Date? = nil
    @State private var filterTo: Date? = nil
    @State private var searchText: String = ""
    @State private var showFilters = false
    @State private var showClearConfirm = false
    @State private var exportFile: ExportFile? = nil
    @State private var deleteTarget: OperationRecord? = nil

    var hasActiveFilters: Bool {
        filterBankId != nil || !filterCategoryName.isEmpty || filterFrom != nil || filterTo != nil
    }

    var filteredSorted: [OperationRecord] {
        var items = appState.data.operations

        if let filterBankId, let bank = appState.data.banks.first(where: { $0.id == filterBankId }) {
            items = items.filter { $0.bank == bank.name }
        }
        if !filterCategoryName.isEmpty {
            items = items.filter { $0.category == filterCategoryName }
        }
        if let from = filterFrom {
            let s = DateFmt.dayString(from)
            items = items.filter { $0.date >= s }
        }
        if let to = filterTo {
            let s = DateFmt.dayString(to)
            items = items.filter { $0.date <= s }
        }
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            items = items.filter { r in
                let fields = [r.person, r.comment, r.category, r.subcategory, r.bank, r.account, r.operation]
                return fields.contains { $0.localizedCaseInsensitiveContains(q) } || Money.format(r.amount).contains(q)
                    || r.effectiveCurrency.code.localizedCaseInsensitiveContains(q)
            }
        }

        return items.sorted { a, b in
            if a.date != b.date { return a.date > b.date }
            if a.time != b.time { return a.time > b.time }
            return a.createdAt > b.createdAt
        }
    }

    struct DayGroup: Identifiable {
        let day: String
        var items: [OperationRecord]
        var id: String { day }
    }

    func groupByDay(_ sorted: [OperationRecord]) -> [DayGroup] {
        var result: [DayGroup] = []
        for rec in sorted {
            if let last = result.last, last.day == rec.date {
                result[result.count - 1].items.append(rec)
            } else {
                result.append(DayGroup(day: rec.date, items: [rec]))
            }
        }
        return result
    }

    var body: some View {
        let items = filteredSorted
        let groups = groupByDay(items)
        List {
            Section {
                VStack(alignment: .leading, spacing: Theme.step) {
                    ScreenHeader(title: "История") {
                        HeaderButton(symbol: hasActiveFilters
                                     ? "line.3.horizontal.decrease.circle.fill"
                                     : "line.3.horizontal.decrease.circle",
                                     label: "Фильтры",
                                     filled: hasActiveFilters) { showFilters = true }
                        actionsMenu(items)
                    }
                    SearchField(text: $searchText)
                }
            }
            .plainRow()

            if items.isEmpty {
                // Пустое состояние — строкой списка, а не плашкой поверх него:
                // поверх оно закрывало бы собственную шапку с поиском.
                Section { emptyState }.plainRow()
            } else {
                ForEach(groups) { group in
                    Section {
                        ForEach(group.items) { rec in
                            NavigationLink(value: rec.id) {
                                RecordRow(rec: rec, kind: appState.data.kind(of: rec))
                            }
                            .accessibilityIdentifier("historyRow")
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) { deleteTarget = rec } label: {
                                    Label("Удалить", systemImage: "trash")
                                }
                            }
                            .swipeActions(edge: .leading) {
                                Button { duplicate(rec) } label: { Label("Копия", systemImage: "plus.square.on.square") }
                                    .tint(.indigo)
                            }
                            .contextMenu {
                                Button { edit(rec) } label: { Label("Изменить", systemImage: "pencil") }
                                Button { duplicate(rec) } label: { Label("Сделать копию", systemImage: "plus.square.on.square") }
                                Divider()
                                Button(role: .destructive) { deleteTarget = rec } label: { Label("Удалить", systemImage: "trash") }
                            }
                        }
                    } header: {
                        SectionTitle(DateFmt.humanDay(group.day))
                    }
                }
            }
        }
        .themedScreen()
        .navigationDestination(for: UUID.self) { id in
            OperationDetailView(recordID: id,
                                onEdit: { rec in edit(rec) },
                                onDuplicate: { rec in duplicate(rec) })
        }
        .sheet(isPresented: $showFilters) {
            filtersSheet
        }
        .alert("Удалить запись?", isPresented: Binding(
            get: { deleteTarget != nil },
            set: { if !$0 { deleteTarget = nil } }
        )) {
            Button("Отмена", role: .cancel) { deleteTarget = nil }
            Button("Удалить", role: .destructive) {
                if let t = deleteTarget {
                    appState.data.operations.removeAll { $0.id == t.id }
                    if editState == .edit(t.id) || editState == .duplicate(t.id) { editState = nil }
                    appState.persist()
                }
                deleteTarget = nil
            }
        } message: {
            Text("Операция будет удалена без возможности восстановления.")
        }
        .alert("Очистить базу?", isPresented: $showClearConfirm) {
            Button("Отмена", role: .cancel) {}
            Button("Очистить", role: .destructive) {
                appState.data.operations.removeAll()
                editState = nil
                appState.persist()
            }
        } message: {
            Text("Все операции (\(appState.data.operations.count)) будут удалены безвозвратно. Справочники останутся. Если данные нужны, сначала сделайте экспорт в Excel.")
        }
        .sheet(item: $exportFile) { file in
            ShareSheet(fileURL: file.url) { exportFile = nil }
                .presentationDetents([.medium, .large])
        }
    }

    /// Экспорт и очистка — рядом с фильтрами на линии заголовка
    private func actionsMenu(_ items: [OperationRecord]) -> some View {
        Menu {
            Button {
                export(appState.data.operations)
            } label: {
                Label("Экспорт всех в Excel", systemImage: "square.and.arrow.up")
            }
            .disabled(appState.data.operations.isEmpty)

            if hasActiveFilters || !searchText.isEmpty {
                Button {
                    export(items)
                } label: {
                    Label("Экспорт найденных (\(items.count))", systemImage: "square.and.arrow.up.on.square")
                }
                .disabled(items.isEmpty)
            }
            Divider()
            Button(role: .destructive) { showClearConfirm = true } label: {
                Label("Очистить базу", systemImage: "trash")
            }
            .disabled(appState.data.operations.isEmpty)
        } label: {
            Image(systemName: "ellipsis")
                .font(.system(size: 16, weight: .semibold))
                .frame(width: 36, height: 36)
                .background(Color(.secondarySystemGroupedBackground), in: Circle())
                .foregroundStyle(Color.primary)
        }
        .accessibilityLabel("Действия")
    }

    /// Пустой экран — ровно по центру страницы, один шрифт, аккуратный текст
    private var emptyState: some View {
        let nothingSaved = appState.data.operations.isEmpty
        return VStack(spacing: Theme.gap) {
            Image(systemName: nothingSaved ? "tray" : "magnifyingglass")
                .font(.system(size: 48, weight: .regular))
                .foregroundStyle(.tertiary)
                .padding(.bottom, 4)
            Text(nothingSaved ? "Операций пока нет" : "Ничего не найдено")
                .font(Theme.subtitle)
            Text(nothingSaved
                 ? "Добавьте первую операцию во вкладке «Форма»."
                 : "Измените запрос или сбросьте фильтры.")
                .font(Theme.caption)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: 260)
        .padding(.horizontal, Theme.sectionSpacing)
        .frame(maxWidth: .infinity, minHeight: 420, alignment: .center)
        .accessibilityElement(children: .combine)
    }

    private var filtersSheet: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Банк", selection: $filterBankId) {
                        Text("Все").tag(UUID?.none)
                        ForEach(appState.data.banks) { b in Text(b.name).tag(Optional(b.id)) }
                    }
                    Picker("Категория", selection: $filterCategoryName) {
                        Text("Все").tag("")
                        ForEach(categoryNames, id: \.self) { c in Text(c).tag(c) }
                    }
                }
                Section(header: SectionTitle("Период")) {
                    OptionalPickerField(label: "С", value: $filterFrom, placeholder: "Не выбрано") { b in
                        DatePicker("", selection: b, displayedComponents: .date).labelsHidden()
                    }
                    OptionalPickerField(label: "По", value: $filterTo, placeholder: "Не выбрано") { b in
                        DatePicker("", selection: b, displayedComponents: .date).labelsHidden()
                    }
                }
                if hasActiveFilters {
                    Section {
                        Button("Сбросить фильтры", role: .destructive) {
                            filterBankId = nil; filterCategoryName = ""; filterFrom = nil; filterTo = nil
                        }
                    }
                }
            }
            .navigationTitle("Фильтры")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { showFilters = false }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    var categoryNames: [String] {
        var unique: Set<String> = []
        for c in appState.data.categories { unique.insert(c.name) }
        var names: [String] = Array(unique)
        names.sort { $0.localizedStandardCompare($1) == .orderedAscending }
        return names
    }

    func edit(_ rec: OperationRecord) {
        editState = .edit(rec.id)
        goToForm()
    }

    func duplicate(_ rec: OperationRecord) {
        editState = .duplicate(rec.id)
        goToForm()
    }

    func export(_ operations: [OperationRecord]) {
        guard !operations.isEmpty else { return }
        let sorted = operations.sorted { a, b in
            if a.date != b.date { return a.date < b.date }
            if a.time != b.time { return a.time < b.time }
            return a.createdAt < b.createdAt
        }
        let xlsxData = XLSXExporter.buildXLSX(operations: sorted)
        let filename = "operations_\(DateFmt.fileStamp(Date())).xlsx"
        let tmpURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
        do {
            try xlsxData.write(to: tmpURL, options: [.atomic, .completeFileProtection])
            exportFile = ExportFile(url: tmpURL)
        } catch {
            appState.saveError = "Не удалось подготовить файл Excel: \(error.localizedDescription)"
        }
    }
}

/// Строка операции — всегда две строки одинаковой высоты:
/// крупно лицо (или категория, если лица нет), ниже серым — категория и подкатегория.
/// Все подробности — на экране операции по нажатию.
struct RecordRow: View {
    let rec: OperationRecord
    let kind: OpKind

    var body: some View {
        HStack(spacing: Theme.gap) {
            OperationIcon(kind: kind, amount: rec.amount, size: 40)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(Theme.subtitle)
                    .lineLimit(1)
                Text(subtitle)
                    .font(Theme.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: Theme.gap)
            AmountText(amount: rec.amount, currency: rec.effectiveCurrency)
        }
        .padding(.vertical, 2)
    }

    private var title: String {
        rec.person.isEmpty ? rec.category : rec.person
    }

    private var subtitle: String {
        if rec.person.isEmpty {
            return rec.subcategory.isEmpty ? rec.operation : rec.subcategory
        }
        return rec.subcategory.isEmpty ? rec.category : "\(rec.category) · \(rec.subcategory)"
    }
}

/// Круглая иконка операции. Направление берётся из знака самой суммы:
/// плюс — зелёная стрелка вниз, минус — оранжевая вверх.
/// «Не учитывать» всегда показывается серыми стрелками.
struct OperationIcon: View {
    let kind: OpKind
    var amount: Double = 0
    var size: CGFloat = 40

    private var color: Color {
        if kind == .neutral { return .gray }
        return amount < 0 ? Theme.expense : Theme.income
    }

    private var symbol: String {
        if kind == .neutral { return "arrow.left.arrow.right" }
        return amount < 0 ? "arrow.up" : "arrow.down"
    }

    var body: some View {
        Image(systemName: symbol)
            .font(.system(size: size * 0.4, weight: .semibold))
            .foregroundStyle(color)
            .frame(width: size, height: size)
            .background(color.opacity(0.15), in: Circle())
            .accessibilityHidden(true)
    }
}

/// Экран одной операции — как карточка транзакции в Apple Wallet
struct OperationDetailView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let recordID: UUID
    var onEdit: (OperationRecord) -> Void
    var onDuplicate: (OperationRecord) -> Void
    @State private var confirmDelete = false

    var body: some View {
        if let rec = appState.data.operations.first(where: { $0.id == recordID }) {
            let kind = appState.data.kind(of: rec)
            List {
                Section {
                    VStack(spacing: Theme.gap) {
                        OperationIcon(kind: kind, amount: rec.amount, size: 64)
                        VStack(spacing: 4) {
                            Text(rec.person.isEmpty ? rec.category : rec.person)
                                .font(Theme.title)
                                .multilineTextAlignment(.center)
                            AmountText(amount: rec.amount, currency: rec.effectiveCurrency, font: Theme.display)
                                .minimumScaleFactor(0.5)
                            Text(dateLine(rec))
                                .font(Theme.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, Theme.gap)
                }
                .listRowBackground(Color.clear)

                Section {
                    LabeledContent("Операция", value: "\(rec.operation) · \(kind.title)")
                    LabeledContent("Категория", value: rec.category)
                    if !rec.subcategory.isEmpty {
                        LabeledContent("Подкатегория", value: rec.subcategory)
                    }
                    if !rec.person.isEmpty {
                        LabeledContent("Лицо", value: rec.person)
                    }
                }

                Section {
                    LabeledContent("Банк", value: rec.bank)
                    LabeledContent("Счёт", value: rec.account)
                    LabeledContent("Валюта",
                                   value: "\(rec.effectiveCurrency.title) · \(rec.effectiveCurrency.code)")
                }

                if !rec.comment.isEmpty {
                    Section(header: SectionTitle("Комментарий")) {
                        Text(rec.comment)
                    }
                }

                Section {
                    Button {
                        dismiss()
                        onEdit(rec)
                    } label: {
                        Label("Изменить", systemImage: "pencil")
                    }
                    Button {
                        dismiss()
                        onDuplicate(rec)
                    } label: {
                        Label("Сделать копию", systemImage: "plus.square.on.square")
                    }
                }

                Section {
                    DestructiveRow(title: "Удалить операцию", symbol: "trash") {
                        confirmDelete = true
                    }
                }
            }
            .themedList()
            .navigationTitle("Операция")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Удалить операцию?", isPresented: $confirmDelete) {
                Button("Отмена", role: .cancel) {}
                Button("Удалить", role: .destructive) {
                    appState.data.operations.removeAll { $0.id == recordID }
                    appState.persist()
                    dismiss()
                }
            } message: {
                Text("Операция будет удалена без возможности восстановления.")
            }
        } else {
            ContentUnavailableView("Операция удалена", systemImage: "tray")
        }
    }

    private func dateLine(_ rec: OperationRecord) -> String {
        let day = DateFmt.humanDay(rec.date)
        return rec.time.isEmpty ? day : "\(day), \(rec.time)"
    }
}
