import SwiftUI

struct HistoryView: View {
    @EnvironmentObject var appState: AppState
    @Binding var editState: EditState?
    var goToForm: () -> Void

    @State private var filterBankId: UUID? = nil
    @State private var filterCategoryName: String = ""
    @State private var filterFrom: Date? = nil
    @State private var filterTo: Date? = nil
    @State private var searchText: String = ""
    @State private var showFilters = false
    @State private var showClearConfirm = false
    @State private var exportFile: ExportFile? = nil
    @State private var deleteTarget: OperationRecord? = nil

    var hasActiveFilters: Bool {
        filterBankId != nil || !filterCategoryName.isEmpty || filterFrom != nil || filterTo != nil
    }

    var filteredSorted: [OperationRecord] {
        var items = appState.data.operations

        if let filterBankId, let bank = appState.data.banks.first(where: { $0.id == filterBankId }) {
            items = items.filter { $0.bank == bank.name }
        }
        if !filterCategoryName.isEmpty {
            items = items.filter { $0.category == filterCategoryName }
        }
        if let from = filterFrom {
            let s = DateFmt.dayString(from)
            items = items.filter { $0.date >= s }
        }
        if let to = filterTo {
            let s = DateFmt.dayString(to)
            items = items.filter { $0.date <= s }
        }
        let q = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            items = items.filter { r in
                let fields = [r.person, r.comment, r.category, r.subcategory, r.bank, r.account, r.operation]
                return fields.contains { $0.localizedCaseInsensitiveContains(q) } || Money.format(r.amount).contains(q)
            }
        }

        return items.sorted { a, b in
            if a.date != b.date { return a.date > b.date }
            if a.time != b.time { return a.time > b.time }
            return a.createdAt > b.createdAt
        }
    }

    struct DayGroup: Identifiable {
        let day: String
        var items: [OperationRecord]
        var id: String { day }
    }

    func groupByDay(_ sorted: [OperationRecord]) -> [DayGroup] {
        var result: [DayGroup] = []
        for rec in sorted {
            if let last = result.last, last.day == rec.date {
                result[result.count - 1].items.append(rec)
            } else {
                result.append(DayGroup(day: rec.date, items: [rec]))
            }
        }
        return result
    }

    var body: some View {
        let items = filteredSorted
        let groups = groupByDay(items)
        List {
            if items.isEmpty {
                emptyState
            } else {
                ForEach(groups) { group in
                    Section {
                        ForEach(group.items) { rec in
                            NavigationLink(value: rec.id) {
                                RecordRow(rec: rec, kind: appState.data.kind(of: rec))
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) { deleteTarget = rec } label: {
                                    Label("Удалить", systemImage: "trash")
                                }
                            }
                            .swipeActions(edge: .leading) {
                                Button { duplicate(rec) } label: { Label("Копия", systemImage: "plus.square.on.square") }
                                    .tint(.indigo)
                            }
                            .contextMenu {
                                Button { edit(rec) } label: { Label("Изменить", systemImage: "pencil") }
                                Button { duplicate(rec) } label: { Label("Сделать копию", systemImage: "plus.square.on.square") }
                                Divider()
                                Button(role: .destructive) { deleteTarget = rec } label: { Label("Удалить", systemImage: "trash") }
                            }
                        }
                    } header: {
                        Text(DateFmt.humanDay(group.day))
                    }
                }
            }
        }
        .navigationTitle("История")
        .themedList()
        .navigationDestination(for: UUID.self) { id in
            OperationDetailView(recordID: id,
                                onEdit: { rec in edit(rec) },
                                onDuplicate: { rec in duplicate(rec) })
        }
        .searchable(text: $searchText, prompt: "Поиск")
        .toolbar {
            ToolbarItemGroup(placement: .topBarTrailing) {
                Button {
                    showFilters = true
                } label: {
                    Image(systemName: hasActiveFilters
                          ? "line.3.horizontal.decrease.circle.fill"
                          : "line.3.horizontal.decrease.circle")
                }
                .accessibilityLabel("Фильтры")

                Menu {
                    Button {
                        export(appState.data.operations)
                    } label: {
                        Label("Экспорт всех в Excel", systemImage: "square.and.arrow.up")
                    }
                    .disabled(appState.data.operations.isEmpty)
                    if hasActiveFilters || !searchText.isEmpty {
                        Button {
                            export(items)
                        } label: {
                            Label("Экспорт найденных (\(items.count))", systemImage: "square.and.arrow.up.on.square")
                        }
                        .disabled(items.isEmpty)
                    }
                    Divider()
                    Button(role: .destructive) { showClearConfirm = true } label: {
                        Label("Очистить базу", systemImage: "trash")
                    }
                    .disabled(appState.data.operations.isEmpty)
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .accessibilityLabel("Действия")
            }
        }
        .sheet(isPresented: $showFilters) {
            filtersSheet
        }
        .alert("Удалить запись?", isPresented: Binding(
            get: { deleteTarget != nil },
            set: { if !$0 { deleteTarget = nil } }
        )) {
            Button("Отмена", role: .cancel) { deleteTarget = nil }
            Button("Удалить", role: .destructive) {
                if let t = deleteTarget {
                    appState.data.operations.removeAll { $0.id == t.id }
                    if editState == .edit(t.id) || editState == .duplicate(t.id) { editState = nil }
                    appState.persist()
                }
                deleteTarget = nil
            }
        } message: {
            Text("Операция будет удалена без возможности восстановления.")
        }
        .alert("Очистить базу?", isPresented: $showClearConfirm) {
            Button("Отмена", role: .cancel) {}
            Button("Очистить", role: .destructive) {
                appState.data.operations.removeAll()
                editState = nil
                appState.persist()
            }
        } message: {
            Text("Все операции (\(appState.data.operations.count)) будут удалены безвозвратно. Справочники останутся. Если данные нужны, сначала сделайте экспорт в Excel.")
        }
        .sheet(item: $exportFile) { file in
            ShareSheet(fileURL: file.url) { exportFile = nil }
                .presentationDetents([.medium, .large])
        }
    }

    @ViewBuilder
    private var emptyState: some View {
        if appState.data.operations.isEmpty {
            ContentUnavailableView("Операций пока нет",
                                   systemImage: "tray",
                                   description: Text("Добавьте первую операцию во вкладке «Форма»."))
                .listRowBackground(Color.clear)
        } else {
            ContentUnavailableView.search(text: searchText)
                .listRowBackground(Color.clear)
        }
    }

    private var filtersSheet: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Банк", selection: $filterBankId) {
                        Text("Все").tag(UUID?.none)
                        ForEach(appState.data.banks) { b in Text(b.name).tag(Optional(b.id)) }
                    }
                    Picker("Категория", selection: $filterCategoryName) {
                        Text("Все").tag("")
                        ForEach(categoryNames, id: \.self) { c in Text(c).tag(c) }
                    }
                }
                Section("Период") {
                    OptionalPickerField(label: "С", value: $filterFrom, placeholder: "Не выбрано") { b in
                        DatePicker("", selection: b, displayedComponents: .date).labelsHidden()
                    }
                    OptionalPickerField(label: "По", value: $filterTo, placeholder: "Не выбрано") { b in
                        DatePicker("", selection: b, displayedComponents: .date).labelsHidden()
                    }
                }
                if hasActiveFilters {
                    Section {
                        Button("Сбросить фильтры", role: .destructive) {
                            filterBankId = nil; filterCategoryName = ""; filterFrom = nil; filterTo = nil
                        }
                    }
                }
            }
            .navigationTitle("Фильтры")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Готово") { showFilters = false }
                }
            }
        }
        .presentationDetents([.medium, .large])
    }

    var categoryNames: [String] {
        Array(Set(appState.data.categories.map { $0.name }))
            .sorted { $0.localizedStandardCompare($1) == .orderedAscending }
    }

    func edit(_ rec: OperationRecord) {
        editState = .edit(rec.id)
        goToForm()
    }

    func duplicate(_ rec: OperationRecord) {
        editState = .duplicate(rec.id)
        goToForm()
    }

    func export(_ operations: [OperationRecord]) {
        guard !operations.isEmpty else { return }
        let sorted = operations.sorted { a, b in
            if a.date != b.date { return a.date < b.date }
            if a.time != b.time { return a.time < b.time }
            return a.createdAt < b.createdAt
        }
        let xlsxData = XLSXExporter.buildXLSX(operations: sorted)
        let filename = "operations_\(DateFmt.fileStamp(Date())).xlsx"
        let tmpURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
        do {
            try xlsxData.write(to: tmpURL, options: [.atomic, .completeFileProtection])
            exportFile = ExportFile(url: tmpURL)
        } catch {
            appState.saveError = "Не удалось подготовить файл Excel: \(error.localizedDescription)"
        }
    }
}

/// Строка операции — всегда две строки одинаковой высоты:
/// крупно лицо (или категория, если лица нет), ниже серым — категория и подкатегория.
/// Все подробности — на экране операции по нажатию.
struct RecordRow: View {
    let rec: OperationRecord
    let kind: OpKind

    var body: some View {
        HStack(spacing: Theme.gap) {
            OperationIcon(kind: kind, size: 40)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(Theme.bodyStrong)
                    .lineLimit(1)
                Text(subtitle)
                    .font(Theme.detail)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
            Spacer(minLength: Theme.gap)
            AmountText(amount: rec.amount, kind: kind)
        }
        .padding(.vertical, 2)
    }

    private var title: String {
        rec.person.isEmpty ? rec.category : rec.person
    }

    private var subtitle: String {
        if rec.person.isEmpty {
            return rec.subcategory.isEmpty ? rec.operation : rec.subcategory
        }
        return rec.subcategory.isEmpty ? rec.category : "\(rec.category) · \(rec.subcategory)"
    }
}

/// Круглая иконка операции: доход — зелёная стрелка вниз, расход — оранжевая вверх
struct OperationIcon: View {
    let kind: OpKind
    var size: CGFloat = 40

    private var color: Color {
        switch kind {
        case .income: return Theme.income
        case .expense: return Theme.expense
        case .neutral: return .gray
        }
    }

    var body: some View {
        Image(systemName: kind.symbol)
            .font(.system(size: size * 0.4, weight: .semibold))
            .foregroundStyle(color)
            .frame(width: size, height: size)
            .background(color.opacity(0.15), in: Circle())
            .accessibilityHidden(true)
    }
}

/// Экран одной операции — как карточка транзакции в Apple Wallet
struct OperationDetailView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    let recordID: UUID
    var onEdit: (OperationRecord) -> Void
    var onDuplicate: (OperationRecord) -> Void
    @State private var confirmDelete = false

    var body: some View {
        if let rec = appState.data.operations.first(where: { $0.id == recordID }) {
            let kind = appState.data.kind(of: rec)
            List {
                Section {
                    VStack(spacing: Theme.gap) {
                        OperationIcon(kind: kind, size: 64)
                        VStack(spacing: 4) {
                            Text(rec.person.isEmpty ? rec.category : rec.person)
                                .font(.title3.weight(.semibold))
                                .multilineTextAlignment(.center)
                            AmountText(amount: rec.amount, kind: kind, font: Theme.hero(40))
                                .minimumScaleFactor(0.5)
                            Text(dateLine(rec))
                                .font(Theme.detail)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, Theme.gap)
                }
                .listRowBackground(Color.clear)

                Section {
                    LabeledContent("Операция", value: "\(rec.operation) · \(kind.title)")
                    LabeledContent("Категория", value: rec.category)
                    if !rec.subcategory.isEmpty {
                        LabeledContent("Подкатегория", value: rec.subcategory)
                    }
                    if !rec.person.isEmpty {
                        LabeledContent("Лицо", value: rec.person)
                    }
                }

                Section {
                    LabeledContent("Банк", value: rec.bank)
                    LabeledContent("Счёт", value: rec.account)
                }

                if !rec.comment.isEmpty {
                    Section("Комментарий") {
                        Text(rec.comment)
                    }
                }

                Section {
                    Button {
                        dismiss()
                        onEdit(rec)
                    } label: {
                        Label("Изменить", systemImage: "pencil")
                    }
                    Button {
                        dismiss()
                        onDuplicate(rec)
                    } label: {
                        Label("Сделать копию", systemImage: "plus.square.on.square")
                    }
                }

                Section {
                    Button(role: .destructive) {
                        confirmDelete = true
                    } label: {
                        Label("Удалить операцию", systemImage: "trash")
                    }
                }
            }
            .themedList()
            .navigationTitle("Операция")
            .navigationBarTitleDisplayMode(.inline)
            .confirmationDialog("Удалить операцию?", isPresented: $confirmDelete, titleVisibility: .visible) {
                Button("Удалить", role: .destructive) {
                    appState.data.operations.removeAll { $0.id == recordID }
                    appState.persist()
                    dismiss()
                }
            } message: {
                Text("Операция будет удалена без возможности восстановления.")
            }
        } else {
            ContentUnavailableView("Операция удалена", systemImage: "tray")
        }
    }

    private func dateLine(_ rec: OperationRecord) -> String {
        let day = DateFmt.humanDay(rec.date)
        return rec.time.isEmpty ? day : "\(day), \(rec.time)"
    }
}
