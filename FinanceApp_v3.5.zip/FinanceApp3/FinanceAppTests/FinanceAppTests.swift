import XCTest
import CryptoKit
import SwiftUI
@testable import FinanceApp

// Юнит-тесты логики приложения. Запускаются в облаке (GitHub Actions)
// на настоящем Mac с Xcode — без iPhone и без установки.

final class CryptoTests: XCTestCase {

    private func hex(_ data: Data) -> String {
        data.map { String(format: "%02x", $0) }.joined()
    }

    /// Официальный тестовый вектор RFC 7914 (раздел 11) для PBKDF2-HMAC-SHA256
    func testPBKDF2_RFC7914Vector() {
        let out = PBKDF2.deriveBytes(password: "passwd", salt: Data("salt".utf8), iterations: 1, keyLength: 64)
        XCTAssertEqual(hex(out), "55ac046e56e3089fec1691c22544b605f94185216dde0465e68b9d57c20dacbc49ca9cccf179b645991664b39d77ef317c71b845b1e30bd509112041d3a19783")
    }

    /// Широко известный вектор: "password" / "salt" / 4096 итераций
    func testPBKDF2_4096Iterations() {
        let out = PBKDF2.deriveBytes(password: "password", salt: Data("salt".utf8), iterations: 4096, keyLength: 32)
        XCTAssertEqual(hex(out), "c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a")
    }

    /// Кириллический пароль — сверено с Python hashlib.pbkdf2_hmac
    func testPBKDF2_Cyrillic() {
        let out = PBKDF2.deriveBytes(password: "Пароль_кириллица", salt: Data("salt_kir".utf8), iterations: 5000, keyLength: 32)
        XCTAssertEqual(hex(out), "f0e1588eadc8344e4d660a6f1cbebbfb889f09a918006a93618171c54657cf55")
    }

    /// Сколько реально длится вывод ключа с боевыми параметрами (для информации)
    func testPBKDF2_ProductionSpeed() {
        let start = Date()
        _ = PBKDF2.deriveKey(password: "test1234", salt: Data(repeating: 7, count: 16), iterations: 250_000)
        let seconds = Date().timeIntervalSince(start)
        print("PBKDF2 250 000 итераций: \(String(format: "%.2f", seconds)) с")
        XCTAssertLessThan(seconds, 30)
    }

    func testEncryptDecryptRoundTrip() throws {
        let key = SymmetricKey(size: .bits256)
        var data = AppData()
        data.banks = [Bank(name: "Тинькофф")]
        data.operations = [OperationRecord(date: "2026-09-15", time: "14:30", bank: "Тинькофф", account: "Основной",
                                           operation: "Расход", category: "Еда", subcategory: "Кафе",
                                           person: "Иванов", amount: 1234.56, comment: "тест \"&<>'", createdAt: 1)]
        let blob = try CryptoBox.encrypt(data, key: key)
        let back = try CryptoBox.decrypt(blob, key: key, as: AppData.self)
        XCTAssertEqual(back, data)

        // Зашифрованный блоб не содержит открытого текста
        XCTAssertNil(String(data: blob.combined, encoding: .utf8)?.range(of: "Тинькофф"))
    }

    func testDecryptWithWrongKeyFails() throws {
        let blob = try CryptoBox.encrypt(AppData(), key: SymmetricKey(size: .bits256))
        XCTAssertThrowsError(try CryptoBox.decrypt(blob, key: SymmetricKey(size: .bits256), as: AppData.self))
    }

    func testTamperedDataFails() throws {
        let key = SymmetricKey(size: .bits256)
        var blob = try CryptoBox.encrypt(AppData(), key: key)
        var bytes = [UInt8](blob.combined)
        bytes[bytes.count - 1] ^= 0xFF
        blob.combined = Data(bytes)
        XCTAssertThrowsError(try CryptoBox.decrypt(blob, key: key, as: AppData.self))
    }
}

final class FormattingTests: XCTestCase {

    func testMoneyParse() {
        XCTAssertEqual(Money.parse("1234,56"), 1234.56)
        XCTAssertEqual(Money.parse("1234.56"), 1234.56)
        XCTAssertEqual(Money.parse("1 234,5"), 1234.5)
        XCTAssertEqual(Money.parse("1\u{00A0}000"), 1000)
        XCTAssertEqual(Money.parse(" 50000 "), 50000)
        XCTAssertEqual(Money.parse("0,01"), 0.01)
        XCTAssertNil(Money.parse(""))
        XCTAssertNil(Money.parse("abc"))
        XCTAssertNil(Money.parse("1,2,3"))
        XCTAssertNil(Money.parse("1e5"))
    }

    /// Знак вводит сам пользователь — минус должен пониматься в любом написании
    func testMoneyParseSign() {
        XCTAssertEqual(Money.parse("-5"), -5)
        XCTAssertEqual(Money.parse("\u{2212}1 234,56"), -1234.56)
        XCTAssertEqual(Money.parse("+700"), 700)
        XCTAssertEqual(Money.parse("-0,01"), -0.01)
        XCTAssertNil(Money.parse("-"))
        XCTAssertNil(Money.parse("--5"))
    }

    func testMoneyEditString() {
        XCTAssertEqual(Money.editString(50000), "50000")
        XCTAssertEqual(Money.editString(1234.56), "1234,56")
        XCTAssertEqual(Money.parse(Money.editString(1234.5)), 1234.5)
        // В поле ввода знака нет — им управляет отдельный переключатель
        XCTAssertEqual(Money.editString(-1234.56), "1234,56")
        XCTAssertEqual(Money.editString(-50000), "50000")
    }

    func testMoneyFormat() {
        let s = Money.format(1234.5)
        XCTAssertTrue(s.hasSuffix(",50"), s)
        XCTAssertTrue(s.hasPrefix("1"), s)

        let neg = Money.format(-1234.5)
        XCTAssertTrue(neg.hasPrefix(Money.minus), neg)
        XCTAssertTrue(neg.hasSuffix(",50"), neg)
        XCTAssertEqual(Money.format(0), "0,00")
    }

    func testDateRoundTrip() {
        let d = DateFmt.day(from: "2026-09-15")
        XCTAssertNotNil(d)
        XCTAssertEqual(DateFmt.dayString(d!), "2026-09-15")
        let t = DateFmt.time(from: "07:05")
        XCTAssertNotNil(t)
        XCTAssertEqual(DateFmt.timeString(t!), "07:05")
        XCTAssertNil(DateFmt.day(from: ""))
        XCTAssertEqual(DateFmt.display("2026-09-15"), "15.09.2026")
        XCTAssertEqual(DateFmt.monthTitle("2026-09"), "Сентябрь 2026")
    }

    private func record(_ operation: String, _ amount: Double = 1) -> OperationRecord {
        OperationRecord(date: "2026-01-01", time: "", bank: "", account: "", operation: operation,
                        category: "", subcategory: "", person: "", amount: amount, comment: "", createdAt: 0)
    }

    /// Тип операции задаётся вручную в справочнике, название может быть любым
    func testKindFromDictionary() {
        var data = AppData()
        data.optypes = [OperationType(name: "Поступление", kind: .income),
                        OperationType(name: "Трата", kind: .expense),
                        OperationType(name: "Перевод себе", kind: .neutral)]
        XCTAssertEqual(data.kind(of: record("Поступление")), .income)
        XCTAssertEqual(data.kind(of: record("Трата")), .expense)
        XCTAssertEqual(data.kind(of: record("Перевод себе")), .neutral)
        XCTAssertTrue(data.isIncome(record("Поступление")))
    }

    /// Главное правило: тип операции НЕ меняет знак суммы, он только группирует.
    /// Исключается из подсчёта лишь «Не учитывать».
    func testKindDoesNotChangeSign() {
        var data = AppData()
        data.optypes = [OperationType(name: "INFLOW", kind: .income),
                        OperationType(name: "OUTFLOW", kind: .expense),
                        OperationType(name: "Перевод себе", kind: .neutral)]
        // минус остаётся минусом, плюс остаётся плюсом — в любой группе
        XCTAssertEqual(data.signedAmount(record("OUTFLOW", -100)), -100)
        XCTAssertEqual(data.signedAmount(record("OUTFLOW", 100)), 100)
        XCTAssertEqual(data.signedAmount(record("INFLOW", 500)), 500)
        XCTAssertEqual(data.signedAmount(record("INFLOW", -500)), -500)
        // «Не учитывать» не влияет на баланс
        XCTAssertEqual(data.signedAmount(record("Перевод себе", -100)), 0)

        // Баланс — простая сумма всех учитываемых операций
        let ops = [record("INFLOW", 1000), record("OUTFLOW", -250),
                   record("OUTFLOW", -150), record("Перевод себе", -9999)]
        XCTAssertEqual(ops.reduce(0) { $0 + data.signedAmount($1) }, 600)
    }

    /// Если тип не задан (старые данные) — определяется по названию
    func testKindFallbackByName() {
        var data = AppData()
        data.optypes = [OperationType(name: "Доход"), OperationType(name: "Расход"), OperationType(name: "Перевод")]
        XCTAssertEqual(data.kind(of: record("Доход")), .income)
        XCTAssertEqual(data.kind(of: record("Расход")), .expense)
        XCTAssertEqual(data.kind(of: record("Перевод")), .neutral)
        // операции нет в справочнике
        XCTAssertEqual(data.kind(of: record("Прочий доход")), .income)
    }

    /// Старые сохранённые данные без поля kind должны читаться
    func testOldDataMigrates() throws {
        let oldJSON = """
        {"id":"\(UUID().uuidString)","name":"Расход"}
        """
        let decoded = try JSONDecoder().decode(OperationType.self, from: Data(oldJSON.utf8))
        XCTAssertNil(decoded.kind)
        XCTAssertEqual(decoded.effectiveKind, .expense)
    }

    /// Файл, записанный до появления валют и категорий лиц, обязан открыться:
    /// у человека на телефоне лежат именно такие данные.
    func testFileWithoutNewFieldsOpens() throws {
        let personId = UUID().uuidString
        let accId = UUID().uuidString
        let bankId = UUID().uuidString
        let oldJSON = """
        {"banks":[{"id":"\(bankId)","name":"VTBR"}],
         "accounts":[{"id":"\(accId)","name":"7684","bankId":"\(bankId)"}],
         "optypes":[],"categories":[],"subcategories":[],
         "persons":[{"id":"\(personId)","name":"IFCM"}],
         "operations":[{"id":"\(UUID().uuidString)","date":"2026-09-01","time":"","bank":"VTBR",
                        "account":"7684","operation":"OUTFLOW","category":"FOD","subcategory":"",
                        "person":"IFCM","amount":-100,"comment":"","createdAt":1}]}
        """
        let d = try JSONDecoder().decode(AppData.self, from: Data(oldJSON.utf8))

        XCTAssertEqual(d.accounts.first?.effectiveCurrency, .rub, "старый счёт должен стать рублёвым")
        XCTAssertFalse(d.accounts.first?.isClosed ?? true, "старый счёт должен считаться открытым")
        XCTAssertEqual(d.operations.first?.effectiveCurrency, .rub)
        XCTAssertEqual(d.personGroups.count, 1)
        XCTAssertEqual(d.personGroups.first?.name, PersonGroup.defaultName)
        XCTAssertEqual(d.persons.first?.groupId, d.personGroups.first?.id,
                       "лицо без категории обязано попасть в «Общее»")
    }

    /// Лицо, чья категория удалена, не должно потеряться
    func testPersonWithLostGroupReturnsToDefault() {
        var d = AppData()
        let ghost = UUID()
        d.persons = [Person(name: "Кто-то", groupId: ghost)]
        d.repairPersonGroups()
        XCTAssertEqual(d.persons[0].groupId, d.personGroups[0].id)
    }

    /// Порядок лиц: сначала закреплённые, потом по числу операций
    func testPersonsOrderedByPinThenUsage() {
        var d = AppData()
        let g = d.personGroups[0].id
        d.persons = [Person(name: "Редкий", groupId: g),
                     Person(name: "Частый", groupId: g),
                     Person(name: "Закреплённый", groupId: g, pinned: true)]
        func op(_ person: String) -> OperationRecord {
            OperationRecord(date: "2026-01-01", time: "", bank: "", account: "", operation: "",
                            category: "", subcategory: "", person: person, amount: 1,
                            comment: "", createdAt: 0)
        }
        d.operations = [op("Частый"), op("Частый"), op("Частый"), op("Редкий")]
        XCTAssertEqual(d.personsOrdered(in: g).map { $0.name },
                       ["Закреплённый", "Частый", "Редкий"])
    }

    /// Остатки: считаются по суммам как введены, включая «Не учитывать»
    func testAccountBalances() {
        var d = AppData()
        let bank = Bank(name: "Банк")
        let rub = Account(name: "Рублёвый", bankId: bank.id, currency: .rub)
        let usd = Account(name: "Долларовый", bankId: bank.id, currency: .usd)
        let old = Account(name: "Закрытый", bankId: bank.id, currency: .rub, closed: true)
        d.banks = [bank]
        d.accounts = [rub, usd, old]
        d.optypes = [OperationType(name: "Перевод", kind: .neutral)]
        func op(_ acc: String, _ amount: Double, _ cur: Currency, _ kind: String = "Трата") -> OperationRecord {
            OperationRecord(date: "2026-01-01", time: "", bank: "Банк", account: acc,
                            operation: kind, category: "", subcategory: "", person: "",
                            amount: amount, comment: "", createdAt: 0, currency: cur)
        }
        d.operations = [op("Рублёвый", 1000, .rub), op("Рублёвый", -250, .rub),
                        op("Рублёвый", -300, .rub, "Перевод"),     // «Не учитывать»
                        op("Долларовый", 40, .usd)]

        let b = d.accountBalances()
        let rubRow = b.first { $0.account == "Рублёвый" }
        XCTAssertEqual(rubRow?.total, 450, "перевод обязан уменьшить остаток счёта")
        XCTAssertEqual(rubRow?.count, 3)
        XCTAssertEqual(b.first { $0.account == "Долларовый" }?.total, 40)
        XCTAssertEqual(b.first { $0.account == "Долларовый" }?.currency, .usd)
        XCTAssertEqual(b.first { $0.account == "Закрытый" }?.total, 0, "счёт без операций — ноль")
        XCTAssertEqual(b.last?.account, "Закрытый", "закрытые уходят в конец")

        // При этом на доходы и расходы «Не учитывать» по-прежнему не влияет
        XCTAssertEqual(d.signedAmount(op("Рублёвый", -300, .rub, "Перевод")), 0)
    }

    /// Сумма со знаком валюты
    func testMoneyFormatWithCurrency() {
        XCTAssertTrue(Money.format(1234.5, .usd).hasSuffix("$"))
        XCTAssertTrue(Money.format(1234.5, .rub).hasSuffix("₽"))
        XCTAssertTrue(Money.format(-10, .eur).hasPrefix(Money.minus))
        XCTAssertEqual(Currency.cny.code, "CNY")
    }
}

final class XLSXTests: XCTestCase {

    private func u32(_ d: [UInt8], _ i: Int) -> UInt32 {
        UInt32(d[i]) | UInt32(d[i+1]) << 8 | UInt32(d[i+2]) << 16 | UInt32(d[i+3]) << 24
    }
    private func u16(_ d: [UInt8], _ i: Int) -> Int {
        Int(d[i]) | Int(d[i+1]) << 8
    }

    func testXLSXStructure() throws {
        let ops = [
            OperationRecord(date: "2026-09-15", time: "14:30", bank: "Тинькофф", account: "Тест \"кавычки\" & <теги>",
                            operation: "Расход", category: "Еда", subcategory: "апостроф'тест",
                            person: "Иванов", amount: 1234.56, comment: "", createdAt: 1),
            OperationRecord(date: "2026-09-14", time: "", bank: "Сбер", account: "Зарплатный",
                            operation: "Доход", category: "Зарплата", subcategory: "",
                            person: "", amount: 50000, comment: "", createdAt: 2,
                            currency: .usd),
        ]
        let bytes = [UInt8](XLSXExporter.buildXLSX(operations: ops))

        // Начало: сигнатура локального заголовка ZIP "PK\3\4"
        XCTAssertEqual(u32(bytes, 0), 0x04034b50)

        // Конец: запись End Of Central Directory (22 байта)
        let eocd = bytes.count - 22
        XCTAssertEqual(u32(bytes, eocd), 0x06054b50)
        XCTAssertEqual(u16(bytes, eocd + 10), 6, "должно быть 6 файлов внутри xlsx")
        let cdSize = Int(u32(bytes, eocd + 12))
        let cdOffset = Int(u32(bytes, eocd + 16))
        XCTAssertEqual(cdOffset + cdSize, eocd, "центральный каталог должен заканчиваться прямо перед EOCD")

        // Проходим центральный каталог и проверяем, что каждый файл найден по смещению
        var p = cdOffset
        var names: [String] = []
        var sheetXML = ""
        for _ in 0..<6 {
            XCTAssertEqual(u32(bytes, p), 0x02014b50)
            let size = Int(u32(bytes, p + 20))
            let nameLen = u16(bytes, p + 28)
            let localOffset = Int(u32(bytes, p + 42))
            let name = String(decoding: bytes[(p + 46)..<(p + 46 + nameLen)], as: UTF8.self)
            names.append(name)
            XCTAssertEqual(u32(bytes, localOffset), 0x04034b50, "локальный заголовок \(name)")
            let localNameLen = u16(bytes, localOffset + 26)
            let dataStart = localOffset + 30 + localNameLen
            let content = String(decoding: bytes[dataStart..<(dataStart + size)], as: UTF8.self)
            XCTAssertTrue(content.hasPrefix("<?xml"), "\(name) должен начинаться с <?xml")
            if name == "xl/worksheets/sheet1.xml" { sheetXML = content }
            p += 46 + nameLen
        }
        XCTAssertEqual(Set(names), ["[Content_Types].xml", "_rels/.rels", "xl/workbook.xml",
                                    "xl/_rels/workbook.xml.rels", "xl/styles.xml", "xl/worksheets/sheet1.xml"])

        // Содержимое листа: экранирование и формат суммы
        XCTAssertTrue(sheetXML.contains("Тест &quot;кавычки&quot; &amp; &lt;теги&gt;"))
        XCTAssertTrue(sheetXML.contains("апостроф&apos;тест"))
        XCTAssertTrue(sheetXML.contains("<v>1234.56</v>"))
        XCTAssertTrue(sheetXML.contains("<v>50000.00</v>"))
        XCTAssertTrue(sheetXML.contains("<dimension ref=\"A1:K3\"/>"),
                      "после колонки валюты лист должен идти до K")
        XCTAssertTrue(sheetXML.contains("<t>Валюта</t>"))
        XCTAssertTrue(sheetXML.contains("<t>RUB</t>"), "валюта по умолчанию — рубль")
        XCTAssertTrue(sheetXML.contains("<t>USD</t>"))
    }
}

@MainActor
final class AppStateTests: XCTestCase {

    private func makeTempDir() -> URL {
        FileManager.default.temporaryDirectory.appendingPathComponent("FinanceTest-\(UUID().uuidString)")
    }

    private func sampleOp(_ amount: Double) -> OperationRecord {
        OperationRecord(date: "2026-09-15", time: "10:00", bank: "Банк", account: "Счёт", operation: "Расход",
                        category: "Еда", subcategory: "", person: "", amount: amount, comment: "", createdAt: 1)
    }

    func testFullLifecycle() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        // 1. Первый запуск — пароля нет
        let s1 = AppState(storageDir: dir, iterations: 1000)
        XCTAssertFalse(s1.hasAccount)

        // 2. Слишком короткий пароль отклоняется
        let short = await s1.createPassword("123")
        XCTAssertNotNil(short)

        // 3. Создание пароля и сохранение операции
        let created = await s1.createPassword("secret1")
        XCTAssertNil(created)
        XCTAssertTrue(s1.isUnlocked)
        s1.data.operations.append(sampleOp(100))
        s1.persist()
        XCTAssertNil(s1.saveError)

        // 4. Файлы исключены из резервных копий
        let dataFile = dir.appendingPathComponent("financedata.enc")
        let values = try dataFile.resourceValues(forKeys: [.isExcludedFromBackupKey])
        XCTAssertEqual(values.isExcludedFromBackup, true)

        // 5. Блокировка стирает данные из памяти
        s1.lock()
        XCTAssertFalse(s1.isUnlocked)
        XCTAssertTrue(s1.data.operations.isEmpty)

        // 6. «Перезапуск» приложения: неверный пароль не пускает
        let s2 = AppState(storageDir: dir, iterations: 1000)
        XCTAssertTrue(s2.hasAccount)
        let wrong = await s2.login("wrong")
        XCTAssertNotNil(wrong)
        XCTAssertFalse(s2.isUnlocked)

        // 7. Верный пароль восстанавливает данные
        let ok = await s2.login("secret1")
        XCTAssertNil(ok)
        XCTAssertEqual(s2.data.operations.count, 1)
        XCTAssertEqual(s2.data.operations.first?.amount, 100)

        // 8. Смена пароля: старый больше не подходит, данные целы
        let badOld = await s2.changePassword(old: "nope", new: "newpass")
        XCTAssertNotNil(badOld)
        let changed = await s2.changePassword(old: "secret1", new: "newpass")
        XCTAssertNil(changed)
        s2.data.operations.append(sampleOp(200))
        s2.persist()

        let s3 = AppState(storageDir: dir, iterations: 1000)
        let oldFails = await s3.login("secret1")
        XCTAssertNotNil(oldFails)
        let newWorks = await s3.login("newpass")
        XCTAssertNil(newWorks)
        XCTAssertEqual(s3.data.operations.map(\.amount), [100, 200])

        // 9. Полный сброс удаляет всё
        s3.fullReset()
        XCTAssertFalse(s3.hasAccount)
        let s4 = AppState(storageDir: dir, iterations: 1000)
        XCTAssertFalse(s4.hasAccount)
    }

    func testAutoLockAfterInactivity() async throws {
        let dir = makeTempDir()
        defer { try? FileManager.default.removeItem(at: dir) }
        let s = AppState(storageDir: dir, iterations: 1000)
        _ = await s.createPassword("secret1")
        XCTAssertTrue(s.isUnlocked)
        s.checkAutoLock()
        XCTAssertTrue(s.isUnlocked, "сразу после активности блокироваться не должно")
    }

    // MARK: - Отчёты

    private func reportData() -> AppData {
        var d = AppData()
        d.optypes = [OperationType(name: "Приход", kind: .income),
                     OperationType(name: "Трата", kind: .expense),
                     OperationType(name: "Перевод", kind: .neutral)]
        func op(_ date: String, _ kind: String, _ amount: Double,
                _ cat: String = "Еда", _ person: String = "") -> OperationRecord {
            OperationRecord(date: date, time: "", bank: "Банк", account: "Основной",
                            operation: kind, category: cat, subcategory: "", person: person,
                            amount: amount, comment: "", createdAt: 0, currency: .rub)
        }
        d.operations = [op("2026-03-02", "Приход", 100_000, "Зарплата", "Работодатель"),
                        op("2026-03-02", "Трата", -1_000),
                        op("2026-03-05", "Трата", -2_000, "Дом"),
                        op("2026-04-01", "Трата", -3_000),
                        op("2026-04-01", "Перевод", -5_000, "Перевод")]
        return d
    }

    /// Границы периода включаются в расчёт с обоих концов
    func testSpanBoundsAreInclusive() {
        let d = reportData()
        let from = DateFmt.day(from: "2026-03-02") ?? Date()
        let to = DateFmt.day(from: "2026-03-05") ?? Date()
        let span = DateSpan(preset: .custom, from: from, to: to)
        let sums = d.sums(in: span, currency: .rub)
        XCTAssertEqual(sums.income, 100_000)
        XCTAssertEqual(sums.expense, -3_000, "обе граничные даты должны попасть в период")
    }

    /// Корзины создаются на все дни отрезка, даже пустые
    func testBucketsCoverEveryDay() {
        let d = reportData()
        let from = DateFmt.day(from: "2026-03-01") ?? Date()
        let to = DateFmt.day(from: "2026-03-05") ?? Date()
        let span = DateSpan(preset: .custom, from: from, to: to)
        let buckets = d.buckets(span: span, step: .day, currency: .rub)
        XCTAssertEqual(buckets.count, 5, "пять календарных дней — пять корзин")
        XCTAssertEqual(buckets.first?.income, 0, "первый день пустой")
        XCTAssertEqual(buckets[1].income, 100_000)
        XCTAssertEqual(buckets[1].expense, -1_000)
        XCTAssertEqual(buckets[4].expense, -2_000)
        for b in buckets { XCTAssertEqual(b.days, 1) }
    }

    /// Месячный шаг знает, сколько в месяце дней — по ним считается план
    func testMonthBucketsCountDays() {
        let d = reportData()
        let from = DateFmt.day(from: "2026-03-01") ?? Date()
        let to = DateFmt.day(from: "2026-04-30") ?? Date()
        let span = DateSpan(preset: .custom, from: from, to: to)
        let buckets = d.buckets(span: span, step: .month, currency: .rub)
        XCTAssertEqual(buckets.count, 2)
        XCTAssertEqual(buckets[0].days, 31, "в марте 31 день")
        XCTAssertEqual(buckets[1].days, 30, "в апреле 30 дней")
        XCTAssertEqual(buckets[1].expense, -3_000, "перевод не расход")
    }

    /// «Всё время» на пустой базе не должно разворачиваться на полвека
    func testAllTimeWithoutDataIsSingleDay() {
        let empty = AppData()
        let span = empty.clamped(DateSpan.make(.all))
        XCTAssertEqual(span.fromKey, span.toKey)
        XCTAssertEqual(empty.buckets(span: DateSpan.make(.all), step: .day, currency: .rub).count, 1)
    }

    /// «Всё время» ограничивается реальными данными с обоих концов
    func testAllTimeFollowsData() {
        let d = reportData()
        let span = d.clamped(DateSpan.make(.all))
        XCTAssertEqual(span.fromKey, "2026-03-02")
        XCTAssertEqual(span.toKey, "2026-04-01")
    }

    /// Обороты по счёту включают переводы
    func testTurnoversIncludeTransfers() {
        let d = reportData()
        let span = d.clamped(DateSpan.make(.all))
        let rows = d.accountTurnovers(span: span, currency: .rub)
        XCTAssertEqual(rows.count, 1)
        XCTAssertEqual(rows.first?.count, 5)
        XCTAssertEqual(rows.first?.total, 89_000, "100000 − 1000 − 2000 − 3000 − 5000")
    }

    /// Доли считаются от суммы модулей, иначе возврат ломает проценты
    func testSharesPercentBase() {
        let rows = [ShareRow(name: "А", value: -1_000), ShareRow(name: "Б", value: 500)]
        XCTAssertEqual(AppData.absSum(rows), 1_500)
        XCTAssertEqual(ShareLegend.percent(-1_000, of: 1_500), "67 %")
        XCTAssertEqual(ShareLegend.percent(500, of: 1_500), "33 %")
    }

    /// Мелочь сворачивается в «Остальное»
    func testSharesFoldTail() {
        var d = AppData()
        d.optypes = [OperationType(name: "Трата", kind: .expense)]
        var ops: [OperationRecord] = []
        for i in 1...5 {
            ops.append(OperationRecord(date: "2026-03-01", time: "", bank: "Б", account: "С",
                                       operation: "Трата", category: "К\(i)", subcategory: "",
                                       person: "", amount: Double(-i * 100), comment: "",
                                       createdAt: 0, currency: .rub))
        }
        let rows = d.shares(ops, by: { $0.category }, limit: 3)
        XCTAssertEqual(rows.count, 4)
        XCTAssertEqual(rows[0].name, "К5")
        XCTAssertEqual(rows[3].name, "Остальное")
        XCTAssertEqual(rows[3].value, -300, "две самые мелкие: −100 и −200")
    }

    /// Разделители разрядов ставятся прямо при наборе
    func testGroupInput() {
        XCTAssertEqual(Money.groupInput("1234567"), "1\u{202F}234\u{202F}567")
        XCTAssertEqual(Money.groupInput("1234,5"), "1\u{202F}234,5")
        XCTAssertEqual(Money.groupInput("12,345"), "12,34", "копеек не больше двух")
        XCTAssertEqual(Money.groupInput("abc"), "")
    }
}
